<?php
// api.php - Master Unified API (Stages 1 through 7)
require_once 'config.php';

$pdo = getDB();
$action = $_GET['action'] ?? '';
$currentUser = $_SESSION['user_id'] ?? 'u-head-1';
$currentRole = $_SESSION['role'] ?? 'HEAD_NURSE';

$input = json_decode(file_get_contents('php://input'), true) ?? [];

switch ($action) {
    // -------------------------------------------------------------------------
    // ROLE & SESSION
    // -------------------------------------------------------------------------
    case 'switch_user':
        $role = $input['role'] ?? 'HEAD_NURSE';
        if ($role === 'HEAD_NURSE') {
            $_SESSION['user_id'] = 'u-head-1';
            $_SESSION['role'] = 'HEAD_NURSE';
        } else {
            $_SESSION['user_id'] = 'u-nurse-2';
            $_SESSION['role'] = 'STAFF_NURSE';
        }
        echo json_encode(['status' => 'success', 'user_id' => $_SESSION['user_id'], 'role' => $_SESSION['role']]);
        break;

    // -------------------------------------------------------------------------
    // STAGE 2: NURSE DIRECTORY & MASTER CRUD (WITH KSA ID VALIDATION)
    // -------------------------------------------------------------------------
    case 'get_nurses':
        $sql = "
            SELECT n.*, u.name_en AS unit_name_en, u.name_ar AS unit_name_ar,
                   c.credential_number, c.expiry_date,
                   DATEDIFF(c.expiry_date, CURRENT_DATE) AS days_to_expiry,
                   (SELECT weekly_hours_limit FROM contracts WHERE nurse_id = n.nurse_id AND is_active = TRUE LIMIT 1) AS weekly_limit
            FROM nurses n
            LEFT JOIN units u ON n.primary_unit_id = u.unit_id
            LEFT JOIN certifications c ON n.nurse_id = c.nurse_id AND c.cert_type = 'SCFHS_LICENSE'
            ORDER BY n.employee_number ASC
        ";
        echo json_encode($pdo->query($sql)->fetchAll());
        break;

    case 'save_nurse':
        if ($currentRole === 'STAFF_NURSE') {
            http_response_code(403);
            echo json_encode(['error' => 'PDPL Access Violation: Staff Nurses cannot edit employee master records.']);
            exit;
        }
        $nurseId = $input['nurse_id'] ?? null;
        $empNo = trim($input['employee_number'] ?? '');
        $fnEn = trim($input['first_name_en'] ?? '');
        $lnEn = trim($input['last_name_en'] ?? '');
        $fnAr = trim($input['first_name_ar'] ?? $fnEn);
        $lnAr = trim($input['last_name_ar'] ?? $lnEn);
        $idType = $input['identification_type'] ?? 'NATIONAL_ID';
        $idNo = trim($input['identification_number'] ?? '');
        $phone = trim($input['phone_number'] ?? '');
        $unitId = $input['primary_unit_id'] ?? 'u-nicu';

        // Saudi National ID & Iqama 10-Digit Rules
        if ($idType === 'NATIONAL_ID' && !preg_match('/^1[0-9]{9}$/', $idNo)) {
            http_response_code(422);
            echo json_encode(['error' => 'Validation Error: Saudi National ID must start with 1 and contain exactly 10 digits.']);
            exit;
        }
        if ($idType === 'IQAMA' && !preg_match('/^2[0-9]{9}$/', $idNo)) {
            http_response_code(422);
            echo json_encode(['error' => 'Validation Error: Saudi Iqama must start with 2 and contain exactly 10 digits.']);
            exit;
        }

        if (empty($nurseId)) {
            $nurseId = 'n-' . bin2hex(random_bytes(4));
            $userId = 'u-' . bin2hex(random_bytes(4));
            $pdo->prepare("INSERT INTO users (user_id, email, password_hash, role) VALUES (?, ?, '$2y$10$e7mZ5h8qFmI6s4eD2yC.mOKB6.4fX5x7hW1D6/lC1V9c8s9tGq7qG', 'STAFF_NURSE')")
                ->execute([$userId, strtolower($empNo) . '@hospital.sa']);
            $pdo->prepare("
                INSERT INTO nurses (nurse_id, user_id, employee_number, first_name_en, last_name_en, first_name_ar, last_name_ar, identification_type, identification_number, phone_number, primary_unit_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ")->execute([$nurseId, $userId, $empNo, $fnEn, $lnEn, $fnAr, $lnAr, $idType, $idNo, $phone, $unitId]);
            $pdo->prepare("INSERT INTO contracts (contract_id, nurse_id, contract_type, start_date, weekly_hours_limit) VALUES (UUID(), ?, 'INDEFINITE', CURRENT_DATE, 48)")
                ->execute([$nurseId]);
        } else {
            $pdo->prepare("
                UPDATE nurses SET first_name_en = ?, last_name_en = ?, first_name_ar = ?, last_name_ar = ?, identification_type = ?, identification_number = ?, phone_number = ?, primary_unit_id = ?
                WHERE nurse_id = ?
            ")->execute([$fnEn, $lnEn, $fnAr, $lnAr, $idType, $idNo, $phone, $unitId, $nurseId]);
        }
        echo json_encode(['status' => 'success']);
        break;

    // -------------------------------------------------------------------------
    // STAGE 3: AUTOMATED EXPIRY ENGINE (90 / 60 / 30 DAY SWEEP)
    // -------------------------------------------------------------------------
    case 'run_automated_sweep':
        $count = 0;
        $certs = $pdo->query("
            SELECT c.*, n.first_name_en, n.last_name_en, n.user_id, DATEDIFF(c.expiry_date, CURRENT_DATE) AS days_left
            FROM certifications c JOIN nurses n ON c.nurse_id = n.nurse_id
            WHERE c.expiry_date <= DATE_ADD(CURRENT_DATE, INTERVAL 30 DAY)
        ")->fetchAll();

        foreach ($certs as $c) {
            $isExpired = $c['days_left'] < 0;
            $titleEn = $isExpired ? "CRITICAL: SCFHS License Expired" : "Urgent: License Expiry in {$c['days_left']} Days";
            $titleAr = $isExpired ? "تنبيه: انتهاء ترخيص هيئة التخصصات" : "تنبيه: اقتراب انتهاء الترخيص خلال {$c['days_left']} يوم";
            $msgEn = "License #{$c['credential_number']} for {$c['first_name_en']} {$c['last_name_en']} requires renewal.";
            $msgAr = "ترخيص #{$c['credential_number']} للممرض يتطلب التجديد الفوري.";
            
            $pdo->prepare("INSERT INTO notifications (notification_id, user_id, channel, category, title_en, title_ar, message_en, message_ar) VALUES (UUID(), ?, 'IN_APP', 'CERT_EXPIRY', ?, ?, ?, ?)")
                ->execute([$c['user_id'], $titleEn, $titleAr, $msgEn, $msgAr]);
            $count++;
        }
        echo json_encode(['status' => 'success', 'dispatched' => $count]);
        break;

    case 'get_notifications':
        $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 25");
        $stmt->execute([$currentUser]);
        echo json_encode($stmt->fetchAll());
        break;

    // -------------------------------------------------------------------------
    // STAGE 4 & 5: TEAMS SHIFTS MATRIX, SWAPS & UNIFIED HUB
    // -------------------------------------------------------------------------
    case 'get_shifts_matrix':
        $unitId = $_GET['unit_id'] ?? 'u-nicu';
        $startDate = $_GET['start_date'] ?? date('Y-m-d', strtotime('-1 days'));
        $endDate = $_GET['end_date'] ?? date('Y-m-d', strtotime('+5 days'));

        $stmt = $pdo->prepare("
            SELECT sa.*, n.first_name_en, n.last_name_en, n.employee_number, n.first_name_ar, n.last_name_ar
            FROM shift_assignments sa
            JOIN nurses n ON sa.nurse_id = n.nurse_id
            WHERE sa.unit_id = ? AND sa.shift_date BETWEEN ? AND ?
            ORDER BY sa.shift_date ASC, n.employee_number ASC
        ");
        $stmt->execute([$unitId, $startDate, $endDate]);

        $nurses = $pdo->prepare("SELECT * FROM nurses WHERE primary_unit_id = ?");
        $nurses->execute([$unitId]);

        $openShifts = $pdo->prepare("SELECT * FROM shift_assignments WHERE unit_id = ? AND is_open_shift = TRUE AND shift_date BETWEEN ? AND ?");
        $openShifts->execute([$unitId, $startDate, $endDate]);

        echo json_encode([
            'shifts' => $stmt->fetchAll(),
            'nurses' => $nurses->fetchAll(),
            'open_shifts' => $openShifts->fetchAll()
        ]);
        break;

    case 'save_shift_cell':
        if ($currentRole === 'STAFF_NURSE') {
            http_response_code(403);
            echo json_encode(['error' => 'Permission denied: Staff Nurses cannot edit rosters directly.']);
            exit;
        }
        $nurseId = $input['nurse_id'];
        $unitId = $input['unit_id'];
        $shiftDate = $input['shift_date'];
        $code = strtoupper(trim($input['duty_code'] ?? 'D'));

        // Validation 1: Hard Block on Expired SCFHS License
        if (in_array($code, ['D', 'E', 'N'])) {
            $cStmt = $pdo->prepare("SELECT expiry_date FROM certifications WHERE nurse_id = ? AND cert_type = 'SCFHS_LICENSE'");
            $cStmt->execute([$nurseId]);
            $cert = $cStmt->fetch();
            if ($cert && strtotime($cert['expiry_date']) < strtotime($shiftDate)) {
                http_response_code(422);
                echo json_encode(['error' => "SCFHS LICENSE EXPIRED: Nurse license expired on {$cert['expiry_date']}. Shift blocked."]);
                exit;
            }

            // Validation 2: Hard Block on Approved Leave
            $lStmt = $pdo->prepare("SELECT * FROM leave_requests WHERE nurse_id = ? AND status = 'APPROVED' AND ? BETWEEN start_date AND end_date");
            $lStmt->execute([$nurseId, $shiftDate]);
            if ($l = $lStmt->fetch()) {
                http_response_code(422);
                echo json_encode(['error' => "LEAVE CONFLICT: Nurse is on approved {$l['leave_type']} leave."]);
                exit;
            }
        }

        $startTime = "$shiftDate 07:00:00";
        $endTime = ($code === 'N') ? date('Y-m-d 07:00:00', strtotime("$shiftDate +1 day")) : "$shiftDate 19:00:00";

        $pdo->prepare("DELETE FROM shift_assignments WHERE nurse_id = ? AND shift_date = ?")->execute([$nurseId, $shiftDate]);
        $pdo->prepare("
            INSERT INTO shift_assignments (assignment_id, nurse_id, unit_id, shift_date, start_time, end_time, duty_code, status, is_published)
            VALUES (UUID(), ?, ?, ?, ?, ?, ?, 'SCHEDULED', FALSE)
        ")->execute([$nurseId, $unitId, $shiftDate, $startTime, $endTime, $code]);

        echo json_encode(['status' => 'success']);
        break;

    case 'publish_unit_schedule':
        $unitId = $input['unit_id'];
        $stmt = $pdo->prepare("UPDATE shift_assignments SET is_published = TRUE WHERE unit_id = ?");
        $stmt->execute([$unitId]);
        echo json_encode(['status' => 'success', 'count' => $stmt->rowCount()]);
        break;

    case 'claim_open_shift':
        $nStmt = $pdo->prepare("SELECT nurse_id FROM nurses WHERE user_id = ?");
        $nStmt->execute([$currentUser]);
        $myNurse = $nStmt->fetch();
        $pdo->prepare("UPDATE shift_assignments SET nurse_id = ?, is_open_shift = FALSE, status = 'CONFIRMED' WHERE assignment_id = ?")
            ->execute([$myNurse['nurse_id'], $input['assignment_id']]);
        echo json_encode(['status' => 'success']);
        break;

    // -------------------------------------------------------------------------
    // LEAVE WORKFLOW & SBAR HANDOVERS (Stage 3 & 5)
    // -------------------------------------------------------------------------
    case 'get_leaves':
        echo json_encode($pdo->query("
            SELECT lr.*, n.first_name_en, n.last_name_en, n.employee_number 
            FROM leave_requests lr JOIN nurses n ON lr.nurse_id = n.nurse_id ORDER BY lr.created_at DESC
        ")->fetchAll());
        break;

    case 'submit_leave':
        $nStmt = $pdo->prepare("SELECT nurse_id FROM nurses WHERE user_id = ?");
        $nStmt->execute([$currentUser]);
        $nurse = $nStmt->fetch();
        $pdo->prepare("INSERT INTO leave_requests (leave_id, nurse_id, leave_type, start_date, end_date, reason) VALUES (UUID(), ?, ?, ?, ?, ?)")
            ->execute([$nurse['nurse_id'], $input['leave_type'], $input['start_date'], $input['end_date'], $input['reason']]);
        echo json_encode(['status' => 'success']);
        break;

    case 'decide_leave':
        $pdo->prepare("UPDATE leave_requests SET status = ?, approved_by_user_id = ? WHERE leave_id = ?")
            ->execute([$input['decision'], $currentUser, $input['leave_id']]);
        echo json_encode(['status' => 'success']);
        break;

    case 'get_channel_messages':
        $unitId = $_GET['unit_id'] ?? 'u-nicu';
        $stmt = $pdo->prepare("SELECT * FROM channel_messages WHERE unit_id = ? ORDER BY created_at DESC LIMIT 20");
        $stmt->execute([$unitId]);
        echo json_encode($stmt->fetchAll());
        break;

    case 'post_channel_message':
        $nStmt = $pdo->prepare("SELECT first_name_en, last_name_en FROM nurses WHERE user_id = ?");
        $nStmt->execute([$currentUser]);
        $n = $nStmt->fetch();
        $sender = $n ? "{$n['first_name_en']} {$n['last_name_en']}" : "Supervisor";

        $pdo->prepare("INSERT INTO channel_messages (message_id, unit_id, user_id, title, content, patient_count, sender_name, sender_role) VALUES (UUID(), ?, ?, ?, ?, ?, ?, ?)")
            ->execute([$input['unit_id'], $currentUser, $input['title'], $input['content'], $input['patient_count'], $sender, $currentRole]);
        echo json_encode(['status' => 'success']);
        break;

    // -------------------------------------------------------------------------
    // STAGE 6: ROLLOUT WAVES & HYPERCARE DESK
    // -------------------------------------------------------------------------
    case 'get_rollout_data':
        $units = $pdo->query("SELECT u.*, d.name_en AS dept_name FROM units u JOIN departments d ON u.department_id = d.department_id ORDER BY u.rollout_wave ASC")->fetchAll();
        $tickets = $pdo->query("SELECT t.*, u.code AS unit_code FROM hypercare_tickets t JOIN units u ON t.unit_id = u.unit_id ORDER BY t.created_at DESC")->fetchAll();
        $modules = $pdo->query("SELECT * FROM training_modules")->fetchAll();
        echo json_encode(['units' => $units, 'tickets' => $tickets, 'training' => $modules]);
        break;

    case 'create_hypercare_ticket':
        $ticketNo = 'HYP-' . rand(100, 999);
        $pdo->prepare("INSERT INTO hypercare_tickets (ticket_id, ticket_number, unit_id, user_id, priority, category, title, description) VALUES (UUID(), ?, ?, ?, ?, ?, ?, ?)")
            ->execute([$ticketNo, $input['unit_id'], $currentUser, $input['priority'], $input['category'], $input['title'], $input['description']]);
        echo json_encode(['status' => 'success']);
        break;

    case 'resolve_hypercare_ticket':
        $pdo->prepare("UPDATE hypercare_tickets SET status = 'RESOLVED', resolution_notes = ? WHERE ticket_id = ?")
            ->execute([$input['resolution_notes'], $input['ticket_id']]);
        echo json_encode(['status' => 'success']);
        break;

    // -------------------------------------------------------------------------
    // STAGE 7: ANALYTICS, CSAT, GOVERNANCE & DRIFT SCANNER
    // -------------------------------------------------------------------------
    case 'get_stage7_analytics':
        $totalCerts = (int)$pdo->query("SELECT COUNT(*) FROM certifications WHERE cert_type = 'SCFHS_LICENSE'")->fetchColumn();
        $validCerts = (int)$pdo->query("SELECT COUNT(*) FROM certifications WHERE cert_type = 'SCFHS_LICENSE' AND expiry_date >= CURRENT_DATE")->fetchColumn();
        $compliance = ($totalCerts > 0) ? round(($validCerts / $totalCerts) * 100) : 100;

        $overtime = $pdo->query("
            SELECT n.first_name_en, n.last_name_en, n.employee_number, u.name_en AS unit_name,
                   COUNT(sa.assignment_id) * 12 AS scheduled_hours, c.weekly_hours_limit
            FROM nurses n
            LEFT JOIN shift_assignments sa ON n.nurse_id = sa.nurse_id AND sa.duty_code IN ('D', 'E', 'N')
            LEFT JOIN contracts c ON n.nurse_id = c.nurse_id AND c.is_active = TRUE
            LEFT JOIN units u ON n.primary_unit_id = u.unit_id
            GROUP BY n.nurse_id
        ")->fetchAll();

        $csat = $pdo->query("SELECT AVG(satisfaction_score) AS avg_csat, COUNT(*) AS count FROM user_feedback")->fetch();
        $backlog = $pdo->query("SELECT * FROM enhancement_backlog ORDER BY votes DESC")->fetchAll();
        $feedback = $pdo->query("SELECT * FROM user_feedback ORDER BY submitted_at DESC LIMIT 10")->fetchAll();

        echo json_encode([
            'compliance_rate' => $compliance,
            'overtime' => $overtime,
            'csat_avg' => round($csat['avg_csat'] ?? 4.8, 1),
            'csat_count' => (int)($csat['count'] ?? 0),
            'backlog' => $backlog,
            'feedback' => $feedback
        ]);
        break;

    case 'run_data_drift_scan':
        $anomalies = [];
        $shiftsExpired = $pdo->query("
            SELECT sa.shift_date, n.first_name_en, n.last_name_en, c.expiry_date
            FROM shift_assignments sa
            JOIN nurses n ON sa.nurse_id = n.nurse_id
            JOIN certifications c ON n.nurse_id = c.nurse_id AND c.cert_type = 'SCFHS_LICENSE'
            WHERE sa.shift_date >= CURRENT_DATE AND c.expiry_date < sa.shift_date AND sa.duty_code IN ('D', 'E', 'N')
        ")->fetchAll();
        foreach ($shiftsExpired as $s) {
            $anomalies[] = "Nurse {$s['first_name_en']} {$s['last_name_en']} rostered on {$s['shift_date']} with license expired ({$s['expiry_date']}).";
        }
        echo json_encode(['anomalies' => $anomalies]);
        break;

    case 'submit_feedback':
        $pdo->prepare("INSERT INTO user_feedback (feedback_id, user_id, role, satisfaction_score, ease_of_use_score, scheduling_fairness_score, comments) VALUES (UUID(), ?, ?, ?, 5, 5, ?)")
            ->execute([$currentUser, $currentRole, $input['score'], $input['comments']]);
        echo json_encode(['status' => 'success']);
        break;

    case 'upvote_backlog':
        $pdo->prepare("UPDATE enhancement_backlog SET votes = votes + 1 WHERE item_id = ?")->execute([$input['item_id']]);
        echo json_encode(['status' => 'success']);
        break;

    default:
        http_response_code(404);
        echo json_encode(['error' => 'Invalid endpoint action']);
        break;
}