<?php
// models/Department.php
namespace Models;

use Config\Database;
use PDO;

class Department {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function getAllWithStats(): array {
        $sql = "
            SELECT d.*, 
                   COUNT(DISTINCT u.unit_id) AS unit_count,
                   COUNT(DISTINCT n.nurse_id) AS nurse_count
            FROM departments d
            LEFT JOIN units u ON d.department_id = u.department_id
            LEFT JOIN nurses n ON (u.unit_id = n.primary_unit_id OR d.department_id = n.primary_department_id)
            GROUP BY d.department_id, d.code, d.name_en, d.name_ar
            ORDER BY d.name_en ASC
        ";
        return $this->db->query($sql)->fetchAll();
    }

    // M4/L4 FIX: Return all sub-units when dept_id is empty or 'ALL'
    public function getSubUnitsByDept(string $deptId): array {
        if (empty($deptId) || strtoupper($deptId) === 'ALL') {
            return $this->db->query("
                SELECT u.*,
                       COUNT(DISTINCT n.nurse_id) AS total_staff
                FROM units u
                LEFT JOIN nurses n ON u.unit_id = n.primary_unit_id
                GROUP BY u.unit_id
                ORDER BY u.code ASC
            ")->fetchAll();
        }

        $stmt = $this->db->prepare("
            SELECT u.*,
                   COUNT(DISTINCT n.nurse_id) AS total_staff
            FROM units u
            LEFT JOIN nurses n ON u.unit_id = n.primary_unit_id
            WHERE u.department_id = ?
            GROUP BY u.unit_id
            ORDER BY u.code ASC
        ");
        $stmt->execute([$deptId]);
        return $stmt->fetchAll();
    }

    public function saveDept(array $data): bool {
        $code = strtoupper(trim($data['code']));
        $nameEn = trim($data['name_en']);
        $nameAr = trim($data['name_ar']);

        if (!empty($data['department_id'])) {
            $stmt = $this->db->prepare("UPDATE departments SET code = ?, name_en = ?, name_ar = ? WHERE department_id = ?");
            return $stmt->execute([$code, $nameEn, $nameAr, $data['department_id']]);
        } else {
            // L6 FIX: Use 16 hex chars (64 bits) for lower collision risk
            $deptId = 'dept-' . bin2hex(random_bytes(8));
            $stmt = $this->db->prepare("INSERT INTO departments (department_id, code, name_en, name_ar) VALUES (?, ?, ?, ?)");
            return $stmt->execute([$deptId, $code, $nameEn, $nameAr]);
        }
    }

    public function saveSubUnit(array $data): bool {
        $code = strtoupper(trim($data['code']));
        $nameEn = trim($data['name_en']);
        $nameAr = trim($data['name_ar'] ?? $nameEn);
        $dayShift = (int)($data['min_staffing_day'] ?? 2);
        $nightShift = (int)($data['min_staffing_night'] ?? 2);
        $wave = $data['rollout_wave'] ?? 'PILOT';
        $status = $data['go_live_status'] ?? 'PLANNED';
        $deptId = $data['department_id'];

        if (!empty($data['unit_id'])) {
            $stmt = $this->db->prepare("
                UPDATE units 
                SET code = ?, name_en = ?, name_ar = ?, min_staffing_day = ?, min_staffing_night = ?, rollout_wave = ?, go_live_status = ?
                WHERE unit_id = ?
            ");
            return $stmt->execute([$code, $nameEn, $nameAr, $dayShift, $nightShift, $wave, $status, $data['unit_id']]);
        } else {
            // L6 FIX: Use 16 hex chars (64 bits) for lower collision risk
            $unitId = 'u-' . bin2hex(random_bytes(8));
            $stmt = $this->db->prepare("
                INSERT INTO units (unit_id, department_id, code, name_en, name_ar, min_staffing_day, min_staffing_night, rollout_wave, go_live_status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            return $stmt->execute([$unitId, $deptId, $code, $nameEn, $nameAr, $dayShift, $nightShift, $wave, $status]);
        }
    }

    public function deleteDept(string $deptId): array {
        $checkNurses = $this->db->prepare("
            SELECT COUNT(DISTINCT n.nurse_id) 
            FROM nurses n 
            LEFT JOIN units u ON n.primary_unit_id = u.unit_id 
            WHERE n.primary_department_id = ? OR u.department_id = ?
        ");
        $checkNurses->execute([$deptId, $deptId]);
        $count = (int)$checkNurses->fetchColumn();

        if ($count > 0) {
            return [
                'success' => false,
                'message' => "Regulatory Lock: Cannot delete department. There are {$count} active nurses assigned to it."
            ];
        }

        $this->db->prepare("DELETE FROM units WHERE department_id = ?")->execute([$deptId]);
        $this->db->prepare("DELETE FROM departments WHERE department_id = ?")->execute([$deptId]);
        return ['success' => true, 'message' => 'Department deleted successfully.'];
    }

    public function deleteSubUnit(string $unitId): array {
        $checkStaff = $this->db->prepare("SELECT COUNT(*) FROM nurses WHERE primary_unit_id = ?");
        $checkStaff->execute([$unitId]);
        $count = (int)$checkStaff->fetchColumn();

        if ($count > 0) {
            return [
                'success' => false,
                'message' => "Cannot delete sub-unit. There are {$count} staff nurses actively assigned to it."
            ];
        }

        $this->db->prepare("DELETE FROM units WHERE unit_id = ?")->execute([$unitId]);
        return ['success' => true, 'message' => 'Sub-unit deleted successfully.'];
    }
}