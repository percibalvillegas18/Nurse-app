<?php
// models/Operations.php
namespace Models;

use Config\Database;
use PDO;

class Operations {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function getHandovers(string $unitId): array {
        $stmt = $this->db->prepare("SELECT * FROM channel_messages WHERE unit_id = ? ORDER BY created_at DESC LIMIT 20");
        $stmt->execute([$unitId]);
        return $stmt->fetchAll();
    }

    public function createHandover(array $data): bool {
        $patientCount = (int)($data['patient_count'] ?? 0);
        $stmt = $this->db->prepare("
            INSERT INTO channel_messages (message_id, unit_id, user_id, title, content, patient_count, sender_name, sender_role) 
            VALUES (UUID(), ?, ?, ?, ?, ?, ?, ?)
        ");
        return $stmt->execute([
            $data['unit_id'],
            $data['user_id'],
            $data['title'] ?? 'Shift Handover',
            $data['content'] ?? '',
            $patientCount,
            $data['sender_name'],
            $data['sender_role']
        ]);
    }

    public function getRolloutData(): array {
        $units = $this->db->query("
            SELECT u.*, d.name_en AS dept_name 
            FROM units u 
            JOIN departments d ON u.department_id = d.department_id 
            ORDER BY u.rollout_wave ASC
        ")->fetchAll();

        $tickets = $this->db->query("
            SELECT t.*, u.code AS unit_code 
            FROM hypercare_tickets t 
            JOIN units u ON t.unit_id = u.unit_id 
            ORDER BY t.created_at DESC
        ")->fetchAll();

        return ['units' => $units, 'tickets' => $tickets];
    }

    public function createHypercareTicket(array $data): bool {
        $ticketNo = 'HYP-' . rand(100, 999);
        $stmt = $this->db->prepare("
            INSERT INTO hypercare_tickets (ticket_id, ticket_number, unit_id, user_id, priority, category, title, description) 
            VALUES (UUID(), ?, ?, ?, ?, ?, ?, ?)
        ");
        return $stmt->execute([
            $ticketNo, 
            $data['unit_id'], 
            $data['user_id'], 
            $data['priority'] ?? 'P3_MEDIUM',
            $data['category'] ?? 'ROSTER_CONFLICT', 
            $data['title'] ?? 'Untitled Issue', 
            $data['description'] ?? ''
        ]);
    }

    public function resolveHypercareTicket(string $ticketId, string $notes): bool {
        $stmt = $this->db->prepare("UPDATE hypercare_tickets SET status = 'RESOLVED', resolution_notes = ? WHERE ticket_id = ?");
        return $stmt->execute([$notes, $ticketId]);
    }

    public function getAnalytics(): array {
        $totalCerts = (int)$this->db->query("SELECT COUNT(*) FROM certifications WHERE cert_type = 'SCFHS_LICENSE'")->fetchColumn();
        $validCerts = (int)$this->db->query("SELECT COUNT(*) FROM certifications WHERE cert_type = 'SCFHS_LICENSE' AND expiry_date >= CURRENT_DATE")->fetchColumn();
        $compliance = ($totalCerts > 0) ? round(($validCerts / $totalCerts) * 100) : 100;

        // H2 FIX: Filter shifts to current week only for accurate overtime calculation
        $weekStart = date('Y-m-d', strtotime('monday this week'));
        $weekEnd = date('Y-m-d', strtotime('sunday this week'));

        $overtimeStmt = $this->db->prepare("
            SELECT n.first_name_en, n.last_name_en, n.employee_number, u.name_en AS unit_name,
                   COALESCE(COUNT(sa.assignment_id) * 12, 0) AS scheduled_hours,
                   COALESCE(c.weekly_hours_limit, 48) AS weekly_hours_limit
            FROM nurses n
            LEFT JOIN shift_assignments sa ON n.nurse_id = sa.nurse_id
                AND sa.duty_code IN ('D', 'E', 'N')
                AND sa.shift_date BETWEEN ? AND ?
            LEFT JOIN contracts c ON n.nurse_id = c.nurse_id AND c.is_active = TRUE
            LEFT JOIN units u ON n.primary_unit_id = u.unit_id
            GROUP BY n.nurse_id, n.first_name_en, n.last_name_en, n.employee_number, u.name_en, c.weekly_hours_limit
        ");
        $overtimeStmt->execute([$weekStart, $weekEnd]);
        $overtime = $overtimeStmt->fetchAll();

        $csat = $this->db->query("SELECT AVG(satisfaction_score) AS avg_csat, COUNT(*) AS count FROM user_feedback")->fetch();

        return [
            'compliance_rate' => $compliance,
            'overtime' => $overtime,
            'csat_avg' => round((float)($csat['avg_csat'] ?? 4.8), 1),
            'csat_count' => (int)($csat['count'] ?? 0)
        ];
    }

    public function checkDrift(): array {
        $shiftsExpired = $this->db->query("
            SELECT sa.shift_date, n.first_name_en, n.last_name_en, c.expiry_date
            FROM shift_assignments sa
            JOIN nurses n ON sa.nurse_id = n.nurse_id
            JOIN certifications c ON n.nurse_id = c.nurse_id AND c.cert_type = 'SCFHS_LICENSE'
            WHERE sa.shift_date >= CURRENT_DATE 
              AND c.expiry_date < sa.shift_date 
              AND sa.duty_code IN ('D', 'E', 'N')
        ")->fetchAll();

        $anomalies = [];
        foreach ($shiftsExpired as $s) {
            $anomalies[] = "Nurse {$s['first_name_en']} {$s['last_name_en']} rostered on {$s['shift_date']} with expired license ({$s['expiry_date']}).";
        }
        return $anomalies;
    }

    public function runSweep(): int {
        $certs = $this->db->query("
            SELECT c.*, n.first_name_en, n.last_name_en, n.user_id, DATEDIFF(c.expiry_date, CURRENT_DATE) AS days_left
            FROM certifications c
            JOIN nurses n ON c.nurse_id = n.nurse_id
            WHERE c.expiry_date <= DATE_ADD(CURRENT_DATE, INTERVAL 30 DAY)
        ")->fetchAll();

        $count = 0;
        foreach ($certs as $c) {
            // H3 FIX: Check for existing CERT_EXPIRY notification for this nurse within last 7 days
            $existingCheck = $this->db->prepare("
                SELECT COUNT(*) FROM notifications
                WHERE user_id = ? AND category = 'CERT_EXPIRY'
                  AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
            ");
            $existingCheck->execute([$c['user_id']]);
            if ((int)$existingCheck->fetchColumn() > 0) {
                continue; // Skip — already notified recently
            }

            $isExpired = $c['days_left'] < 0;
            $titleEn = $isExpired ? "CRITICAL: SCFHS License Expired" : "Urgent: License Expiry in {$c['days_left']} Days";
            $titleAr = $isExpired ? "تنبيه: انتهاء ترخيص هيئة التخصصات" : "تنبيه: اقتراب انتهاء الترخيص خلال {$c['days_left']} يوم";
            $msgEn = "License #{$c['credential_number']} for {$c['first_name_en']} {$c['last_name_en']} requires renewal.";
            $msgAr = "ترخيص #{$c['credential_number']} للممرض يتطلب التجديد الفوري.";

            $this->db->prepare("
                INSERT INTO notifications (notification_id, user_id, channel, category, title_en, title_ar, message_en, message_ar)
                VALUES (UUID(), ?, 'IN_APP', 'CERT_EXPIRY', ?, ?, ?, ?)
            ")->execute([$c['user_id'], $titleEn, $titleAr, $msgEn, $msgAr]);
            $count++;
        }
        return $count;
    }

    // M7 FIX: Add upvote method for enhancement backlog
    public function upvoteBacklog(int $itemId): bool {
        $stmt = $this->db->prepare("UPDATE enhancement_backlog SET votes = votes + 1 WHERE item_id = ?");
        return $stmt->execute([$itemId]);
    }

    // M8 FIX: Add get notifications method
    public function getNotifications(string $userId): array {
        $stmt = $this->db->prepare("
            SELECT * FROM notifications
            WHERE user_id = ?
            ORDER BY created_at DESC
            LIMIT 50
        ");
        $stmt->execute([$userId]);
        return $stmt->fetchAll();
    }
}