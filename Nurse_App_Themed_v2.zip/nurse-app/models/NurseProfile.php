<?php
namespace Models;

use Config\Database;
use PDO;

class NurseProfile {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function getAll(): array {
        return $this->db->query("
            SELECT profile_id, full_name, gender, date_of_birth, nationality,
                   identification_type, identification_number, phone_number,
                   email, scfhs_details, mumaris_id, created_at
            FROM nurse_profiles
            ORDER BY created_at DESC
        ")->fetchAll();
    }

    public function create(array $data, array $documents): string {
        $profileId = 'np-' . bin2hex(random_bytes(16));
        $this->db->beginTransaction();
        try {
            $stmt = $this->db->prepare("
                INSERT INTO nurse_profiles (
                    profile_id, full_name, gender, date_of_birth, nationality,
                    identification_type, identification_number, passport_number,
                    passport_issue_date, passport_expiry_date, passport_place_of_issue,
                    home_address, phone_number, email, emergency_contact_name,
                    emergency_contact_relation, emergency_contact_phone, nursing_degrees,
                    professional_licenses, scfhs_details, employment_history, mumaris_id,
                    created_by_user_id
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ");
            $stmt->execute([
                $profileId, $data['full_name'], $data['gender'], $data['date_of_birth'],
                $data['nationality'], $data['identification_type'], $data['identification_number'],
                $data['passport_number'], $data['passport_issue_date'], $data['passport_expiry_date'],
                $data['passport_place_of_issue'], $data['home_address'], $data['phone_number'],
                $data['email'], $data['emergency_contact_name'], $data['emergency_contact_relation'],
                $data['emergency_contact_phone'], $data['nursing_degrees'],
                $data['professional_licenses'], $data['scfhs_details'], $data['employment_history'],
                $data['mumaris_id'], $data['created_by_user_id']
            ]);

            $docStmt = $this->db->prepare("
                INSERT INTO nurse_profile_documents
                    (document_id, profile_id, document_type, original_name, stored_name, mime_type, file_size)
                VALUES (UUID(), ?, ?, ?, ?, ?, ?)
            ");
            foreach ($documents as $document) {
                $docStmt->execute([
                    $profileId, $document['document_type'], $document['original_name'],
                    $document['stored_name'], $document['mime_type'], $document['file_size']
                ]);
            }

            $this->db->commit();
            return $profileId;
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            throw $e;
        }
    }
}
