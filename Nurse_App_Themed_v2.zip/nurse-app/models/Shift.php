<?php
// models/Shift.php
namespace Models;

use Config\Database;
use PDO;

class Shift {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function getMatrix(string $unitId, string $start, string $end): array {
        $stmt = $this->db->prepare("
            SELECT sa.*, n.first_name_en, n.last_name_en, n.employee_number, n.first_name_ar, n.last_name_ar
            FROM shift_assignments sa
            JOIN nurses n ON sa.nurse_id = n.nurse_id
            WHERE sa.unit_id = ? AND sa.shift_date BETWEEN ? AND ?
            ORDER BY sa.shift_date ASC, n.employee_number ASC
        ");
        $stmt->execute([$unitId, $start, $end]);
        $shifts = $stmt->fetchAll();

        $nurses = $this->db->prepare("SELECT * FROM nurses WHERE primary_unit_id = ?");
        $nurses->execute([$unitId]);

        $open = $this->db->prepare("SELECT * FROM shift_assignments WHERE unit_id = ? AND is_open_shift = TRUE AND shift_date BETWEEN ? AND ?");
        $open->execute([$unitId, $start, $end]);

        return [
            'shifts' => $shifts,
            'nurses' => $nurses->fetchAll(),
            'open_shifts' => $open->fetchAll()
        ];
    }

    public function assign(string $nurseId, string $unitId, string $date, string $code): bool {
        // H1 FIX: Proper time windows for each duty code
        switch ($code) {
            case 'D': // Day shift: 07:00 – 19:00
                $startTime = "$date 07:00:00";
                $endTime = "$date 19:00:00";
                break;
            case 'E': // Evening shift: 15:00 – 23:00
                $startTime = "$date 15:00:00";
                $endTime = "$date 23:00:00";
                break;
            case 'N': // Night shift: 19:00 – 07:00 (next day)
                $startTime = "$date 19:00:00";
                $endTime = date('Y-m-d 07:00:00', strtotime("$date +1 day"));
                break;
            default: // AL, X, or other non-active codes
                $startTime = "$date 00:00:00";
                $endTime = "$date 23:59:59";
                break;
        }

        // H5 FIX: Wrap DELETE+INSERT in a transaction for atomicity
        $this->db->beginTransaction();
        try {
            $this->db->prepare("DELETE FROM shift_assignments WHERE nurse_id = ? AND shift_date = ?")->execute([$nurseId, $date]);
            $stmt = $this->db->prepare("
                INSERT INTO shift_assignments (assignment_id, nurse_id, unit_id, shift_date, start_time, end_time, duty_code, status, is_published)
                VALUES (UUID(), ?, ?, ?, ?, ?, ?, 'SCHEDULED', FALSE)
            ");
            $result = $stmt->execute([$nurseId, $unitId, $date, $startTime, $endTime, $code]);
            $this->db->commit();
            return $result;
        } catch (\Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    public function publish(string $unitId): int {
        $stmt = $this->db->prepare("UPDATE shift_assignments SET is_published = TRUE WHERE unit_id = ?");
        $stmt->execute([$unitId]);
        return $stmt->rowCount();
    }

    public function claimOpenShift(string $assignmentId, string $nurseId): bool {
        $stmt = $this->db->prepare("
            UPDATE shift_assignments 
            SET nurse_id = ?, is_open_shift = FALSE, status = 'CONFIRMED' 
            WHERE assignment_id = ?
        ");
        return $stmt->execute([$nurseId, $assignmentId]);
    }
}