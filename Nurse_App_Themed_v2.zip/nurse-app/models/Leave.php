<?php
// models/Leave.php
namespace Models;

use Config\Database;
use PDO;

class Leave {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function getAll(): array {
        return $this->db->query("
            SELECT lr.*, n.first_name_en, n.last_name_en, n.employee_number 
            FROM leave_requests lr 
            JOIN nurses n ON lr.nurse_id = n.nurse_id 
            ORDER BY lr.created_at DESC
        ")->fetchAll();
    }

    public function checkConflict(string $nurseId, string $date): ?array {
        $stmt = $this->db->prepare("
            SELECT * FROM leave_requests 
            WHERE nurse_id = ? 
              AND status = 'APPROVED' 
              AND start_date <= ? 
              AND end_date >= ?
            LIMIT 1
        ");
        $stmt->execute([$nurseId, $date, $date]);
        return $stmt->fetch() ?: null;
    }

    public function create(string $nurseId, string $type, string $start, string $end, ?string $reason): bool {
        $stmt = $this->db->prepare("
            INSERT INTO leave_requests (leave_id, nurse_id, leave_type, start_date, end_date, reason) 
            VALUES (UUID(), ?, ?, ?, ?, ?)
        ");
        return $stmt->execute([$nurseId, $type, $start, $end, $reason]);
    }

    public function decide(string $leaveId, string $decision, string $approverId): bool {
        $stmt = $this->db->prepare("
            UPDATE leave_requests 
            SET status = ?, approved_by_user_id = ? 
            WHERE leave_id = ?
        ");
        return $stmt->execute([$decision, $approverId, $leaveId]);
    }
}