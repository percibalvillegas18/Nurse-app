<?php
// models/Nurse.php
namespace Models;

use Config\Database;
use PDO;

class Nurse {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    public function getAll(): array {
        $sql = "
            SELECT n.*, u.name_en AS unit_name_en, u.name_ar AS unit_name_ar,
                   c.credential_number, c.expiry_date,
                   DATEDIFF(c.expiry_date, CURRENT_DATE) AS days_to_expiry,
                   (SELECT weekly_hours_limit FROM contracts WHERE nurse_id = n.nurse_id AND is_active = TRUE LIMIT 1) AS weekly_limit
            FROM nurses n
            LEFT JOIN units u ON n.primary_unit_id = u.unit_id
            LEFT JOIN certifications c ON n.nurse_id = c.nurse_id AND c.cert_type = 'SCFHS_LICENSE'
            ORDER BY n.employee_number ASC
        ";
        return $this->db->query($sql)->fetchAll();
    }

    public function findById(string $nurseId): ?array {
        $stmt = $this->db->prepare("SELECT * FROM nurses WHERE nurse_id = ?");
        $stmt->execute([$nurseId]);
        return $stmt->fetch() ?: null;
    }

    public function findByUserId(string $userId): ?array {
        $stmt = $this->db->prepare("SELECT * FROM nurses WHERE user_id = ?");
        $stmt->execute([$userId]);
        return $stmt->fetch() ?: null;
    }

    public function create(array $data): string {
        // L6 FIX: Use proper UUIDv4-style IDs (16 hex = 64 bits, much lower collision risk)
        $nurseId = 'n-' . bin2hex(random_bytes(8));
        $userId = 'u-' . bin2hex(random_bytes(8));

        // C4 FIX: Generate a unique random temporary password per user instead of hardcoded hash
        $tempPassword = bin2hex(random_bytes(8)); // 16-char random temporary password
        $passwordHash = password_hash($tempPassword, PASSWORD_BCRYPT);

        $this->db->prepare("
            INSERT INTO users (user_id, email, password_hash, role)
            VALUES (?, ?, ?, 'STAFF_NURSE')
        ")->execute([$userId, strtolower($data['employee_number']) . '@hospital.sa', $passwordHash]);

        $stmt = $this->db->prepare("
            INSERT INTO nurses (nurse_id, user_id, employee_number, first_name_en, last_name_en, first_name_ar, last_name_ar, identification_type, identification_number, phone_number, primary_unit_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $nurseId, $userId, $data['employee_number'], $data['first_name_en'], $data['last_name_en'],
            $data['first_name_ar'], $data['last_name_ar'], $data['identification_type'], $data['identification_number'],
            $data['phone_number'], $data['primary_unit_id']
        ]);

        $this->db->prepare("
            INSERT INTO contracts (contract_id, nurse_id, contract_type, start_date, weekly_hours_limit) 
            VALUES (UUID(), ?, 'INDEFINITE', CURRENT_DATE, 48)
        ")->execute([$nurseId]);

        return $nurseId;
    }

    public function update(string $nurseId, array $data): bool {
        $stmt = $this->db->prepare("
            UPDATE nurses 
            SET first_name_en = ?, last_name_en = ?, first_name_ar = ?, last_name_ar = ?,
                identification_type = ?, identification_number = ?, phone_number = ?, primary_unit_id = ?
            WHERE nurse_id = ?
        ");
        return $stmt->execute([
            $data['first_name_en'], $data['last_name_en'], $data['first_name_ar'], $data['last_name_ar'],
            $data['identification_type'], $data['identification_number'], $data['phone_number'],
            $data['primary_unit_id'], $nurseId
        ]);
    }

    public function getLicenseExpiry(string $nurseId): ?string {
        $stmt = $this->db->prepare("SELECT expiry_date FROM certifications WHERE nurse_id = ? AND cert_type = 'SCFHS_LICENSE'");
        $stmt->execute([$nurseId]);
        $row = $stmt->fetch();
        return $row ? $row['expiry_date'] : null;
    }
}