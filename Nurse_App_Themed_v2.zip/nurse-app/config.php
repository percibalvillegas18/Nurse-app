<?php
// config.php - Unified Configuration
// L2 FIX: Consolidated to use Config\Database as the single connection source.
// This file is kept for backward compatibility (api.php) but now delegates to Database.php.

require_once __DIR__ . '/config/Database.php';

/**
 * @deprecated Use Config\Database::getConnection() directly.
 */
function getDB() {
    return \Config\Database::getConnection();
}

// Only set headers/session if not already done by index.php
if (!headers_sent()) {
    header('Content-Type: application/json; charset=utf-8');
}
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
