-- Nurse App Themed v2: extended nurse onboarding/data-entry records
CREATE TABLE IF NOT EXISTS nurse_profiles (
    profile_id VARCHAR(67) PRIMARY KEY,
    full_name VARCHAR(200) NOT NULL,
    gender ENUM('MALE','FEMALE','OTHER') NOT NULL,
    date_of_birth DATE NOT NULL,
    nationality CHAR(2) NOT NULL,
    identification_type ENUM('NATIONAL_ID','IQAMA') NOT NULL,
    identification_number VARCHAR(10) NOT NULL UNIQUE,
    passport_number VARCHAR(30) NULL,
    passport_issue_date DATE NULL,
    passport_expiry_date DATE NULL,
    passport_place_of_issue VARCHAR(120) NULL,
    home_address TEXT NOT NULL,
    phone_number VARCHAR(30) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    emergency_contact_name VARCHAR(200) NOT NULL,
    emergency_contact_relation VARCHAR(100) NOT NULL,
    emergency_contact_phone VARCHAR(30) NOT NULL,
    nursing_degrees TEXT NULL,
    professional_licenses TEXT NULL,
    scfhs_details TEXT NULL,
    employment_history TEXT NULL,
    mumaris_id VARCHAR(100) NULL,
    created_by_user_id VARCHAR(67) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_nurse_profiles_name (full_name),
    INDEX idx_nurse_profiles_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS nurse_profile_documents (
    document_id VARCHAR(36) PRIMARY KEY,
    profile_id VARCHAR(67) NOT NULL,
    document_type VARCHAR(40) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    stored_name VARCHAR(255) NOT NULL UNIQUE,
    mime_type VARCHAR(80) NOT NULL,
    file_size INT UNSIGNED NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_profile_documents_profile (profile_id),
    CONSTRAINT fk_profile_documents_profile FOREIGN KEY (profile_id)
        REFERENCES nurse_profiles(profile_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
