<?php
// index.php - Front Controller & Router
session_start();

// --- C3 FIX: Generate CSRF token if not present ---
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// PSR-4 style autoloader
spl_autoload_register(function ($class) {
    $prefixMap = [
        'Config\\' => __DIR__ . '/config/',
        'Models\\' => __DIR__ . '/models/',
        'Controllers\\' => __DIR__ . '/controllers/'
    ];

    foreach ($prefixMap as $prefix => $baseDir) {
        $len = strlen($prefix);
        if (strncmp($prefix, $class, $len) === 0) {
            $relativeClass = substr($class, $len);
            $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';
            if (file_exists($file)) {
                require $file;
                return;
            }
        }
    }
});

use Controllers\NurseController;
use Controllers\ShiftController;
use Controllers\LeaveController;
use Controllers\OperationsController;
use Controllers\DepartmentController;
use Controllers\NurseProfileController;

$action = $_GET['action'] ?? null;

// If no action is specified, render the main View
if (!$action) {
    require __DIR__ . '/views/dashboard.php';
    exit;
}

header('Content-Type: application/json; charset=utf-8');

// --- C2 FIX: Authentication check — require valid session for API calls ---
$currentUser = $_SESSION['user_id'] ?? null;
$currentRole = $_SESSION['role'] ?? null;

if (!$currentUser || !$currentRole) {
    // Allow switch_user to bootstrap a session (acts as a lightweight login)
    if ($action !== 'switch_user') {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized: Please log in to access the system.']);
        exit;
    }
    // Default for switch_user when no session exists
    $currentUser = 'u-head-1';
    $currentRole = 'HEAD_NURSE';
}

// --- C3 FIX: CSRF validation for all POST requests ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrfHeader = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'], $csrfHeader)) {
        http_response_code(403);
        echo json_encode(['error' => 'CSRF token validation failed. Please refresh the page.']);
        exit;
    }
}

$input = json_decode(file_get_contents('php://input'), true) ?? [];

// Global Session Switcher Action
if ($action === 'switch_user') {
    $role = $input['role'] ?? 'HEAD_NURSE';
    if (!in_array($role, ['HEAD_NURSE', 'STAFF_NURSE'], true)) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid role specified.']);
        exit;
    }
    $_SESSION['user_id'] = ($role === 'HEAD_NURSE') ? 'u-head-1' : 'u-nurse-2';
    $_SESSION['role'] = $role;
    echo json_encode(['status' => 'success', 'role' => $role]);
    exit;
}

// Controller Routing
switch ($action) {
    // -------------------------------------------------------------------------
    // Department Controller (Add / Edit / Delete / Units)
    // -------------------------------------------------------------------------
    case 'get_departments':
        (new DepartmentController())->index();
        break;
    case 'get_sub_units':
        (new DepartmentController())->subUnits();
        break;
    case 'save_department':
        (new DepartmentController())->saveDept($input, $currentRole);
        break;
    case 'save_sub_unit':
        (new DepartmentController())->saveSubUnit($input, $currentRole);
        break;
    case 'delete_department':
        (new DepartmentController())->deleteDept($input, $currentRole);
        break;
    case 'delete_sub_unit':
        (new DepartmentController())->deleteSubUnit($input, $currentRole);
        break;

    // -------------------------------------------------------------------------
    // Nurse Controller
    // -------------------------------------------------------------------------
    case 'get_nurses':
        (new NurseController())->index();
        break;
    case 'save_nurse':
        (new NurseController())->save($input, $currentRole);
        break;
    case 'get_nurse_profiles':
        (new NurseProfileController())->index($currentRole);
        break;
    case 'save_nurse_profile':
        (new NurseProfileController())->save($_POST, $_FILES, $currentUser, $currentRole);
        break;

    // -------------------------------------------------------------------------
    // Shift Controller
    // -------------------------------------------------------------------------
    case 'get_shifts_matrix':
        (new ShiftController())->matrix($_GET);
        break;
    case 'save_shift_cell':
        (new ShiftController())->assign($input, $currentRole);
        break;
    case 'publish_unit_schedule':
        (new ShiftController())->publish($input, $currentRole);
        break;
    case 'claim_open_shift':
        (new ShiftController())->claim($input, $currentUser);
        break;

    // -------------------------------------------------------------------------
    // Leave Controller
    // -------------------------------------------------------------------------
    case 'get_leaves':
        (new LeaveController())->index();
        break;
    case 'submit_leave':
        (new LeaveController())->submit($input, $currentUser);
        break;
    case 'decide_leave':
        (new LeaveController())->decide($input, $currentUser, $currentRole);
        break;

    // -------------------------------------------------------------------------
    // Operations & Telemetry Controller
    // -------------------------------------------------------------------------
    case 'get_channel_messages':
        (new OperationsController())->handovers($_GET['unit_id'] ?? 'u-nicu');
        break;
    case 'post_channel_message':
        (new OperationsController())->submitHandover($input, $currentUser, $currentRole);
        break;
    case 'get_rollout_data':
        (new OperationsController())->rollout();
        break;
    case 'create_hypercare_ticket':
        (new OperationsController())->createTicket($input, $currentUser);
        break;
    case 'resolve_hypercare_ticket':
        (new OperationsController())->resolveTicket($input);
        break;
    case 'get_stage7_analytics':
        (new OperationsController())->analytics();
        break;
    case 'run_data_drift_scan':
        (new OperationsController())->drift();
        break;
    case 'run_automated_sweep':
        (new OperationsController())->sweep();
        break;
    case 'submit_feedback':
        (new OperationsController())->submitFeedback($input, $currentUser, $currentRole);
        break;

    // --- M7 FIX: Add upvote_backlog route ---
    case 'upvote_backlog':
        (new OperationsController())->upvoteBacklog($input);
        break;

    // --- M8 FIX: Add get_notifications route ---
    case 'get_notifications':
        (new OperationsController())->getNotifications($currentUser);
        break;

    default:
        http_response_code(404);
        echo json_encode(['error' => 'Action route not found.']);
        break;
}
