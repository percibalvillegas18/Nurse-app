<?php
// controllers/OperationsController.php
namespace Controllers;

use Models\Operations;
use Models\Nurse;

class OperationsController {
    private Operations $opsModel;
    private Nurse $nurseModel;

    public function __construct() {
        $this->opsModel = new Operations();
        $this->nurseModel = new Nurse();
    }

    public function handovers(string $unitId): void {
        echo json_encode($this->opsModel->getHandovers($unitId));
    }

    public function submitHandover(array $input, string $userId, string $role): void {
        $nurse = $this->nurseModel->findByUserId($userId);
        $input['user_id'] = $userId;
        $input['sender_name'] = $nurse ? "{$nurse['first_name_en']} {$nurse['last_name_en']}" : "Supervisor";
        $input['sender_role'] = $role;

        $this->opsModel->createHandover($input);
        echo json_encode(['status' => 'success']);
    }

    public function rollout(): void {
        echo json_encode($this->opsModel->getRolloutData());
    }

    public function createTicket(array $input, string $userId): void {
        $input['user_id'] = $userId;
        $this->opsModel->createHypercareTicket($input);
        echo json_encode(['status' => 'success']);
    }

    public function resolveTicket(array $input): void {
        $notes = $input['resolution_notes'] ?? 'Resolved in clinical huddle.';
        $ticketId = $input['ticket_id'] ?? '';
        $this->opsModel->resolveHypercareTicket($ticketId, $notes);
        echo json_encode(['status' => 'success']);
    }

    public function analytics(): void {
        echo json_encode($this->opsModel->getAnalytics());
    }

    public function drift(): void {
        echo json_encode(['anomalies' => $this->opsModel->checkDrift()]);
    }

    public function sweep(): void {
        $count = $this->opsModel->runSweep();
        echo json_encode(['status' => 'success', 'dispatched' => $count]);
    }

    // M7 FIX: Add upvote backlog controller method
    public function upvoteBacklog(array $input): void {
        $itemId = (int)($input['item_id'] ?? 0);
        if ($itemId <= 0) {
            http_response_code(400);
            echo json_encode(['error' => 'Valid item_id is required.']);
            return;
        }
        $this->opsModel->upvoteBacklog($itemId);
        echo json_encode(['status' => 'success']);
    }

    // M8 FIX: Add get notifications controller method
    public function getNotifications(string $userId): void {
        echo json_encode($this->opsModel->getNotifications($userId));
    }

    public function submitFeedback(array $input, string $userId, string $role): void {
        $db = \Config\Database::getConnection();
        $stmt = $db->prepare("
            INSERT INTO user_feedback (feedback_id, user_id, role, satisfaction_score, ease_of_use_score, scheduling_fairness_score, comments) 
            VALUES (UUID(), ?, ?, ?, 5, 5, ?)
        ");
        $stmt->execute([$userId, $role, (int)($input['score'] ?? 5), $input['comments'] ?? '']);
        echo json_encode(['status' => 'success']);
    }
}