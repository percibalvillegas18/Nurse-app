<?php
// controllers/ShiftController.php
namespace Controllers;

use Models\Shift;
use Models\Nurse;
use Models\Leave;

class ShiftController {
    private Shift $shiftModel;
    private Nurse $nurseModel;
    private Leave $leaveModel;

    public function __construct() {
        $this->shiftModel = new Shift();
        $this->nurseModel = new Nurse();
        $this->leaveModel = new Leave();
    }

    public function matrix(array $params): void {
        $unitId = $params['unit_id'] ?? 'u-nicu';
        $start = $params['start_date'] ?? date('Y-m-d', strtotime('-1 days'));
        $end = $params['end_date'] ?? date('Y-m-d', strtotime('+5 days'));

        echo json_encode($this->shiftModel->getMatrix($unitId, $start, $end));
    }

    public function assign(array $input, string $role): void {
        if ($role === 'STAFF_NURSE') {
            http_response_code(403);
            echo json_encode(['error' => 'Permission denied: Staff Nurses cannot edit rosters directly.']);
            return;
        }

        // L3 FIX: Validate required fields
        $nurseId = $input['nurse_id'] ?? '';
        $unitId = $input['unit_id'] ?? '';
        $date = $input['shift_date'] ?? '';
        $code = strtoupper(trim($input['duty_code'] ?? 'D'));

        if (empty($nurseId) || empty($unitId) || empty($date)) {
            http_response_code(422);
            echo json_encode(['error' => 'nurse_id, unit_id, and shift_date are required.']);
            return;
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || !strtotime($date)) {
            http_response_code(422);
            echo json_encode(['error' => 'Invalid shift_date format. Use YYYY-MM-DD.']);
            return;
        }
        if (!in_array($code, ['D', 'E', 'N', 'AL', 'X'], true)) {
            http_response_code(422);
            echo json_encode(['error' => 'Invalid duty_code. Must be D, E, N, AL, or X.']);
            return;
        }

        if (in_array($code, ['D', 'E', 'N'])) {
            // Check SCFHS Expiry
            $expiry = $this->nurseModel->getLicenseExpiry($nurseId);
            if ($expiry && strtotime($expiry) < strtotime($date)) {
                http_response_code(422);
                echo json_encode(['error' => "SCFHS LICENSE EXPIRED: Nurse license expired on {$expiry}. Assignment blocked."]);
                return;
            }

            // Check Approved Leave Conflict
            $conflict = $this->leaveModel->checkConflict($nurseId, $date);
            if ($conflict) {
                http_response_code(422);
                echo json_encode(['error' => "LEAVE CONFLICT: Nurse is on approved {$conflict['leave_type']} leave."]);
                return;
            }
        }

        $this->shiftModel->assign($nurseId, $unitId, $date, $code);
        echo json_encode(['status' => 'success']);
    }

    // H6 FIX: Add role check to publish — only HEAD_NURSE can publish schedules
    public function publish(array $input, string $role = 'HEAD_NURSE'): void {
        if ($role === 'STAFF_NURSE') {
            http_response_code(403);
            echo json_encode(['error' => 'Permission denied: Only Head Nurses can publish unit schedules.']);
            return;
        }
        $count = $this->shiftModel->publish($input['unit_id']);
        echo json_encode(['status' => 'success', 'count' => $count]);
    }

    public function claim(array $input, string $userId): void {
        $nurse = $this->nurseModel->findByUserId($userId);
        if (!$nurse) {
            http_response_code(400);
            echo json_encode(['error' => 'No nurse profile linked to current user.']);
            return;
        }

        // H4 FIX: Validate SCFHS license expiry and leave conflicts before claiming
        $assignmentId = $input['assignment_id'] ?? '';

        // Fetch the open shift details to get the shift date
        $db = \Config\Database::getConnection();
        $shiftStmt = $db->prepare("SELECT * FROM shift_assignments WHERE assignment_id = ? AND is_open_shift = TRUE");
        $shiftStmt->execute([$assignmentId]);
        $openShift = $shiftStmt->fetch();

        if (!$openShift) {
            http_response_code(400);
            echo json_encode(['error' => 'Open shift not found or already claimed.']);
            return;
        }

        $shiftDate = $openShift['shift_date'];
        $dutyCode = $openShift['duty_code'];

        // Only validate for active clinical shifts (D, E, N)
        if (in_array($dutyCode, ['D', 'E', 'N'])) {
            // Check SCFHS License Expiry
            $expiry = $this->nurseModel->getLicenseExpiry($nurse['nurse_id']);
            if ($expiry && strtotime($expiry) < strtotime($shiftDate)) {
                http_response_code(422);
                echo json_encode(['error' => "SCFHS LICENSE EXPIRED: Your license expired on {$expiry}. Cannot claim this shift."]);
                return;
            }

            // Check Approved Leave Conflict
            $conflict = $this->leaveModel->checkConflict($nurse['nurse_id'], $shiftDate);
            if ($conflict) {
                http_response_code(422);
                echo json_encode(['error' => "LEAVE CONFLICT: You have approved {$conflict['leave_type']} leave on this date."]);
                return;
            }

            // Check for double-booking (already rostered on that date)
            $existingStmt = $db->prepare("SELECT COUNT(*) FROM shift_assignments WHERE nurse_id = ? AND shift_date = ? AND assignment_id != ?");
            $existingStmt->execute([$nurse['nurse_id'], $shiftDate, $assignmentId]);
            if ((int)$existingStmt->fetchColumn() > 0) {
                http_response_code(422);
                echo json_encode(['error' => 'SCHEDULE CONFLICT: You are already rostered on this date.']);
                return;
            }
        }

        $this->shiftModel->claimOpenShift($assignmentId, $nurse['nurse_id']);
        echo json_encode(['status' => 'success']);
    }
}