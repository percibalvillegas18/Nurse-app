<?php
// controllers/DepartmentController.php
namespace Controllers;

use Models\Department;

class DepartmentController {
    private Department $model;

    public function __construct() {
        $this->model = new Department();
    }

    public function index(): void {
        echo json_encode($this->model->getAllWithStats());
    }

    public function subUnits(): void {
        $deptId = $_GET['dept_id'] ?? '';
        echo json_encode($this->model->getSubUnitsByDept($deptId));
    }

    public function saveDept(array $input, string $role): void {
        if ($role !== 'HEAD_NURSE') {
            http_response_code(403);
            echo json_encode(['error' => 'Permission denied: Only Head Nurses can modify departments.']);
            return;
        }

        if (empty($input['code']) || empty($input['name_en']) || empty($input['name_ar'])) {
            http_response_code(422);
            echo json_encode(['error' => 'Dept Code, English Name, and Arabic Name are required.']);
            return;
        }

        $this->model->saveDept($input);
        echo json_encode(['status' => 'success']);
    }

    public function saveSubUnit(array $input, string $role): void {
        if ($role !== 'HEAD_NURSE') {
            http_response_code(403);
            echo json_encode(['error' => 'Permission denied: Only Head Nurses can add/edit sub-units.']);
            return;
        }

        if (empty($input['department_id']) || empty($input['code']) || empty($input['name_en'])) {
            http_response_code(422);
            echo json_encode(['error' => 'Parent Department, Unit Code, and Name are required.']);
            return;
        }

        $this->model->saveSubUnit($input);
        echo json_encode(['status' => 'success']);
    }

    public function deleteDept(array $input, string $role): void {
        if ($role !== 'HEAD_NURSE') {
            http_response_code(403);
            echo json_encode(['error' => 'Permission denied: Only Head Nurses can delete departments.']);
            return;
        }

        $res = $this->model->deleteDept($input['department_id'] ?? '');
        if (!$res['success']) {
            http_response_code(400);
            echo json_encode(['error' => $res['message']]);
            return;
        }
        echo json_encode(['status' => 'success', 'message' => $res['message']]);
    }

    public function deleteSubUnit(array $input, string $role): void {
        if ($role !== 'HEAD_NURSE') {
            http_response_code(403);
            echo json_encode(['error' => 'Permission denied.']);
            return;
        }

        $res = $this->model->deleteSubUnit($input['unit_id'] ?? '');
        if (!$res['success']) {
            http_response_code(400);
            echo json_encode(['error' => $res['message']]);
            return;
        }
        echo json_encode(['status' => 'success', 'message' => $res['message']]);
    }
}