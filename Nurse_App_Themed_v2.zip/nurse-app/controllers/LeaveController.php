<?php
// controllers/LeaveController.php
namespace Controllers;

use Models\Leave;
use Models\Nurse;

class LeaveController {
    private Leave $leaveModel;
    private Nurse $nurseModel;

    public function __construct() {
        $this->leaveModel = new Leave();
        $this->nurseModel = new Nurse();
    }

    public function index(): void {
        echo json_encode($this->leaveModel->getAll());
    }

    public function submit(array $input, string $userId): void {
        $nurse = $this->nurseModel->findByUserId($userId);
        if (!$nurse) {
            http_response_code(400);
            echo json_encode(['error' => 'No nurse profile linked to current user.']);
            return;
        }

        // L3 FIX: Validate required fields and formats
        $leaveType = $input['leave_type'] ?? '';
        $startDate = $input['start_date'] ?? '';
        $endDate = $input['end_date'] ?? '';

        if (!in_array($leaveType, ['ANNUAL', 'SICK', 'HAJJ'], true)) {
            http_response_code(422);
            echo json_encode(['error' => 'Invalid leave type. Must be ANNUAL, SICK, or HAJJ.']);
            return;
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $startDate) || !strtotime($startDate)) {
            http_response_code(422);
            echo json_encode(['error' => 'Invalid start_date format. Use YYYY-MM-DD.']);
            return;
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $endDate) || !strtotime($endDate)) {
            http_response_code(422);
            echo json_encode(['error' => 'Invalid end_date format. Use YYYY-MM-DD.']);
            return;
        }
        if (strtotime($endDate) < strtotime($startDate)) {
            http_response_code(422);
            echo json_encode(['error' => 'end_date cannot be before start_date.']);
            return;
        }

        $this->leaveModel->create(
            $nurse['nurse_id'],
            $leaveType,
            $startDate,
            $endDate,
            $input['reason'] ?? ''
        );
        echo json_encode(['status' => 'success']);
    }

    public function decide(array $input, string $userId, string $role): void {
        if ($role !== 'HEAD_NURSE') {
            http_response_code(403);
            echo json_encode(['error' => 'Permission denied: Only Head Nurses can authorize leaves.']);
            return;
        }

        // L3 FIX: Validate decision input
        $leaveId = $input['leave_id'] ?? '';
        $decision = $input['decision'] ?? '';

        if (empty($leaveId)) {
            http_response_code(422);
            echo json_encode(['error' => 'leave_id is required.']);
            return;
        }
        if (!in_array($decision, ['APPROVED', 'REJECTED'], true)) {
            http_response_code(422);
            echo json_encode(['error' => 'Decision must be APPROVED or REJECTED.']);
            return;
        }

        $this->leaveModel->decide($leaveId, $decision, $userId);
        echo json_encode(['status' => 'success']);
    }
}