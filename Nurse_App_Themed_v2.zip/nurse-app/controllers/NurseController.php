<?php
// controllers/NurseController.php
namespace Controllers;

use Models\Nurse;
use PDOException;

class NurseController {
    private Nurse $model;

    public function __construct() {
        $this->model = new Nurse();
    }

    public function index(): void {
        echo json_encode($this->model->getAll());
    }

    public function save(array $input, string $role): void {
        if ($role === 'STAFF_NURSE') {
            http_response_code(403);
            echo json_encode(['error' => 'PDPL Violation: Staff Nurses cannot modify nurse records.']);
            return;
        }

        $idType = $input['identification_type'] ?? 'NATIONAL_ID';
        $idNo = trim($input['identification_number'] ?? '');
        $empNo = trim($input['employee_number'] ?? '');

        if (empty($empNo)) {
            http_response_code(422);
            echo json_encode(['error' => 'Validation Error: Employee Number is required.']);
            return;
        }

        // KSA 10-Digit ID Validation
        if ($idType === 'NATIONAL_ID' && !preg_match('/^1[0-9]{9}$/', $idNo)) {
            http_response_code(422);
            echo json_encode(['error' => 'Validation Error: Saudi National ID must start with 1 and contain exactly 10 digits.']);
            return;
        }
        if ($idType === 'IQAMA' && !preg_match('/^2[0-9]{9}$/', $idNo)) {
            http_response_code(422);
            echo json_encode(['error' => 'Validation Error: Saudi Iqama must start with 2 and contain exactly 10 digits.']);
            return;
        }

        try {
            if (empty($input['nurse_id'])) {
                $this->model->create($input);
            } else {
                $this->model->update($input['nurse_id'], $input);
            }
            echo json_encode(['status' => 'success']);
        } catch (PDOException $e) {
            http_response_code(400);
            if ($e->getCode() == 23000) {
                echo json_encode(['error' => 'Duplicate Record: Employee Number or National ID/Iqama already exists in system.']);
            } else {
                echo json_encode(['error' => 'Database Error: ' . $e->getMessage()]);
            }
        }
    }
}