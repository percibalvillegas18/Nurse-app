# Nurse App Themed v2 installation

1. Import your existing Nurse App database.
2. In phpMyAdmin, select the `nurse_scheduling` database.
3. Import `database_migration_v2.sql` once.
4. Copy the `nurse-app` folder into your XAMPP `htdocs` directory.
5. Ensure `storage/nurse_documents` is writable by PHP/Apache.
6. Open `http://localhost/nurse-app/`.

The new **Data Entry** module is available to the Head Nurse role. Uploaded
documents are limited to PDF, JPG and PNG files with a maximum size of 5 MB
per file. Stored filenames are randomized, directory listing is disabled, and
executable web files are blocked by the included `.htaccess` policy.

For production, move uploaded documents outside the public web root and replace
the demonstration role switcher with authenticated user accounts.
