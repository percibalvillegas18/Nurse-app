<?php
// controllers/AuthController.php – Login / Logout / Session endpoints
namespace Controllers;

use Middleware\AuthMiddleware;
use Config\Rbac;

class AuthController
{
    /**
     * POST ?action=login
     * Body: { "email": "...", "password": "..." }
     */
    public function login(array $input): void
    {
        $email    = trim(strtolower($input['email']    ?? ''));
        $password = $input['password'] ?? '';
        $ip       = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

        if (!$email || !$password) {
            http_response_code(400);
            echo json_encode(['error' => 'Email and password are required.']);
            return;
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid email format.']);
            return;
        }

        $result = AuthMiddleware::attemptLogin($email, $password, $ip);

        if (!$result['ok']) {
            http_response_code(401);
            echo json_encode(['error' => $result['error']]);
            return;
        }

        echo json_encode([
            'success' => true,
            'user'    => $result['user'],
            'message' => 'Login successful.',
        ]);
    }

    /**
     * POST ?action=logout
     */
    public function logout(): void
    {
        AuthMiddleware::logout();
        echo json_encode(['success' => true, 'message' => 'Logged out successfully.']);
    }

    /**
     * GET ?action=me  – returns current session user + role + permissions
     */
    public function me(): void
    {
        AuthMiddleware::requireAuth();
        $role = AuthMiddleware::currentRole();
        echo json_encode([
            'user_id'     => AuthMiddleware::currentUser(),
            'email'       => $_SESSION['user_email'] ?? null,
            'role'        => $role,
            'permissions' => Rbac::permissionsFor($role),
        ]);
    }
}
