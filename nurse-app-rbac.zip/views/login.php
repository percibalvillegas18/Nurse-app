<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AIGH — Secure Login</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700&family=Inter:wght@300;400;500;600;700&display=swap">
<style>
:root {
  --navy:        #1B2A4B;
  --navy-light:  #253556;
  --teal:        #0E7C7B;
  --teal-light:  #12A5A5;
  --teal-bg:     #E8F6F6;
  --amber:       #E8A838;
  --red:         #D94452;
  --red-bg:      #FDE8EA;
  --bg:          #F0F2F5;
  --card:        #FFFFFF;
  --text:        #1A1D23;
  --text-sec:    #5F6673;
  --border:      #E2E5EB;
  --shadow:      0 8px 32px rgba(27,42,75,0.12);
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
  font-family: 'DM Sans', system-ui, sans-serif;
  background: linear-gradient(135deg, var(--navy) 0%, var(--navy-light) 40%, #1a4a6e 100%);
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
}

/* ── Decorative background pattern ── */
body::before {
  content: '';
  position: fixed;
  inset: 0;
  background-image:
    radial-gradient(circle at 20% 20%, rgba(14,124,123,.18) 0%, transparent 50%),
    radial-gradient(circle at 80% 80%, rgba(14,124,123,.12) 0%, transparent 50%);
  pointer-events: none;
}

.login-card {
  background: var(--card);
  border-radius: 20px;
  box-shadow: var(--shadow);
  width: 100%;
  max-width: 420px;
  overflow: hidden;
  position: relative;
}

/* ── Header banner ── */
.card-header {
  background: linear-gradient(135deg, var(--navy) 0%, var(--navy-light) 100%);
  padding: 32px 36px 28px;
  text-align: center;
  position: relative;
}
.card-header::after {
  content: '';
  position: absolute;
  bottom: -1px; left: 0; right: 0;
  height: 3px;
  background: linear-gradient(90deg, var(--teal), var(--teal-light), var(--teal));
}
.logo-mark {
  width: 52px; height: 52px;
  background: var(--teal);
  border-radius: 14px;
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 14px;
}
.logo-mark svg { width: 30px; height: 30px; }
.card-header h1 { color: #fff; font-size: 1.25rem; font-weight: 700; letter-spacing: -.01em; }
.card-header p  { color: rgba(255,255,255,.55); font-size: .78rem; margin-top: 4px; }

/* ── Form body ── */
.card-body { padding: 32px 36px 36px; }

.field { margin-bottom: 20px; }
.field label {
  display: block;
  font-size: .78rem; font-weight: 600;
  color: var(--text); letter-spacing: .03em;
  text-transform: uppercase;
  margin-bottom: 7px;
}
.field input {
  width: 100%;
  padding: 11px 14px;
  border: 1.5px solid var(--border);
  border-radius: 10px;
  font-size: .92rem; font-family: inherit;
  color: var(--text);
  background: #FAFBFC;
  outline: none;
  transition: border-color .15s, box-shadow .15s;
}
.field input:focus {
  border-color: var(--teal);
  box-shadow: 0 0 0 3px rgba(14,124,123,.12);
  background: #fff;
}

.field-row { display: flex; align-items: center; justify-content: space-between; margin-bottom: 7px; }
.field-row label { margin: 0; }
.show-pw {
  font-size: .76rem; color: var(--teal); cursor: pointer;
  background: none; border: none; font-family: inherit;
}

.submit-btn {
  width: 100%; padding: 13px;
  background: linear-gradient(135deg, var(--teal) 0%, var(--teal-light) 100%);
  color: #fff; border: none; border-radius: 11px;
  font-size: .95rem; font-weight: 700; font-family: inherit;
  cursor: pointer; letter-spacing: .01em;
  transition: opacity .15s, transform .1s;
  display: flex; align-items: center; justify-content: center; gap: 8px;
  margin-top: 8px;
}
.submit-btn:hover   { opacity: .92; }
.submit-btn:active  { transform: scale(.98); }
.submit-btn:disabled{ opacity: .6; cursor: not-allowed; }

/* ── Alert ── */
.alert {
  display: none; padding: 12px 14px;
  border-radius: 9px; font-size: .85rem; font-weight: 500;
  margin-bottom: 20px; align-items: flex-start; gap: 8px;
}
.alert.error   { background: var(--red-bg); color: var(--red); border: 1px solid #f8c9cd; display: flex; }
.alert.success { background: var(--teal-bg); color: var(--teal); border: 1px solid #c0eaea; display: flex; }

/* ── Footer note ── */
.card-footer {
  text-align: center;
  padding: 0 36px 28px;
  font-size: .76rem; color: var(--text-sec);
  line-height: 1.6;
}
.card-footer a { color: var(--teal); text-decoration: none; font-weight: 600; }

/* ── Spinner ── */
.spinner {
  width: 18px; height: 18px;
  border: 2px solid rgba(255,255,255,.3);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin .6s linear infinite;
  display: none;
}
@keyframes spin { to { transform: rotate(360deg); } }
.loading .spinner { display: block; }
.loading .btn-text { display: none; }
</style>
</head>
<body>

<div class="login-card">

  <!-- Header -->
  <div class="card-header">
    <div class="logo-mark">
      <svg viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M15 3L23 8V22L15 27L7 22V8L15 3Z" fill="white" opacity=".9"/>
        <path d="M15 10V20M11 13H19M11 17H19" stroke="#0E7C7B" stroke-width="1.8" stroke-linecap="round"/>
      </svg>
    </div>
    <h1>AIGH Nursing System</h1>
    <p>Secure Clinical Workforce Portal</p>
  </div>

  <!-- Body -->
  <div class="card-body">
    <div id="alert" class="alert"></div>

    <form id="loginForm" novalidate>
      <div class="field">
        <label for="email">Email Address</label>
        <input type="email" id="email" name="email"
               placeholder="nurse@hospital.sa" autocomplete="username" required>
      </div>

      <div class="field">
        <div class="field-row">
          <label for="password">Password</label>
          <button type="button" class="show-pw" onclick="togglePassword()">Show</button>
        </div>
        <input type="password" id="password" name="password"
               placeholder="••••••••" autocomplete="current-password" required>
      </div>

      <button type="submit" class="submit-btn" id="submitBtn">
        <span class="spinner"></span>
        <span class="btn-text">Sign In Securely</span>
      </button>
    </form>
  </div>

  <!-- Footer -->
  <div class="card-footer">
    Forgot your password? Contact your<br>
    <a href="mailto:admin@hospital.sa">System Administrator</a>
    &nbsp;·&nbsp;
    <span>PDPL Compliant · SCFHS Integrated</span>
  </div>

</div>

<script>
const form  = document.getElementById('loginForm');
const alert = document.getElementById('alert');
const btn   = document.getElementById('submitBtn');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const email    = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;

  hideAlert();
  btn.disabled = true;
  btn.classList.add('loading');

  try {
    // Read CSRF token from meta if present (for CSRF-protected endpoints)
    const csrf = document.querySelector('meta[name="csrf-token"]')?.content ?? '';
    const res  = await fetch('index.php?action=login', {
      method:  'POST',
      headers: {
        'Content-Type':   'application/json',
        'X-CSRF-Token':   csrf,
      },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();

    if (res.ok && data.success) {
      showAlert('Login successful. Redirecting…', 'success');
      setTimeout(() => { window.location.href = 'index.php'; }, 800);
    } else {
      showAlert(data.error || 'Login failed. Please try again.', 'error');
      btn.disabled = false;
      btn.classList.remove('loading');
    }
  } catch (err) {
    showAlert('Network error. Please check your connection.', 'error');
    btn.disabled = false;
    btn.classList.remove('loading');
  }
});

function showAlert(msg, type) {
  alert.textContent = msg;
  alert.className   = 'alert ' + type;
}
function hideAlert() {
  alert.className = 'alert';
}
function togglePassword() {
  const pw = document.getElementById('password');
  const btn = document.querySelector('.show-pw');
  if (pw.type === 'password') { pw.type = 'text';     btn.textContent = 'Hide'; }
  else                        { pw.type = 'password'; btn.textContent = 'Show'; }
}
</script>
</body>
</html>
