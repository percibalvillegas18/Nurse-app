-- =============================================================================
-- AIGH Nursing Management System – RBAC Migration
-- Version  : 1.0.0
-- Database : nurse_scheduling
-- Run once : mysql -u root nurse_scheduling < database/rbac_migration.sql
-- =============================================================================

SET NAMES utf8mb4;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_ENGINE_SUBSTITUTION';

-- ─────────────────────────────────────────────────────────────────────────────
-- 1. ROLES
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `roles` (
    `role_id`        VARCHAR(36)   NOT NULL,
    `role_code`      VARCHAR(50)   NOT NULL UNIQUE,        -- e.g. ADMIN, MANAGER
    `role_name_en`   VARCHAR(100)  NOT NULL,
    `role_name_ar`   VARCHAR(100)  NOT NULL,
    `description`    TEXT,
    `hierarchy_level` TINYINT UNSIGNED NOT NULL DEFAULT 0, -- higher = more privilege
    `is_system_role` TINYINT(1)    NOT NULL DEFAULT 0,     -- 1 = cannot be deleted
    `is_active`      TINYINT(1)    NOT NULL DEFAULT 1,
    `created_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────────────────────
-- 2. PERMISSIONS
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `permissions` (
    `permission_id`  VARCHAR(36)   NOT NULL,
    `resource`       VARCHAR(80)   NOT NULL,   -- e.g. nurses, shifts, leaves
    `action`         VARCHAR(40)   NOT NULL,   -- create|read|update|delete|approve|export|…
    `scope`          ENUM('global','department','unit','self') NOT NULL DEFAULT 'global',
    `description`    VARCHAR(255),
    `created_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`permission_id`),
    UNIQUE KEY `uq_perm` (`resource`, `action`, `scope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────────────────────
-- 3. ROLE ↔ PERMISSION MAPPING
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `role_permissions` (
    `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `role_id`        VARCHAR(36)   NOT NULL,
    `permission_id`  VARCHAR(36)   NOT NULL,
    `granted_by`     VARCHAR(36),
    `granted_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_rp` (`role_id`, `permission_id`),
    FOREIGN KEY (`role_id`)       REFERENCES `roles`(`role_id`)       ON DELETE CASCADE,
    FOREIGN KEY (`permission_id`) REFERENCES `permissions`(`permission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────────────────────
-- 4. USER ↔ ROLE ASSIGNMENTS  (scoped, temporal)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `user_roles` (
    `user_role_id`   VARCHAR(36)   NOT NULL,
    `user_id`        VARCHAR(36)   NOT NULL,
    `role_id`        VARCHAR(36)   NOT NULL,
    -- scope: null scope_id = system-wide; unit_id = scoped to that unit; dept_id = dept scope
    `scope_type`     ENUM('global','department','unit') NOT NULL DEFAULT 'global',
    `scope_id`       VARCHAR(36)   DEFAULT NULL,    -- FK to departments.dept_id or units.unit_id
    `effective_from` DATE          NOT NULL DEFAULT (CURDATE()),
    `effective_to`   DATE          DEFAULT NULL,    -- NULL = no expiry
    `granted_by`     VARCHAR(36)   NOT NULL,
    `reason`         VARCHAR(500)  DEFAULT NULL,
    `is_active`      TINYINT(1)    NOT NULL DEFAULT 1,
    `created_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`user_role_id`),
    KEY `idx_user_roles_user`  (`user_id`, `is_active`),
    KEY `idx_user_roles_role`  (`role_id`),
    KEY `idx_user_roles_scope` (`scope_type`, `scope_id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
    FOREIGN KEY (`role_id`) REFERENCES `roles`(`role_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────────────────────
-- 5. IMMUTABLE AUDIT LOG
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `rbac_audit_log` (
    `log_id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `actor_user_id`  VARCHAR(36)   DEFAULT NULL,   -- who performed the action
    `actor_role`     VARCHAR(50)   DEFAULT NULL,
    `action`         VARCHAR(60)   NOT NULL,        -- ROLE_ASSIGNED, ROLE_REVOKED, LOGIN_SUCCESS, etc.
    `resource_type`  VARCHAR(60)   DEFAULT NULL,
    `resource_id`    VARCHAR(36)   DEFAULT NULL,
    `target_user_id` VARCHAR(36)   DEFAULT NULL,    -- user affected (for assignments)
    `old_value`      JSON          DEFAULT NULL,
    `new_value`      JSON          DEFAULT NULL,
    `ip_address`     VARCHAR(45)   DEFAULT NULL,    -- IPv4 or IPv6
    `user_agent`     VARCHAR(500)  DEFAULT NULL,
    `session_id`     VARCHAR(128)  DEFAULT NULL,
    `created_at`     DATETIME(3)   NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (`log_id`),
    KEY `idx_audit_actor`  (`actor_user_id`, `created_at`),
    KEY `idx_audit_target` (`target_user_id`, `created_at`),
    KEY `idx_audit_action` (`action`, `created_at`)
    -- NOTE: No UPDATE/DELETE triggers to guarantee immutability.
    -- Retention: archive rows older than 7 years per PDPL Art.29.
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────────────────────
-- 6. FAILED LOGIN TRACKING  (for account lockout)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `login_attempts` (
    `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `email`          VARCHAR(255)  NOT NULL,
    `ip_address`     VARCHAR(45)   NOT NULL,
    `attempted_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `success`        TINYINT(1)    NOT NULL DEFAULT 0,
    PRIMARY KEY (`id`),
    KEY `idx_la_email_time` (`email`, `attempted_at`),
    KEY `idx_la_ip_time`    (`ip_address`, `attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────────────────────
-- 7. ALTER EXISTING users TABLE – add RBAC & auth columns
-- ─────────────────────────────────────────────────────────────────────────────
ALTER TABLE `users`
    ADD COLUMN IF NOT EXISTS `mfa_enabled`       TINYINT(1)   NOT NULL DEFAULT 0            AFTER `password_hash`,
    ADD COLUMN IF NOT EXISTS `mfa_secret`        VARCHAR(64)  DEFAULT NULL                  AFTER `mfa_enabled`,
    ADD COLUMN IF NOT EXISTS `failed_attempts`   TINYINT      NOT NULL DEFAULT 0            AFTER `mfa_secret`,
    ADD COLUMN IF NOT EXISTS `locked_until`      DATETIME     DEFAULT NULL                  AFTER `failed_attempts`,
    ADD COLUMN IF NOT EXISTS `last_login_at`     DATETIME     DEFAULT NULL                  AFTER `locked_until`,
    ADD COLUMN IF NOT EXISTS `last_login_ip`     VARCHAR(45)  DEFAULT NULL                  AFTER `last_login_at`,
    ADD COLUMN IF NOT EXISTS `password_changed_at` DATETIME   DEFAULT NULL                  AFTER `last_login_ip`,
    ADD COLUMN IF NOT EXISTS `is_active`         TINYINT(1)   NOT NULL DEFAULT 1            AFTER `password_changed_at`;

-- ─────────────────────────────────────────────────────────────────────────────
-- 8. SEED ROLES
-- ─────────────────────────────────────────────────────────────────────────────
INSERT IGNORE INTO `roles`
    (`role_id`, `role_code`, `role_name_en`, `role_name_ar`, `description`, `hierarchy_level`, `is_system_role`)
VALUES
    ('role-admin-001',  'ADMIN',       'System Administrator', 'مسؤول النظام',   'Full system access; manages users, roles, config, audit logs.',  40, 1),
    ('role-mgr-001',    'MANAGER',     'Department Manager',   'مدير القسم',     'Dept-scoped: manages nurses, approves leaves, views reports.',   30, 1),
    ('role-sup-001',    'SUPERVISOR',  'Unit Supervisor',      'مشرف الوحدة',    'Unit-scoped: schedules shifts, approves unit leaves, SBAR.',     20, 1),
    ('role-nurse-001',  'STAFF_NURSE', 'Staff Nurse',          'ممرض/ة',         'Self-service: view schedule, submit leave, claim open shifts.',  10, 1);

-- ─────────────────────────────────────────────────────────────────────────────
-- 9. SEED PERMISSIONS
-- ─────────────────────────────────────────────────────────────────────────────
INSERT IGNORE INTO `permissions` (`permission_id`, `resource`, `action`, `scope`, `description`) VALUES
-- Users
('perm-u-c',   'users', 'create',       'global', 'Create a new system user account'),
('perm-u-r',   'users', 'read',         'global', 'View user list and profiles'),
('perm-u-u',   'users', 'update',       'global', 'Edit user account details'),
('perm-u-d',   'users', 'delete',       'global', 'Deactivate or delete a user account'),
('perm-u-ar',  'users', 'assign_role',  'global', 'Assign or revoke roles for any user'),
-- Nurses
('perm-n-c',   'nurses', 'create',      'global',     'Register a new nurse record'),
('perm-n-r',   'nurses', 'read',        'global',     'View all nurse master records'),
('perm-n-rs',  'nurses', 'read',        'self',       'View own nurse record only'),
('perm-n-u',   'nurses', 'update',      'global',     'Edit any nurse master record'),
('perm-n-us',  'nurses', 'update',      'self',       'Edit own nurse profile details'),
('perm-n-d',   'nurses', 'delete',      'global',     'Remove a nurse record from system'),
-- Shifts
('perm-s-c',   'shifts', 'create',      'global',     'Assign new shift cells'),
('perm-s-cu',  'shifts', 'create',      'unit',       'Assign shifts within own unit'),
('perm-s-r',   'shifts', 'read',        'global',     'View any unit shift matrix'),
('perm-s-u',   'shifts', 'update',      'global',     'Edit any shift assignment'),
('perm-s-uu',  'shifts', 'update',      'unit',       'Edit shifts within own unit'),
('perm-s-d',   'shifts', 'delete',      'global',     'Delete shift assignments'),
('perm-s-pub', 'shifts', 'publish',     'unit',       'Publish shift schedule for own unit'),
('perm-s-cl',  'shifts', 'claim_open',  'self',       'Claim an open shift for self'),
-- Leaves
('perm-l-sub', 'leaves', 'submit',      'self',       'Submit own leave request'),
('perm-l-app', 'leaves', 'approve',     'unit',       'Approve/reject unit leave requests'),
('perm-l-apg', 'leaves', 'approve',     'global',     'Approve/reject any leave request'),
('perm-l-r',   'leaves', 'read',        'global',     'View all leave requests'),
('perm-l-rs',  'leaves', 'read',        'self',       'View own leave requests'),
-- Departments
('perm-d-c',   'departments', 'create', 'global',     'Create new departments'),
('perm-d-r',   'departments', 'read',   'global',     'View departments and units'),
('perm-d-u',   'departments', 'update', 'global',     'Edit department configuration'),
('perm-d-um',  'departments', 'update', 'department', 'Edit own department config'),
('perm-d-del', 'departments', 'delete', 'global',     'Delete departments'),
-- Reports
('perm-r-v',   'reports', 'view',       'global',     'View analytics and KPI dashboards'),
('perm-r-vd',  'reports', 'view',       'department', 'View own department reports'),
('perm-r-e',   'reports', 'export',     'global',     'Export reports as CSV/PDF'),
-- Audit
('perm-a-v',   'audit', 'view',         'global',     'View system audit log'),
-- Config
('perm-cfg',   'config', 'manage',      'global',     'Manage system configuration'),
-- Handovers / SBAR
('perm-h-r',   'handovers', 'read',     'global',     'Read SBAR handover messages'),
('perm-h-w',   'handovers', 'post',     'unit',       'Post SBAR shift handover'),
-- Tickets
('perm-t-c',   'tickets', 'create',     'global',     'Create hypercare support ticket'),
('perm-t-res', 'tickets', 'resolve',    'unit',       'Resolve hypercare ticket');

-- ─────────────────────────────────────────────────────────────────────────────
-- 10. MAP PERMISSIONS → ROLES
-- ─────────────────────────────────────────────────────────────────────────────

-- ADMIN: all permissions
INSERT IGNORE INTO `role_permissions` (`id`, `role_id`, `permission_id`) VALUES
(1,  'role-admin-001', 'perm-u-c'),
(2,  'role-admin-001', 'perm-u-r'),
(3,  'role-admin-001', 'perm-u-u'),
(4,  'role-admin-001', 'perm-u-d'),
(5,  'role-admin-001', 'perm-u-ar'),
(6,  'role-admin-001', 'perm-n-c'),
(7,  'role-admin-001', 'perm-n-r'),
(8,  'role-admin-001', 'perm-n-u'),
(9,  'role-admin-001', 'perm-n-d'),
(10, 'role-admin-001', 'perm-s-c'),
(11, 'role-admin-001', 'perm-s-r'),
(12, 'role-admin-001', 'perm-s-u'),
(13, 'role-admin-001', 'perm-s-d'),
(14, 'role-admin-001', 'perm-s-pub'),
(15, 'role-admin-001', 'perm-l-sub'),
(16, 'role-admin-001', 'perm-l-apg'),
(17, 'role-admin-001', 'perm-l-r'),
(18, 'role-admin-001', 'perm-d-c'),
(19, 'role-admin-001', 'perm-d-r'),
(20, 'role-admin-001', 'perm-d-u'),
(21, 'role-admin-001', 'perm-d-del'),
(22, 'role-admin-001', 'perm-r-v'),
(23, 'role-admin-001', 'perm-r-e'),
(24, 'role-admin-001', 'perm-a-v'),
(25, 'role-admin-001', 'perm-cfg'),
(26, 'role-admin-001', 'perm-h-r'),
(27, 'role-admin-001', 'perm-h-w'),
(28, 'role-admin-001', 'perm-t-c'),
(29, 'role-admin-001', 'perm-t-res');

-- MANAGER: department-scoped management
INSERT IGNORE INTO `role_permissions` (`id`, `role_id`, `permission_id`) VALUES
(30, 'role-mgr-001', 'perm-u-r'),
(31, 'role-mgr-001', 'perm-n-c'),
(32, 'role-mgr-001', 'perm-n-r'),
(33, 'role-mgr-001', 'perm-n-u'),
(34, 'role-mgr-001', 'perm-s-c'),
(35, 'role-mgr-001', 'perm-s-r'),
(36, 'role-mgr-001', 'perm-s-u'),
(37, 'role-mgr-001', 'perm-s-d'),
(38, 'role-mgr-001', 'perm-s-pub'),
(39, 'role-mgr-001', 'perm-l-sub'),
(40, 'role-mgr-001', 'perm-l-apg'),
(41, 'role-mgr-001', 'perm-l-r'),
(42, 'role-mgr-001', 'perm-d-r'),
(43, 'role-mgr-001', 'perm-d-um'),
(44, 'role-mgr-001', 'perm-r-vd'),
(45, 'role-mgr-001', 'perm-r-e'),
(46, 'role-mgr-001', 'perm-h-r'),
(47, 'role-mgr-001', 'perm-h-w'),
(48, 'role-mgr-001', 'perm-t-c'),
(49, 'role-mgr-001', 'perm-t-res');

-- SUPERVISOR (= old HEAD_NURSE): unit-scoped
INSERT IGNORE INTO `role_permissions` (`id`, `role_id`, `permission_id`) VALUES
(50, 'role-sup-001', 'perm-n-r'),
(51, 'role-sup-001', 'perm-s-cu'),
(52, 'role-sup-001', 'perm-s-r'),
(53, 'role-sup-001', 'perm-s-uu'),
(54, 'role-sup-001', 'perm-s-pub'),
(55, 'role-sup-001', 'perm-l-sub'),
(56, 'role-sup-001', 'perm-l-app'),
(57, 'role-sup-001', 'perm-l-r'),
(58, 'role-sup-001', 'perm-d-r'),
(59, 'role-sup-001', 'perm-r-vd'),
(60, 'role-sup-001', 'perm-h-r'),
(61, 'role-sup-001', 'perm-h-w'),
(62, 'role-sup-001', 'perm-t-c'),
(63, 'role-sup-001', 'perm-t-res');

-- STAFF_NURSE: self-service only
INSERT IGNORE INTO `role_permissions` (`id`, `role_id`, `permission_id`) VALUES
(64, 'role-nurse-001', 'perm-n-rs'),
(65, 'role-nurse-001', 'perm-n-us'),
(66, 'role-nurse-001', 'perm-s-r'),
(67, 'role-nurse-001', 'perm-s-cl'),
(68, 'role-nurse-001', 'perm-l-sub'),
(69, 'role-nurse-001', 'perm-l-rs'),
(70, 'role-nurse-001', 'perm-d-r'),
(71, 'role-nurse-001', 'perm-h-r'),
(72, 'role-nurse-001', 'perm-h-w'),
(73, 'role-nurse-001', 'perm-t-c');

-- ─────────────────────────────────────────────────────────────────────────────
-- 11. MIGRATE EXISTING USERS → user_roles
-- ─────────────────────────────────────────────────────────────────────────────
-- Map legacy role column to new role_id
INSERT IGNORE INTO `user_roles`
    (`user_role_id`, `user_id`, `role_id`, `scope_type`, `granted_by`, `reason`, `is_active`)
SELECT
    UUID(),
    u.user_id,
    CASE u.role
        WHEN 'HEAD_NURSE'  THEN 'role-sup-001'
        WHEN 'STAFF_NURSE' THEN 'role-nurse-001'
        ELSE 'role-nurse-001'
    END,
    'global',
    'system-migration',
    'Migrated from legacy role column during RBAC rollout v1.0',
    1
FROM `users` u;

-- ─────────────────────────────────────────────────────────────────────────────
-- 12. SEED ADMIN USER  (change password immediately after first login)
-- ─────────────────────────────────────────────────────────────────────────────
INSERT IGNORE INTO `users`
    (`user_id`, `email`, `password_hash`, `role`, `is_active`)
VALUES
    ('u-admin-001',
     'admin@hospital.sa',
     '$2y$12$GkDmFCuP2w8uJ3N7xZoJuuAvRh5N5W7GdYQk8EwPZ7TT5JqFVlrRy',  -- Admin@1234
     'ADMIN',
     1);

INSERT IGNORE INTO `user_roles`
    (`user_role_id`, `user_id`, `role_id`, `scope_type`, `granted_by`, `reason`)
VALUES
    (UUID(), 'u-admin-001', 'role-admin-001', 'global', 'u-admin-001', 'Initial system admin account');

SET foreign_key_checks = 1;

-- =============================================================================
-- MIGRATION COMPLETE
-- Tables created: roles, permissions, role_permissions, user_roles,
--                 rbac_audit_log, login_attempts
-- users table: added mfa_enabled, mfa_secret, failed_attempts, locked_until,
--              last_login_at, last_login_ip, password_changed_at, is_active
-- Default admin: admin@hospital.sa / Admin@1234  ← CHANGE IMMEDIATELY
-- =============================================================================
