<?php
// config/Rbac.php  –  Static RBAC Permission Map
// Used by middleware for in-memory checks (no DB round-trip for hot paths).
// Must stay in sync with database/rbac_migration.sql seed data.

namespace Config;

class Rbac
{
    // ── Role codes ────────────────────────────────────────────────────────────
    public const ADMIN      = 'ADMIN';
    public const MANAGER    = 'MANAGER';
    public const SUPERVISOR = 'SUPERVISOR';
    public const STAFF_NURSE = 'STAFF_NURSE';

    // ── Legacy alias map (backward-compat with old session values) ────────────
    public const LEGACY_MAP = [
        'HEAD_NURSE' => self::SUPERVISOR,
    ];

    // ── Hierarchy: higher = more privilege ────────────────────────────────────
    public const HIERARCHY = [
        self::ADMIN       => 40,
        self::MANAGER     => 30,
        self::SUPERVISOR  => 20,
        self::STAFF_NURSE => 10,
    ];

    // ── Permission matrix ─────────────────────────────────────────────────────
    // Format: resource.action → [roles that may execute at 'global' scope]
    // Scope enforcement ('unit','department','self') is handled in middleware.
    //
    // Each row: 'resource.action' => ['ROLE_A', 'ROLE_B', ...]
    public const MATRIX = [
        // Users
        'users.create'      => [self::ADMIN],
        'users.read'        => [self::ADMIN, self::MANAGER, self::SUPERVISOR],
        'users.update'      => [self::ADMIN],
        'users.delete'      => [self::ADMIN],
        'users.assign_role' => [self::ADMIN],

        // Nurses
        'nurses.create'     => [self::ADMIN, self::MANAGER],
        'nurses.read'       => [self::ADMIN, self::MANAGER, self::SUPERVISOR],
        'nurses.read.self'  => [self::STAFF_NURSE],   // own record only
        'nurses.update'     => [self::ADMIN, self::MANAGER],
        'nurses.update.self'=> [self::STAFF_NURSE],   // own record only
        'nurses.delete'     => [self::ADMIN],

        // Shifts
        'shifts.create'     => [self::ADMIN, self::MANAGER, self::SUPERVISOR],
        'shifts.read'       => [self::ADMIN, self::MANAGER, self::SUPERVISOR, self::STAFF_NURSE],
        'shifts.update'     => [self::ADMIN, self::MANAGER, self::SUPERVISOR],
        'shifts.delete'     => [self::ADMIN, self::MANAGER, self::SUPERVISOR],
        'shifts.publish'    => [self::ADMIN, self::MANAGER, self::SUPERVISOR],
        'shifts.claim_open' => [self::ADMIN, self::MANAGER, self::SUPERVISOR, self::STAFF_NURSE],

        // Leaves
        'leaves.submit'     => [self::ADMIN, self::MANAGER, self::SUPERVISOR, self::STAFF_NURSE],
        'leaves.approve'    => [self::ADMIN, self::MANAGER, self::SUPERVISOR],
        'leaves.read'       => [self::ADMIN, self::MANAGER, self::SUPERVISOR],
        'leaves.read.self'  => [self::STAFF_NURSE],

        // Departments
        'departments.create'=> [self::ADMIN],
        'departments.read'  => [self::ADMIN, self::MANAGER, self::SUPERVISOR, self::STAFF_NURSE],
        'departments.update'=> [self::ADMIN, self::MANAGER],
        'departments.delete'=> [self::ADMIN],

        // Reports
        'reports.view'      => [self::ADMIN, self::MANAGER, self::SUPERVISOR],
        'reports.export'    => [self::ADMIN, self::MANAGER],

        // Audit
        'audit.view'        => [self::ADMIN],

        // Config
        'config.manage'     => [self::ADMIN],

        // Handovers / SBAR
        'handovers.read'    => [self::ADMIN, self::MANAGER, self::SUPERVISOR, self::STAFF_NURSE],
        'handovers.post'    => [self::ADMIN, self::MANAGER, self::SUPERVISOR, self::STAFF_NURSE],

        // Tickets
        'tickets.create'    => [self::ADMIN, self::MANAGER, self::SUPERVISOR, self::STAFF_NURSE],
        'tickets.resolve'   => [self::ADMIN, self::MANAGER, self::SUPERVISOR],
    ];

    /**
     * Normalise a legacy role code to the new canonical code.
     */
    public static function normalise(string $role): string
    {
        return self::LEGACY_MAP[$role] ?? $role;
    }

    /**
     * Quick in-memory permission check (no DB).
     *
     * @param string      $role     Canonical role code
     * @param string      $resource e.g. 'nurses'
     * @param string      $action   e.g. 'read'
     * @param string|null $scope    'self' to check self-scoped variant
     */
    public static function can(string $role, string $resource, string $action, ?string $scope = null): bool
    {
        $role = self::normalise($role);
        $key  = $scope ? "{$resource}.{$action}.{$scope}" : "{$resource}.{$action}";

        // Check exact key first, then fall back to global key
        foreach ([$key, "{$resource}.{$action}"] as $lookup) {
            if (isset(self::MATRIX[$lookup])) {
                return in_array($role, self::MATRIX[$lookup], true);
            }
        }
        return false; // deny by default
    }

    /**
     * Returns the hierarchy level for a role (higher = more privilege).
     */
    public static function level(string $role): int
    {
        $role = self::normalise($role);
        return self::HIERARCHY[$role] ?? 0;
    }

    /**
     * Returns all permissions a role holds as ['resource.action', ...].
     */
    public static function permissionsFor(string $role): array
    {
        $role  = self::normalise($role);
        $perms = [];
        foreach (self::MATRIX as $key => $roles) {
            if (in_array($role, $roles, true)) {
                $perms[] = $key;
            }
        }
        return $perms;
    }
}
