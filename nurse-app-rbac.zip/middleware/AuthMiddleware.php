<?php
// middleware/AuthMiddleware.php – Authentication & RBAC Enforcement
namespace Middleware;

use Config\Database;
use Config\Rbac;
use PDO;

class AuthMiddleware
{
    // ── Session / lockout constants ───────────────────────────────────────────
    private const SESSION_TIMEOUT_MINUTES = 30;   // idle timeout
    private const MAX_FAILED_ATTEMPTS     = 5;    // before lockout
    private const LOCKOUT_MINUTES         = 15;   // duration of lockout

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC GUARD METHODS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Ensure a valid, live session exists. Sends HTTP 401 + exits if not.
     */
    public static function requireAuth(): void
    {
        self::startSession();

        // Idle timeout
        if (isset($_SESSION['last_activity'])) {
            $idleSeconds = time() - $_SESSION['last_activity'];
            if ($idleSeconds > self::SESSION_TIMEOUT_MINUTES * 60) {
                self::terminateSession('Session expired due to inactivity.');
            }
        }
        $_SESSION['last_activity'] = time();

        $userId = $_SESSION['user_id']   ?? null;
        $role   = $_SESSION['user_role'] ?? null;

        if (!$userId || !$role) {
            http_response_code(401);
            echo json_encode([
                'error' => 'Unauthorised: authentication required.',
                'redirect' => 'login',
            ]);
            exit;
        }
    }

    /**
     * Require a specific RBAC permission. Sends HTTP 403 + exits if denied.
     *
     * @param string      $resource  e.g. 'nurses'
     * @param string      $action    e.g. 'create'
     * @param string|null $scope     e.g. 'self', 'unit', 'department'
     */
    public static function requirePermission(string $resource, string $action, ?string $scope = null): void
    {
        self::requireAuth();
        $role = Rbac::normalise($_SESSION['user_role'] ?? '');

        if (!Rbac::can($role, $resource, $action, $scope)) {
            self::auditDeny($resource, $action);
            http_response_code(403);
            echo json_encode([
                'error'   => "Access denied: you do not have [{$resource}.{$action}] permission.",
                'role'    => $role,
                'contact' => 'Contact your system administrator to request access.',
            ]);
            exit;
        }
    }

    /**
     * Boolean check (no side-effects) – use in conditional UI rendering.
     */
    public static function can(string $resource, string $action, ?string $scope = null): bool
    {
        $role = Rbac::normalise($_SESSION['user_role'] ?? '');
        return Rbac::can($role, $resource, $action, $scope);
    }

    /**
     * Returns current role (canonical).
     */
    public static function currentRole(): string
    {
        return Rbac::normalise($_SESSION['user_role'] ?? '');
    }

    /**
     * Returns current user_id.
     */
    public static function currentUser(): ?string
    {
        return $_SESSION['user_id'] ?? null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AUTHENTICATION
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Attempt login. Returns ['ok' => true, 'user' => [...]] or ['ok' => false, 'error' => '...'].
     */
    public static function attemptLogin(string $email, string $password, string $ip): array
    {
        $db = Database::getConnection();

        // ① Rate-check recent failures for this email + IP
        $recentFails = self::recentFailedAttempts($db, $email, $ip);
        if ($recentFails >= self::MAX_FAILED_ATTEMPTS) {
            self::recordAttempt($db, $email, $ip, false);
            self::auditEvent(null, null, 'LOGIN_BLOCKED', 'users', null, null,
                ['email' => $email, 'ip' => $ip]);
            return ['ok' => false, 'error' => 'Account temporarily locked. Try again in ' . self::LOCKOUT_MINUTES . ' minutes.'];
        }

        // ② Fetch user
        $stmt = $db->prepare("
            SELECT u.user_id, u.email, u.password_hash, u.is_active, u.locked_until,
                   u.failed_attempts, u.mfa_enabled,
                   ur.role_id,
                   r.role_code
            FROM users u
            LEFT JOIN user_roles ur ON ur.user_id = u.user_id
                AND ur.is_active = 1
                AND (ur.effective_to IS NULL OR ur.effective_to >= CURDATE())
            LEFT JOIN roles r ON r.role_id = ur.role_id
            WHERE u.email = ?
            LIMIT 1
        ");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            self::recordAttempt($db, $email, $ip, false);
            return ['ok' => false, 'error' => 'Invalid email or password.'];
        }

        // ③ Account status checks
        if (!$user['is_active']) {
            return ['ok' => false, 'error' => 'Account has been deactivated. Contact your administrator.'];
        }
        if ($user['locked_until'] && strtotime($user['locked_until']) > time()) {
            return ['ok' => false, 'error' => 'Account locked until ' . $user['locked_until'] . '. Contact admin.'];
        }

        // ④ Password verify
        if (!password_verify($password, $user['password_hash'])) {
            self::recordAttempt($db, $email, $ip, false);
            $fails = $recentFails + 1;
            // Lock account if threshold reached
            if ($fails >= self::MAX_FAILED_ATTEMPTS) {
                $until = date('Y-m-d H:i:s', strtotime('+' . self::LOCKOUT_MINUTES . ' minutes'));
                $db->prepare("UPDATE users SET locked_until = ? WHERE user_id = ?")->execute([$until, $user['user_id']]);
                self::auditEvent($user['user_id'], $user['role_code'], 'ACCOUNT_LOCKED', 'users', $user['user_id'],
                    null, ['reason' => 'Exceeded max failed attempts', 'until' => $until]);
            }
            return ['ok' => false, 'error' => 'Invalid email or password. ' . (self::MAX_FAILED_ATTEMPTS - $fails) . ' attempts remaining.'];
        }

        // ⑤ Successful login – create session
        self::recordAttempt($db, $email, $ip, true);
        $db->prepare("UPDATE users SET last_login_at = NOW(), last_login_ip = ?, failed_attempts = 0, locked_until = NULL WHERE user_id = ?")
           ->execute([$ip, $user['user_id']]);

        $role = Rbac::normalise($user['role_code'] ?? Rbac::STAFF_NURSE);

        // Regenerate session ID to prevent fixation
        session_regenerate_id(true);
        $_SESSION['user_id']      = $user['user_id'];
        $_SESSION['user_email']   = $user['email'];
        $_SESSION['user_role']    = $role;
        // Backward compat keys for existing controllers
        $_SESSION['role']         = $role;
        $_SESSION['last_activity'] = time();

        self::auditEvent($user['user_id'], $role, 'LOGIN_SUCCESS', 'users', $user['user_id'],
            null, ['ip' => $ip]);

        return [
            'ok'   => true,
            'user' => [
                'user_id'   => $user['user_id'],
                'email'     => $user['email'],
                'role'      => $role,
                'mfa'       => (bool)$user['mfa_enabled'],
                'permissions' => Rbac::permissionsFor($role),
            ],
        ];
    }

    /**
     * Destroy session and redirect to login.
     */
    public static function logout(): void
    {
        $userId = $_SESSION['user_id'] ?? null;
        $role   = $_SESSION['user_role'] ?? null;
        self::auditEvent($userId, $role, 'LOGOUT', 'users', $userId, null, null);

        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AUDIT HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    public static function auditEvent(
        ?string $actorId,
        ?string $actorRole,
        string  $action,
        ?string $resourceType = null,
        ?string $resourceId   = null,
        ?array  $oldValue     = null,
        ?array  $newValue     = null
    ): void {
        try {
            $db = Database::getConnection();
            $db->prepare("
                INSERT INTO rbac_audit_log
                    (actor_user_id, actor_role, action, resource_type, resource_id,
                     old_value, new_value, ip_address, user_agent, session_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ")->execute([
                $actorId,
                $actorRole,
                $action,
                $resourceType,
                $resourceId,
                $oldValue ? json_encode($oldValue)  : null,
                $newValue ? json_encode($newValue)  : null,
                self::clientIp(),
                substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500),
                session_id() ?: null,
            ]);
        } catch (\Throwable $e) {
            // Audit failure must never crash the app — just log to error_log
            error_log('[RBAC AUDIT ERROR] ' . $e->getMessage());
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PRIVATE HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    private static function startSession(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_set_cookie_params([
                'lifetime' => 0,
                'path'     => '/',
                'domain'   => '',
                'secure'   => isset($_SERVER['HTTPS']),
                'httponly' => true,
                'samesite' => 'Strict',
            ]);
            session_start();
        }
    }

    private static function terminateSession(string $message): void
    {
        $userId = $_SESSION['user_id'] ?? null;
        $role   = $_SESSION['user_role'] ?? null;
        self::auditEvent($userId, $role, 'SESSION_EXPIRED', 'session', null, null, ['reason' => $message]);
        session_destroy();
        http_response_code(401);
        echo json_encode(['error' => $message, 'redirect' => 'login']);
        exit;
    }

    private static function recentFailedAttempts(PDO $db, string $email, string $ip): int
    {
        $cutoff = date('Y-m-d H:i:s', strtotime('-' . self::LOCKOUT_MINUTES . ' minutes'));
        $stmt = $db->prepare("
            SELECT COUNT(*) FROM login_attempts
            WHERE success = 0 AND attempted_at > ?
              AND (email = ? OR ip_address = ?)
        ");
        $stmt->execute([$cutoff, $email, $ip]);
        return (int) $stmt->fetchColumn();
    }

    private static function recordAttempt(PDO $db, string $email, string $ip, bool $success): void
    {
        $db->prepare("INSERT INTO login_attempts (email, ip_address, success) VALUES (?, ?, ?)")
           ->execute([$email, $ip, $success ? 1 : 0]);
    }

    private static function auditDeny(string $resource, string $action): void
    {
        self::auditEvent(
            $_SESSION['user_id']   ?? null,
            $_SESSION['user_role'] ?? null,
            'ACCESS_DENIED',
            $resource, null,
            null,
            ['action' => $action, 'uri' => $_SERVER['REQUEST_URI'] ?? '']
        );
    }

    private static function clientIp(): string
    {
        foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'] as $key) {
            if (!empty($_SERVER[$key])) {
                return filter_var($_SERVER[$key], FILTER_VALIDATE_IP) ?: '';
            }
        }
        return '';
    }
}
