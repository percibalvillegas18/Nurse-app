# R6 — Package runnable again (Database + 5 controllers)

## What was missing

The merged `nurse-app-rbac` zip shipped **front-end + RBAC only**. These files were absent and caused fatal errors:

| File | Used by |
|------|---------|
| `config/Database.php` | `AuthMiddleware`, `RbacController`, all domain controllers |
| `controllers/DepartmentController.php` | departments / sub-units routes |
| `controllers/NurseController.php` | nurses directory routes |
| `controllers/ShiftController.php` | shifts matrix routes |
| `controllers/LeaveController.php` | leave routes |
| `controllers/OperationsController.php` | handovers, rollout, analytics, tickets |

## What this package adds

1. **`config/Database.php`** — real PDO singleton. Configure with env vars:
   - `DB_HOST` (default `127.0.0.1`)
   - `DB_PORT` (default `3306`)
   - `DB_NAME` (default `nurse_scheduling`)
   - `DB_USER` / `DB_PASS`
   - Or edit defaults in the file.

2. **Five controller stubs** with the **exact method signatures** `index.php` calls.
   - Read endpoints try the DB; on missing tables they return empty arrays / safe shapes so the UI does not crash.
   - Write endpoints return **HTTP 501** with a clear message to copy the original implementation.

## What you must still do

Copy the **full** controllers from your original AIGH nurse-app project over these stubs:

```text
controllers/DepartmentController.php
controllers/NurseController.php
controllers/ShiftController.php
controllers/LeaveController.php
controllers/OperationsController.php
```

Keep `config/Database.php` (or align it with your original if you already had one).

Run the RBAC migration against your DB:

```bash
mysql -u root nurse_scheduling < database/rbac_migration.sql
```

Default admin (change immediately): `admin@hospital.sa` / `Admin@1234`

## Already fixed in this package line

- **R1** — unauthenticated `switch_user` removed
- **R2** — Sign out button + session user in header
- **R10** — `safeFetch` redirects to login on 401
- **R6** — Database.php + 5 controller stubs (this note)
