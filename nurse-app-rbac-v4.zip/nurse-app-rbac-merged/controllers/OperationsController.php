<?php
// controllers/OperationsController.php – Handovers (SBAR), Tickets, Analytics, Notifications
namespace Controllers;

use Config\Database;
use Config\Rbac;
use Middleware\AuthMiddleware;
use PDO;

class OperationsController
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET ?action=get_channel_messages&unit_id=X[&limit=50]
    // Returns SBAR shift handover messages for the given unit
    // ─────────────────────────────────────────────────────────────────────────
    public function handovers(string $unitId): void
    {
        if (!$unitId) {
            http_response_code(400);
            echo json_encode(['error' => 'unit_id is required.']);
            return;
        }

        $limit = min((int)($_GET['limit'] ?? 50), 200);

        $stmt = $this->db->prepare("
            SELECT h.handover_id, h.unit_id, h.shift_type,
                   h.author_id, u.email AS author_email,
                   h.patient_count, h.critical_alerts, h.pending_tasks,
                   h.message_body, h.created_at
            FROM handover_messages h
            JOIN users u ON u.user_id = h.author_id
            WHERE h.unit_id = ?
            ORDER BY h.created_at DESC
            LIMIT ?
        ");
        $stmt->execute([$unitId, $limit]);

        echo json_encode([
            'unit_id'   => $unitId,
            'messages'  => $stmt->fetchAll(PDO::FETCH_ASSOC),
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=post_channel_message
    // Body: { unit_id, shift_type, patient_count, critical_alerts, pending_tasks, message_body }
    // ─────────────────────────────────────────────────────────────────────────
    public function submitHandover(array $input, ?string $currentUser, string $currentRole): void
    {
        $unitId        = trim($input['unit_id']        ?? '');
        $shiftType     = strtoupper(trim($input['shift_type']     ?? 'M'));  // M|A|N
        $patientCount  = (int)($input['patient_count']  ?? 0);
        $criticalAlerts= trim($input['critical_alerts'] ?? '');
        $pendingTasks  = trim($input['pending_tasks']   ?? '');
        $messageBody   = trim($input['message_body']   ?? '');

        if (!$unitId || !$messageBody) {
            http_response_code(400);
            echo json_encode(['error' => 'unit_id and message_body are required.']);
            return;
        }
        if (!in_array($shiftType, ['M', 'A', 'N'], true)) {
            $shiftType = 'M';
        }

        $handoverId = 'hv-' . bin2hex(random_bytes(6));
        $stmt = $this->db->prepare("
            INSERT INTO handover_messages
                (handover_id, unit_id, shift_type, author_id,
                 patient_count, critical_alerts, pending_tasks, message_body)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $handoverId, $unitId, $shiftType, $currentUser,
            $patientCount, $criticalAlerts, $pendingTasks, $messageBody,
        ]);

        AuthMiddleware::auditEvent(
            $currentUser, $currentRole,
            'HANDOVER_POSTED', 'handovers', $handoverId,
            null,
            ['unit_id' => $unitId, 'shift' => $shiftType]
        );

        echo json_encode([
            'success'     => true,
            'handover_id' => $handoverId,
            'message'     => 'Handover message posted.',
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET ?action=get_rollout_data
    // Returns system rollout telemetry (open access — no extra permission gate)
    // ─────────────────────────────────────────────────────────────────────────
    public function rollout(): void
    {
        // Aggregate counts for rollout KPI tiles
        try {
            $counts = [];

            $counts['total_nurses']  = (int)$this->db->query("SELECT COUNT(*) FROM nurses WHERE is_active=1")->fetchColumn();
            $counts['total_users']   = (int)$this->db->query("SELECT COUNT(*) FROM users  WHERE is_active=1")->fetchColumn();
            $counts['open_tickets']  = (int)$this->db->query("SELECT COUNT(*) FROM hypercare_tickets WHERE status='OPEN'")->fetchColumn();
            $counts['pending_leaves']= (int)$this->db->query("SELECT COUNT(*) FROM leaves WHERE status='PENDING'")->fetchColumn();

            // Shifts published this month
            $counts['schedules_published'] = (int)$this->db->query("
                SELECT COUNT(*) FROM shift_publishes
                WHERE YEAR(published_at)=YEAR(NOW()) AND MONTH(published_at)=MONTH(NOW())
            ")->fetchColumn();

            // Login activity last 24 h
            $counts['logins_24h'] = (int)$this->db->query("
                SELECT COUNT(*) FROM rbac_audit_log
                WHERE action='LOGIN_SUCCESS' AND created_at >= NOW() - INTERVAL 1 DAY
            ")->fetchColumn();

            echo json_encode(['success' => true, 'data' => $counts]);
        } catch (\Throwable $e) {
            error_log('[ROLLOUT] ' . $e->getMessage());
            echo json_encode(['success' => false, 'data' => [], 'error' => 'Could not load rollout data.']);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=create_hypercare_ticket  (any authenticated user)
    // Body: { title, description, priority?, unit_id? }
    // ─────────────────────────────────────────────────────────────────────────
    public function createTicket(array $input, ?string $currentUser): void
    {
        $title       = trim($input['title']       ?? '');
        $description = trim($input['description'] ?? '');
        $priority    = strtoupper(trim($input['priority']    ?? 'MEDIUM'));
        $unitId      = trim($input['unit_id']     ?? '');

        if (!$title || !$description) {
            http_response_code(400);
            echo json_encode(['error' => 'title and description are required.']);
            return;
        }
        if (!in_array($priority, ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'], true)) {
            $priority = 'MEDIUM';
        }

        $ticketId = 'tk-' . bin2hex(random_bytes(6));
        $stmt     = $this->db->prepare("
            INSERT INTO hypercare_tickets
                (ticket_id, title, description, priority,
                 unit_id, created_by, status)
            VALUES (?, ?, ?, ?, ?, ?, 'OPEN')
        ");
        $stmt->execute([
            $ticketId, $title, $description, $priority,
            $unitId ?: null, $currentUser,
        ]);

        AuthMiddleware::auditEvent(
            $currentUser, AuthMiddleware::currentRole(),
            'TICKET_CREATED', 'tickets', $ticketId,
            null, ['title' => $title, 'priority' => $priority]
        );

        echo json_encode([
            'success'   => true,
            'ticket_id' => $ticketId,
            'message'   => 'Support ticket created.',
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=resolve_hypercare_ticket  (SUPERVISOR+)
    // Body: { ticket_id, resolution_note? }
    // ─────────────────────────────────────────────────────────────────────────
    public function resolveTicket(array $input): void
    {
        $ticketId      = trim($input['ticket_id']      ?? '');
        $resolutionNote= trim($input['resolution_note'] ?? '');

        if (!$ticketId) {
            http_response_code(400);
            echo json_encode(['error' => 'ticket_id is required.']);
            return;
        }

        $check = $this->db->prepare("SELECT ticket_id, status FROM hypercare_tickets WHERE ticket_id = ? LIMIT 1");
        $check->execute([$ticketId]);
        $ticket = $check->fetch(PDO::FETCH_ASSOC);

        if (!$ticket) {
            http_response_code(404);
            echo json_encode(['error' => 'Ticket not found.']);
            return;
        }
        if ($ticket['status'] !== 'OPEN') {
            http_response_code(409);
            echo json_encode(['error' => "Ticket is already {$ticket['status']}."]);
            return;
        }

        $currentUser = AuthMiddleware::currentUser();
        $stmt = $this->db->prepare("
            UPDATE hypercare_tickets
            SET status = 'RESOLVED', resolution_note = ?,
                resolved_by = ?, resolved_at = NOW(), updated_at = NOW()
            WHERE ticket_id = ?
        ");
        $stmt->execute([$resolutionNote, $currentUser, $ticketId]);

        AuthMiddleware::auditEvent(
            $currentUser, AuthMiddleware::currentRole(),
            'TICKET_RESOLVED', 'tickets', $ticketId,
            ['status' => 'OPEN'], ['status' => 'RESOLVED']
        );

        echo json_encode(['success' => true, 'ticket_id' => $ticketId, 'message' => 'Ticket resolved.']);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET ?action=get_stage7_analytics  (ADMIN / MANAGER / SUPERVISOR)
    // Returns KPI metrics for the analytics dashboard
    // ─────────────────────────────────────────────────────────────────────────
    public function analytics(): void
    {
        $unitId  = $_GET['unit_id']   ?? null;
        $role    = AuthMiddleware::currentRole();

        try {
            $data = [];

            // Shift coverage rate: assigned/total slots this month
            $shiftBase = "FROM shifts WHERE YEAR(shift_date)=YEAR(NOW()) AND MONTH(shift_date)=MONTH(NOW())";
            if ($unitId && !in_array($role, [Rbac::ADMIN, Rbac::MANAGER], true)) {
                $shiftBase .= " AND unit_id = " . $this->db->quote($unitId);
            }
            $assigned = (int)$this->db->query("SELECT COUNT(*) {$shiftBase} AND shift_code NOT IN ('', 'OFF')")->fetchColumn();
            $total    = (int)$this->db->query("SELECT COUNT(*) {$shiftBase}")->fetchColumn();
            $data['shift_coverage_pct'] = $total > 0 ? round($assigned / $total * 100, 1) : 0;
            $data['shift_assigned']     = $assigned;
            $data['shift_total']        = $total;

            // Leave stats this month
            $leaveBase = "FROM leaves WHERE YEAR(created_at)=YEAR(NOW()) AND MONTH(created_at)=MONTH(NOW())";
            $data['leaves_pending']  = (int)$this->db->query("SELECT COUNT(*) {$leaveBase} AND status='PENDING'")->fetchColumn();
            $data['leaves_approved'] = (int)$this->db->query("SELECT COUNT(*) {$leaveBase} AND status='APPROVED'")->fetchColumn();
            $data['leaves_rejected'] = (int)$this->db->query("SELECT COUNT(*) {$leaveBase} AND status='REJECTED'")->fetchColumn();

            // Expiring certifications (next 30 days)
            $data['licenses_expiring_soon'] = (int)$this->db->query("
                SELECT COUNT(*) FROM nurses
                WHERE is_active=1 AND license_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
            ")->fetchColumn();

            // Contract expirations (next 60 days)
            $data['contracts_expiring_soon'] = (int)$this->db->query("
                SELECT COUNT(*) FROM nurses
                WHERE is_active=1 AND contract_end BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 60 DAY)
            ")->fetchColumn();

            // Open tickets
            $data['open_tickets'] = (int)$this->db->query("
                SELECT COUNT(*) FROM hypercare_tickets WHERE status='OPEN'
            ")->fetchColumn();

            // Login failure rate last 7 days
            $totalAttempts  = (int)$this->db->query("SELECT COUNT(*) FROM login_attempts WHERE attempted_at >= NOW() - INTERVAL 7 DAY")->fetchColumn();
            $failedAttempts = (int)$this->db->query("SELECT COUNT(*) FROM login_attempts WHERE success=0 AND attempted_at >= NOW() - INTERVAL 7 DAY")->fetchColumn();
            $data['login_failure_rate_7d'] = $totalAttempts > 0 ? round($failedAttempts / $totalAttempts * 100, 1) : 0;

            echo json_encode(['success' => true, 'analytics' => $data]);
        } catch (\Throwable $e) {
            error_log('[ANALYTICS] ' . $e->getMessage());
            echo json_encode(['success' => false, 'error' => 'Failed to load analytics.']);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET ?action=run_data_drift_scan  (ADMIN / MANAGER / SUPERVISOR)
    // Scans for data quality issues and returns a findings report
    // ─────────────────────────────────────────────────────────────────────────
    public function drift(): void
    {
        $findings = [];

        try {
            // Nurses with no unit assigned
            $noUnit = (int)$this->db->query("SELECT COUNT(*) FROM nurses WHERE unit_id IS NULL AND is_active=1")->fetchColumn();
            if ($noUnit) {
                $findings[] = ['severity' => 'WARN',  'category' => 'Nurse Assignment',
                               'issue' => "{$noUnit} active nurse(s) have no unit assignment."];
            }

            // Expired licenses still active
            $expLic = (int)$this->db->query("SELECT COUNT(*) FROM nurses WHERE is_active=1 AND license_expiry < CURDATE()")->fetchColumn();
            if ($expLic) {
                $findings[] = ['severity' => 'CRITICAL', 'category' => 'Compliance',
                               'issue' => "{$expLic} nurse(s) have expired SCFHS licenses."];
            }

            // Expired contracts still active
            $expCon = (int)$this->db->query("SELECT COUNT(*) FROM nurses WHERE is_active=1 AND contract_end < CURDATE()")->fetchColumn();
            if ($expCon) {
                $findings[] = ['severity' => 'WARN', 'category' => 'HR',
                               'issue' => "{$expCon} nurse(s) have past contract end dates."];
            }

            // Users with no role assignment
            $noRole = (int)$this->db->query("
                SELECT COUNT(*) FROM users u
                WHERE u.is_active=1
                AND NOT EXISTS (
                    SELECT 1 FROM user_roles ur WHERE ur.user_id=u.user_id AND ur.is_active=1
                )
            ")->fetchColumn();
            if ($noRole) {
                $findings[] = ['severity' => 'WARN', 'category' => 'RBAC',
                               'issue' => "{$noRole} active user(s) have no role assigned."];
            }

            // Locked accounts still active
            $locked = (int)$this->db->query("SELECT COUNT(*) FROM users WHERE is_active=1 AND locked_until > NOW()")->fetchColumn();
            if ($locked) {
                $findings[] = ['severity' => 'INFO', 'category' => 'Security',
                               'issue' => "{$locked} user(s) are currently locked out."];
            }

            echo json_encode([
                'success'       => true,
                'findings_count'=> count($findings),
                'findings'      => $findings,
                'scanned_at'    => date('Y-m-d H:i:s'),
            ]);
        } catch (\Throwable $e) {
            error_log('[DRIFT SCAN] ' . $e->getMessage());
            echo json_encode(['success' => false, 'error' => 'Drift scan failed.']);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=run_automated_sweep  (ADMIN only)
    // Runs scheduled maintenance: unlock expired lockouts, archive stale data
    // ─────────────────────────────────────────────────────────────────────────
    public function sweep(): void
    {
        $currentUser = AuthMiddleware::currentUser();
        $results     = [];

        try {
            // 1. Unlock accounts whose lockout has expired
            $unlocked = $this->db->exec("
                UPDATE users SET locked_until = NULL, failed_attempts = 0
                WHERE locked_until IS NOT NULL AND locked_until < NOW()
            ");
            $results['accounts_unlocked'] = $unlocked;

            // 2. Purge login_attempts older than 30 days (PDPL data minimisation)
            $purgedAttempts = $this->db->exec("
                DELETE FROM login_attempts WHERE attempted_at < NOW() - INTERVAL 30 DAY
            ");
            $results['login_attempts_purged'] = $purgedAttempts;

            // 3. Archive audit log rows older than 7 years (PDPL Art.29 retention)
            // In production this would INSERT into an archive table before deleting.
            // Here we simply report the count ready for archival.
            $archiveReady = (int)$this->db->query("
                SELECT COUNT(*) FROM rbac_audit_log
                WHERE created_at < NOW() - INTERVAL 7 YEAR
            ")->fetchColumn();
            $results['audit_rows_ready_for_archive'] = $archiveReady;

            AuthMiddleware::auditEvent(
                $currentUser, AuthMiddleware::currentRole(),
                'AUTOMATED_SWEEP', 'system', null, null, $results
            );

            echo json_encode(['success' => true, 'sweep_results' => $results, 'swept_at' => date('Y-m-d H:i:s')]);
        } catch (\Throwable $e) {
            error_log('[SWEEP] ' . $e->getMessage());
            echo json_encode(['success' => false, 'error' => 'Automated sweep failed.']);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=submit_feedback  (any authenticated user)
    // Body: { text, category? }
    // ─────────────────────────────────────────────────────────────────────────
    public function submitFeedback(array $input, ?string $currentUser, string $currentRole): void
    {
        $text     = trim($input['text']     ?? '');
        $category = strtoupper(trim($input['category'] ?? 'GENERAL'));

        if (!$text) {
            http_response_code(400);
            echo json_encode(['error' => 'Feedback text is required.']);
            return;
        }

        $allowedCategories = ['GENERAL', 'BUG', 'FEATURE', 'UX', 'PERFORMANCE', 'OTHER'];
        if (!in_array($category, $allowedCategories, true)) {
            $category = 'GENERAL';
        }

        $fbId = 'fb-' . bin2hex(random_bytes(6));
        $stmt = $this->db->prepare("
            INSERT INTO feedback (feedback_id, category, feedback_text, submitted_by, role)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$fbId, $category, $text, $currentUser, $currentRole]);

        echo json_encode(['success' => true, 'feedback_id' => $fbId, 'message' => 'Feedback submitted. Thank you!']);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=upvote_backlog  (any authenticated user)
    // Body: { item_id }
    // ─────────────────────────────────────────────────────────────────────────
    public function upvoteBacklog(array $input): void
    {
        $itemId      = trim($input['item_id'] ?? '');
        $currentUser = AuthMiddleware::currentUser();

        if (!$itemId) {
            http_response_code(400);
            echo json_encode(['error' => 'item_id is required.']);
            return;
        }

        // Check item exists
        $check = $this->db->prepare("SELECT item_id, vote_count FROM backlog_items WHERE item_id = ? LIMIT 1");
        $check->execute([$itemId]);
        $item = $check->fetch(PDO::FETCH_ASSOC);

        if (!$item) {
            http_response_code(404);
            echo json_encode(['error' => 'Backlog item not found.']);
            return;
        }

        // Prevent duplicate votes from same user (best-effort — ignore if table does not yet have the constraint)
        try {
            $this->db->prepare(
                "INSERT INTO backlog_votes (item_id, user_id) VALUES (?, ?)"
            )->execute([$itemId, $currentUser]);
        } catch (\PDOException $e) {
            if (str_contains($e->getMessage(), 'Duplicate') || $e->errorInfo[1] == 1062) {
                http_response_code(409);
                echo json_encode(['error' => 'You have already upvoted this item.']);
                return;
            }
            throw $e;
        }

        $this->db->prepare("UPDATE backlog_items SET vote_count = vote_count + 1 WHERE item_id = ?")->execute([$itemId]);

        echo json_encode([
            'success'    => true,
            'item_id'    => $itemId,
            'vote_count' => $item['vote_count'] + 1,
            'message'    => 'Upvote recorded.',
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET ?action=get_notifications  (any authenticated user)
    // Returns the current user's recent system notifications
    // ─────────────────────────────────────────────────────────────────────────
    public function getNotifications(?string $currentUser): void
    {
        if (!$currentUser) {
            echo json_encode(['notifications' => [], 'unread_count' => 0]);
            return;
        }

        $stmt = $this->db->prepare("
            SELECT n.notif_id, n.notif_type, n.title, n.body,
                   n.link_action, n.is_read, n.created_at
            FROM notifications n
            WHERE n.user_id = ?
            ORDER BY n.created_at DESC
            LIMIT 30
        ");
        $stmt->execute([$currentUser]);
        $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $unread = array_filter($notifications, fn($n) => !$n['is_read']);

        // Mark all as read
        if ($notifications) {
            $this->db->prepare("
                UPDATE notifications SET is_read = 1
                WHERE user_id = ? AND is_read = 0
            ")->execute([$currentUser]);
        }

        echo json_encode([
            'notifications' => $notifications,
            'unread_count'  => count($unread),
        ]);
    }
}
