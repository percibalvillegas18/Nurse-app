<?php
// controllers/LeaveController.php – Leave Request Submission & Approval
namespace Controllers;

use Config\Database;
use Config\Rbac;
use Middleware\AuthMiddleware;
use PDO;

class LeaveController
{
    private PDO $db;

    // Allowed leave types
    private const LEAVE_TYPES = ['ANNUAL', 'SICK', 'EMERGENCY', 'MATERNITY', 'PATERNITY', 'UNPAID', 'STUDY'];
    // Allowed statuses for decide()
    private const DECIDE_VALUES = ['APPROVED', 'REJECTED'];

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET ?action=get_leaves[&unit_id=X&status=PENDING&nurse_id=Y]
    // ADMIN/MANAGER: all leaves  |  SUPERVISOR: unit leaves  |  STAFF_NURSE: own
    // ─────────────────────────────────────────────────────────────────────────
    public function index(): void
    {
        $role        = AuthMiddleware::currentRole();
        $currentUser = AuthMiddleware::currentUser();
        $unitId      = $_GET['unit_id'] ?? null;
        $status      = strtoupper(trim($_GET['status']   ?? ''));
        $nurseId     = trim($_GET['nurse_id'] ?? '');

        $conditions = [];
        $params     = [];

        // Scope: STAFF_NURSE sees only their own leaves
        if ($role === Rbac::STAFF_NURSE) {
            // Look up nurse record for this user
            $nStmt = $this->db->prepare("SELECT nurse_id FROM nurses WHERE user_id = ? AND is_active = 1 LIMIT 1");
            $nStmt->execute([$currentUser]);
            $nRow = $nStmt->fetch(PDO::FETCH_ASSOC);

            if (!$nRow) {
                echo json_encode(['leaves' => [], 'scope' => 'self']);
                return;
            }
            $conditions[] = 'l.nurse_id = ?';
            $params[]     = $nRow['nurse_id'];
        } else {
            // SUPERVISOR scoped to unit; ADMIN/MANAGER global
            if ($unitId && !in_array($role, [Rbac::ADMIN, Rbac::MANAGER], true)) {
                $conditions[] = 'n.unit_id = ?';
                $params[]     = $unitId;
            } elseif ($unitId) {
                $conditions[] = 'n.unit_id = ?';
                $params[]     = $unitId;
            }

            if ($nurseId) {
                $conditions[] = 'l.nurse_id = ?';
                $params[]     = $nurseId;
            }
        }

        if ($status && in_array($status, ['PENDING', 'APPROVED', 'REJECTED', 'CANCELLED'], true)) {
            $conditions[] = 'l.status = ?';
            $params[]     = $status;
        }

        $where = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';

        $stmt = $this->db->prepare("
            SELECT l.leave_id, l.nurse_id,
                   n.full_name_en, n.employee_id, n.unit_id,
                   su.unit_name_en,
                   l.leave_type, l.start_date, l.end_date,
                   DATEDIFF(l.end_date, l.start_date) + 1 AS duration_days,
                   l.reason, l.status, l.decided_by,
                   du.email AS decided_by_email,
                   l.decision_note, l.created_at, l.updated_at
            FROM leaves l
            JOIN nurses n  ON n.nurse_id = l.nurse_id
            LEFT JOIN sub_units su ON su.unit_id = n.unit_id
            LEFT JOIN users du  ON du.user_id = l.decided_by
            {$where}
            ORDER BY l.created_at DESC
            LIMIT 500
        ");
        $stmt->execute($params);

        echo json_encode(['leaves' => $stmt->fetchAll(PDO::FETCH_ASSOC), 'scope' => $role]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=submit_leave  (any authenticated user)
    // Body: { leave_type, start_date, end_date, reason }
    // ─────────────────────────────────────────────────────────────────────────
    public function submit(array $input, ?string $currentUser): void
    {
        if (!$currentUser) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorised.']);
            return;
        }

        $leaveType  = strtoupper(trim($input['leave_type']  ?? ''));
        $startDate  = trim($input['start_date']  ?? '');
        $endDate    = trim($input['end_date']    ?? '');
        $reason     = trim($input['reason']      ?? '');

        // Validate
        if (!$leaveType || !$startDate || !$endDate) {
            http_response_code(400);
            echo json_encode(['error' => 'leave_type, start_date, and end_date are required.']);
            return;
        }
        if (!in_array($leaveType, self::LEAVE_TYPES, true)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid leave_type. Allowed: ' . implode(', ', self::LEAVE_TYPES)]);
            return;
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $startDate) || !strtotime($startDate)) {
            http_response_code(400);
            echo json_encode(['error' => 'start_date must be YYYY-MM-DD.']);
            return;
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $endDate) || !strtotime($endDate)) {
            http_response_code(400);
            echo json_encode(['error' => 'end_date must be YYYY-MM-DD.']);
            return;
        }
        if (strtotime($endDate) < strtotime($startDate)) {
            http_response_code(400);
            echo json_encode(['error' => 'end_date cannot be before start_date.']);
            return;
        }

        // Resolve nurse record
        $nStmt = $this->db->prepare("SELECT nurse_id FROM nurses WHERE user_id = ? AND is_active = 1 LIMIT 1");
        $nStmt->execute([$currentUser]);
        $nRow = $nStmt->fetch(PDO::FETCH_ASSOC);

        if (!$nRow) {
            http_response_code(403);
            echo json_encode(['error' => 'No active nurse profile linked to your account. Contact your administrator.']);
            return;
        }

        // Check for overlapping pending/approved leave
        $overlapStmt = $this->db->prepare("
            SELECT leave_id FROM leaves
            WHERE nurse_id = ?
              AND status IN ('PENDING', 'APPROVED')
              AND start_date <= ? AND end_date >= ?
            LIMIT 1
        ");
        $overlapStmt->execute([$nRow['nurse_id'], $endDate, $startDate]);
        if ($overlapStmt->fetch()) {
            http_response_code(409);
            echo json_encode(['error' => 'You already have a pending or approved leave that overlaps with these dates.']);
            return;
        }

        $leaveId = 'lv-' . bin2hex(random_bytes(6));
        $stmt    = $this->db->prepare("
            INSERT INTO leaves
                (leave_id, nurse_id, leave_type, start_date, end_date, reason, status)
            VALUES (?, ?, ?, ?, ?, ?, 'PENDING')
        ");
        $stmt->execute([$leaveId, $nRow['nurse_id'], $leaveType, $startDate, $endDate, $reason]);

        AuthMiddleware::auditEvent(
            $currentUser, AuthMiddleware::currentRole(),
            'LEAVE_SUBMITTED', 'leaves', $leaveId,
            null,
            ['nurse_id' => $nRow['nurse_id'], 'type' => $leaveType,
             'start' => $startDate, 'end' => $endDate]
        );

        echo json_encode([
            'success'  => true,
            'leave_id' => $leaveId,
            'message'  => 'Leave request submitted. Awaiting approval.',
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=decide_leave  (SUPERVISOR+ with leaves.approve permission)
    // Body: { leave_id, decision, decision_note? }
    // decision: APPROVED | REJECTED
    // ─────────────────────────────────────────────────────────────────────────
    public function decide(array $input, ?string $currentUser, string $currentRole): void
    {
        $leaveId      = trim($input['leave_id']      ?? '');
        $decision     = strtoupper(trim($input['decision']     ?? ''));
        $decisionNote = trim($input['decision_note'] ?? '');

        if (!$leaveId || !$decision) {
            http_response_code(400);
            echo json_encode(['error' => 'leave_id and decision are required.']);
            return;
        }
        if (!in_array($decision, self::DECIDE_VALUES, true)) {
            http_response_code(400);
            echo json_encode(['error' => 'decision must be APPROVED or REJECTED.']);
            return;
        }

        // Fetch the leave
        $leaveStmt = $this->db->prepare("
            SELECT l.leave_id, l.nurse_id, l.status, l.leave_type,
                   l.start_date, l.end_date, n.unit_id
            FROM leaves l
            JOIN nurses n ON n.nurse_id = l.nurse_id
            WHERE l.leave_id = ?
            LIMIT 1
        ");
        $leaveStmt->execute([$leaveId]);
        $leave = $leaveStmt->fetch(PDO::FETCH_ASSOC);

        if (!$leave) {
            http_response_code(404);
            echo json_encode(['error' => 'Leave request not found.']);
            return;
        }
        if ($leave['status'] !== 'PENDING') {
            http_response_code(409);
            echo json_encode(['error' => "Leave is already {$leave['status']} — cannot re-decide."]);
            return;
        }

        // SUPERVISOR: must be scoped to the nurse's unit
        if ($currentRole === Rbac::SUPERVISOR && $leave['unit_id']) {
            AuthMiddleware::requireUnitScope($leave['unit_id']);
        }

        $stmt = $this->db->prepare("
            UPDATE leaves
            SET status = ?, decided_by = ?, decision_note = ?, updated_at = NOW()
            WHERE leave_id = ?
        ");
        $stmt->execute([$decision, $currentUser, $decisionNote, $leaveId]);

        // If approved, create corresponding shift OFF cells for each day
        if ($decision === 'APPROVED' && $leave['unit_id']) {
            $this->applyLeaveToShifts($leave, $currentUser, $currentRole);
        }

        AuthMiddleware::auditEvent(
            $currentUser, $currentRole,
            "LEAVE_{$decision}", 'leaves', $leaveId,
            ['status' => 'PENDING'],
            ['status' => $decision, 'nurse_id' => $leave['nurse_id'],
             'start' => $leave['start_date'], 'end' => $leave['end_date']]
        );

        echo json_encode([
            'success'  => true,
            'leave_id' => $leaveId,
            'decision' => $decision,
            'message'  => "Leave request {$decision}.",
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PRIVATE: Write leave-type shift codes for the approved leave period
    // ─────────────────────────────────────────────────────────────────────────
    private function applyLeaveToShifts(array $leave, string $currentUser, string $currentRole): void
    {
        // Map leave types to shift codes
        $codeMap = [
            'ANNUAL'    => 'AL',
            'SICK'      => 'SL',
            'EMERGENCY' => 'SL',
            'MATERNITY' => 'AL',
            'PATERNITY' => 'AL',
            'UNPAID'    => 'OFF',
            'STUDY'     => 'AL',
        ];
        $shiftCode = $codeMap[$leave['leave_type']] ?? 'OFF';

        $period = new \DatePeriod(
            new \DateTime($leave['start_date']),
            new \DateInterval('P1D'),
            (new \DateTime($leave['end_date']))->modify('+1 day')
        );

        foreach ($period as $day) {
            $dateStr = $day->format('Y-m-d');

            $check = $this->db->prepare("
                SELECT shift_id FROM shifts
                WHERE unit_id = ? AND nurse_id = ? AND shift_date = ?
                LIMIT 1
            ");
            $check->execute([$leave['unit_id'], $leave['nurse_id'], $dateStr]);
            $existing = $check->fetch(PDO::FETCH_ASSOC);

            if ($existing) {
                $this->db->prepare("
                    UPDATE shifts SET shift_code = ?, updated_by = ?, updated_at = NOW()
                    WHERE shift_id = ?
                ")->execute([$shiftCode, $currentUser, $existing['shift_id']]);
            } else {
                $newId = 'sh-' . bin2hex(random_bytes(6));
                $this->db->prepare("
                    INSERT INTO shifts
                        (shift_id, unit_id, nurse_id, shift_date, shift_code, is_open, created_by, updated_by)
                    VALUES (?, ?, ?, ?, ?, 0, ?, ?)
                ")->execute([
                    $newId, $leave['unit_id'], $leave['nurse_id'],
                    $dateStr, $shiftCode, $currentUser, $currentUser,
                ]);
            }
        }
    }
}
