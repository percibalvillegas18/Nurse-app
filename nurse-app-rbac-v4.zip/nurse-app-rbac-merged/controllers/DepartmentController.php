<?php
// controllers/DepartmentController.php – Department & Sub-Unit CRUD
namespace Controllers;

use Config\Database;
use Config\Rbac;
use Middleware\AuthMiddleware;
use PDO;

class DepartmentController
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET ?action=get_departments
    // Returns all active departments (open to authenticated users)
    // ─────────────────────────────────────────────────────────────────────────
    public function index(): void
    {
        $stmt = $this->db->query("
            SELECT d.dept_id, d.dept_code, d.dept_name_en, d.dept_name_ar,
                   d.is_active, d.created_at,
                   COUNT(DISTINCT u.unit_id) AS unit_count
            FROM departments d
            LEFT JOIN sub_units u ON u.dept_id = d.dept_id AND u.is_active = 1
            WHERE d.is_active = 1
            GROUP BY d.dept_id
            ORDER BY d.dept_name_en
        ");
        echo json_encode(['departments' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET ?action=get_sub_units[&dept_id=X]
    // Returns sub-units; optionally filtered by department
    // ─────────────────────────────────────────────────────────────────────────
    public function subUnits(): void
    {
        $deptId = $_GET['dept_id'] ?? null;

        if ($deptId) {
            $stmt = $this->db->prepare("
                SELECT u.unit_id, u.unit_code, u.unit_name_en, u.unit_name_ar,
                       u.dept_id, d.dept_name_en, u.bed_count, u.is_active
                FROM sub_units u
                JOIN departments d ON d.dept_id = u.dept_id
                WHERE u.dept_id = ? AND u.is_active = 1
                ORDER BY u.unit_name_en
            ");
            $stmt->execute([$deptId]);
        } else {
            $stmt = $this->db->query("
                SELECT u.unit_id, u.unit_code, u.unit_name_en, u.unit_name_ar,
                       u.dept_id, d.dept_name_en, u.bed_count, u.is_active
                FROM sub_units u
                JOIN departments d ON d.dept_id = u.dept_id
                WHERE u.is_active = 1
                ORDER BY d.dept_name_en, u.unit_name_en
            ");
        }

        echo json_encode(['units' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=save_department  (ADMIN only)
    // Body: { dept_id?, dept_code, dept_name_en, dept_name_ar }
    // ─────────────────────────────────────────────────────────────────────────
    public function saveDept(array $input, string $currentRole): void
    {
        $deptId    = trim($input['dept_id']      ?? '');
        $code      = strtoupper(trim($input['dept_code']    ?? ''));
        $nameEn    = trim($input['dept_name_en'] ?? '');
        $nameAr    = trim($input['dept_name_ar'] ?? '');

        if (!$code || !$nameEn) {
            http_response_code(400);
            echo json_encode(['error' => 'dept_code and dept_name_en are required.']);
            return;
        }

        if ($deptId) {
            // UPDATE
            $stmt = $this->db->prepare("
                UPDATE departments
                SET dept_code = ?, dept_name_en = ?, dept_name_ar = ?, updated_at = NOW()
                WHERE dept_id = ?
            ");
            $stmt->execute([$code, $nameEn, $nameAr, $deptId]);

            AuthMiddleware::auditEvent(
                AuthMiddleware::currentUser(), $currentRole,
                'DEPT_UPDATED', 'departments', $deptId,
                null, ['code' => $code, 'name_en' => $nameEn]
            );
            echo json_encode(['success' => true, 'dept_id' => $deptId, 'message' => 'Department updated.']);
        } else {
            // INSERT
            $newId = 'dept-' . bin2hex(random_bytes(6));
            $stmt  = $this->db->prepare("
                INSERT INTO departments (dept_id, dept_code, dept_name_en, dept_name_ar, is_active)
                VALUES (?, ?, ?, ?, 1)
            ");
            $stmt->execute([$newId, $code, $nameEn, $nameAr]);

            AuthMiddleware::auditEvent(
                AuthMiddleware::currentUser(), $currentRole,
                'DEPT_CREATED', 'departments', $newId,
                null, ['code' => $code, 'name_en' => $nameEn]
            );
            echo json_encode(['success' => true, 'dept_id' => $newId, 'message' => 'Department created.']);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=save_sub_unit  (ADMIN / MANAGER)
    // Body: { unit_id?, dept_id, unit_code, unit_name_en, unit_name_ar, bed_count }
    // ─────────────────────────────────────────────────────────────────────────
    public function saveSubUnit(array $input, string $currentRole): void
    {
        $unitId  = trim($input['unit_id']     ?? '');
        $deptId  = trim($input['dept_id']     ?? '');
        $code    = strtoupper(trim($input['unit_code']    ?? ''));
        $nameEn  = trim($input['unit_name_en'] ?? '');
        $nameAr  = trim($input['unit_name_ar'] ?? '');
        $beds    = (int)($input['bed_count']  ?? 0);

        if (!$deptId || !$code || !$nameEn) {
            http_response_code(400);
            echo json_encode(['error' => 'dept_id, unit_code, and unit_name_en are required.']);
            return;
        }

        if ($unitId) {
            $stmt = $this->db->prepare("
                UPDATE sub_units
                SET dept_id = ?, unit_code = ?, unit_name_en = ?, unit_name_ar = ?,
                    bed_count = ?, updated_at = NOW()
                WHERE unit_id = ?
            ");
            $stmt->execute([$deptId, $code, $nameEn, $nameAr, $beds, $unitId]);

            AuthMiddleware::auditEvent(
                AuthMiddleware::currentUser(), $currentRole,
                'UNIT_UPDATED', 'sub_units', $unitId,
                null, ['code' => $code, 'name_en' => $nameEn]
            );
            echo json_encode(['success' => true, 'unit_id' => $unitId, 'message' => 'Sub-unit updated.']);
        } else {
            $newId = 'u-' . bin2hex(random_bytes(5));
            $stmt  = $this->db->prepare("
                INSERT INTO sub_units
                    (unit_id, dept_id, unit_code, unit_name_en, unit_name_ar, bed_count, is_active)
                VALUES (?, ?, ?, ?, ?, ?, 1)
            ");
            $stmt->execute([$newId, $deptId, $code, $nameEn, $nameAr, $beds]);

            AuthMiddleware::auditEvent(
                AuthMiddleware::currentUser(), $currentRole,
                'UNIT_CREATED', 'sub_units', $newId,
                null, ['code' => $code, 'dept_id' => $deptId]
            );
            echo json_encode(['success' => true, 'unit_id' => $newId, 'message' => 'Sub-unit created.']);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=delete_department  (ADMIN only)
    // Body: { dept_id }
    // ─────────────────────────────────────────────────────────────────────────
    public function deleteDept(array $input, string $currentRole): void
    {
        $deptId = trim($input['dept_id'] ?? '');
        if (!$deptId) {
            http_response_code(400);
            echo json_encode(['error' => 'dept_id is required.']);
            return;
        }

        // Soft-delete: mark as inactive rather than hard delete
        $stmt = $this->db->prepare("UPDATE departments SET is_active = 0, updated_at = NOW() WHERE dept_id = ?");
        $stmt->execute([$deptId]);

        if ($stmt->rowCount() === 0) {
            http_response_code(404);
            echo json_encode(['error' => 'Department not found.']);
            return;
        }

        AuthMiddleware::auditEvent(
            AuthMiddleware::currentUser(), $currentRole,
            'DEPT_DELETED', 'departments', $deptId,
            ['dept_id' => $deptId], null
        );
        echo json_encode(['success' => true, 'message' => 'Department deactivated.']);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=delete_sub_unit  (ADMIN only)
    // Body: { unit_id }
    // ─────────────────────────────────────────────────────────────────────────
    public function deleteSubUnit(array $input, string $currentRole): void
    {
        $unitId = trim($input['unit_id'] ?? '');
        if (!$unitId) {
            http_response_code(400);
            echo json_encode(['error' => 'unit_id is required.']);
            return;
        }

        $stmt = $this->db->prepare("UPDATE sub_units SET is_active = 0, updated_at = NOW() WHERE unit_id = ?");
        $stmt->execute([$unitId]);

        if ($stmt->rowCount() === 0) {
            http_response_code(404);
            echo json_encode(['error' => 'Sub-unit not found.']);
            return;
        }

        AuthMiddleware::auditEvent(
            AuthMiddleware::currentUser(), $currentRole,
            'UNIT_DELETED', 'sub_units', $unitId,
            ['unit_id' => $unitId], null
        );
        echo json_encode(['success' => true, 'message' => 'Sub-unit deactivated.']);
    }
}
