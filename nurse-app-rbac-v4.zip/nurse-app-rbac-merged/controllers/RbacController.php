<?php
// controllers/RbacController.php – Access Matrix CRUD & Audit Log API
namespace Controllers;

use Config\Database;
use Config\Rbac;
use Middleware\AuthMiddleware;
use PDO;

class RbacController
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET ?action=rbac_list_users
    // Returns users with their current active roles and scopes
    // ─────────────────────────────────────────────────────────────────────────
    public function listUsers(): void
    {
        AuthMiddleware::requirePermission('users', 'read');

        // Layer 2: optional unit_id filters to global + unit + parent-department scopes
        $unitId = $_GET['unit_id'] ?? null;
        $where  = '';
        $params = [];
        if ($unitId) {
            $where = "WHERE EXISTS (
                SELECT 1 FROM user_roles ur2
                WHERE ur2.user_id = u.user_id
                  AND ur2.is_active = 1
                  AND (ur2.effective_to IS NULL OR ur2.effective_to >= CURDATE())
                  AND (
                        ur2.scope_type = 'global'
                     OR (ur2.scope_type = 'unit' AND ur2.scope_id = ?)
                     OR (ur2.scope_type = 'department'
                         AND ur2.scope_id = (SELECT department_id FROM units WHERE unit_id = ? LIMIT 1))
                  )
            )";
            $params = [$unitId, $unitId];
        }

        // R4: pack user_role_id so Revoke works. Format: id|code|scope_type[|scope_id]
        $sql = "
            SELECT
                u.user_id, u.email, u.is_active,
                u.last_login_at, u.failed_attempts,
                GROUP_CONCAT(
                    CONCAT(ur.user_role_id, '|', r.role_code, '|', ur.scope_type,
                           IFNULL(CONCAT('|', ur.scope_id), ''))
                    ORDER BY r.hierarchy_level DESC SEPARATOR ','
                ) AS roles_raw
            FROM users u
            LEFT JOIN user_roles ur ON ur.user_id = u.user_id AND ur.is_active = 1
                AND (ur.effective_to IS NULL OR ur.effective_to >= CURDATE())
            LEFT JOIN roles r ON r.role_id = ur.role_id
            {$where}
            GROUP BY u.user_id
            ORDER BY u.email
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);

        $users = [];
        $scopedCount = 0;
        $globalCount = 0;
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $roles = [];
            $hasGlobal = false;
            $hasScoped = false;
            if ($row['roles_raw']) {
                foreach (explode(',', $row['roles_raw']) as $part) {
                    $bits = explode('|', $part);
                    $scopeType = $bits[2] ?? 'global';
                    $roles[] = [
                        'user_role_id' => $bits[0] ?? null,
                        'role_code'    => $bits[1] ?? '',
                        'scope_type'   => $scopeType,
                        'scope_id'     => $bits[3] ?? null,
                    ];
                    if ($scopeType === 'global') {
                        $hasGlobal = true;
                    } else {
                        $hasScoped = true;
                    }
                }
            }
            if ($hasGlobal) {
                $globalCount++;
            }
            if ($hasScoped) {
                $scopedCount++;
            }
            $users[] = [
                'user_id'         => $row['user_id'],
                'email'           => $row['email'],
                'is_active'       => (bool)$row['is_active'],
                'last_login_at'   => $row['last_login_at'],
                'failed_attempts' => (int)$row['failed_attempts'],
                'roles'           => $roles,
            ];
        }
        echo json_encode([
            'users'        => $users,
            'unit_id'      => $unitId,
            'scoped_count' => $scopedCount,
            'global_count' => $globalCount,
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET ?action=rbac_list_roles
    // ─────────────────────────────────────────────────────────────────────────
    public function listRoles(): void
    {
        AuthMiddleware::requirePermission('users', 'read');

        $stmt = $this->db->query("
            SELECT role_id, role_code, role_name_en, role_name_ar,
                   description, hierarchy_level, is_system_role, is_active
            FROM roles ORDER BY hierarchy_level DESC
        ");
        echo json_encode(['roles' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET ?action=rbac_list_permissions
    // ─────────────────────────────────────────────────────────────────────────
    public function listPermissions(): void
    {
        AuthMiddleware::requirePermission('users', 'read');

        $stmt = $this->db->query("
            SELECT p.permission_id, p.resource, p.action, p.scope, p.description,
                   GROUP_CONCAT(r.role_code ORDER BY r.hierarchy_level DESC SEPARATOR ',') AS granted_to_roles
            FROM permissions p
            LEFT JOIN role_permissions rp ON rp.permission_id = p.permission_id
            LEFT JOIN roles r             ON r.role_id = rp.role_id
            GROUP BY p.permission_id
            ORDER BY p.resource, p.action
        ");
        echo json_encode(['permissions' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=rbac_assign_role
    // Body: { user_id, role_code, scope_type, scope_id, effective_from, effective_to, reason }
    // ─────────────────────────────────────────────────────────────────────────
    public function assignRole(array $input, bool $quiet = false): ?array
    {
        AuthMiddleware::requirePermission('users', 'assign_role');

        $targetUserId = $input['user_id']      ?? null;
        $roleCode     = Rbac::normalise((string)($input['role_code'] ?? ''));
        $scopeType    = $input['scope_type']   ?? 'global';
        $scopeId      = $input['scope_id']     ?? null;
        $from         = $input['effective_from'] ?? date('Y-m-d');
        $to           = $input['effective_to']   ?? null;
        $reason       = substr($input['reason'] ?? '', 0, 500);

        if (!$targetUserId || !$roleCode) {
            if ($quiet) return ['ok' => false, 'error' => 'user_id and role_code are required.'];
            http_response_code(400);
            echo json_encode(['error' => 'user_id and role_code are required.']);
            return null;
        }
        if (!in_array($scopeType, ['global', 'department', 'unit'], true)) {
            if ($quiet) return ['ok' => false, 'error' => 'Invalid scope_type.'];
            http_response_code(400);
            echo json_encode(['error' => 'Invalid scope_type. Use global, department, or unit.']);
            return null;
        }
        if ($scopeType === 'global') {
            $scopeId = null;
        } elseif ($scopeId === null || $scopeId === '') {
            if ($quiet) return ['ok' => false, 'error' => 'scope_id required for department/unit.'];
            http_response_code(400);
            echo json_encode(['error' => 'scope_id is required when scope_type is department or unit.']);
            return null;
        }

        // Target user must exist and preferably be active
        $userStmt = $this->db->prepare('SELECT user_id, is_active, email FROM users WHERE user_id = ? LIMIT 1');
        $userStmt->execute([$targetUserId]);
        $target = $userStmt->fetch(PDO::FETCH_ASSOC);
        if (!$target) {
            if ($quiet) return ['ok' => false, 'error' => 'Target user not found.'];
            http_response_code(404);
            echo json_encode(['error' => 'Target user not found.']);
            return null;
        }

        // Resolve role_id
        $stmt = $this->db->prepare("SELECT role_id FROM roles WHERE role_code = ? AND is_active = 1");
        $stmt->execute([$roleCode]);
        $role = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$role) {
            if ($quiet) return ['ok' => false, 'error' => "Role [{$roleCode}] not found."];
            http_response_code(404);
            echo json_encode(['error' => "Role [{$roleCode}] not found."]);
            return null;
        }

        // Prevent duplicate active assignment (same role + scope_type + scope_id)
        $check = $this->db->prepare("
            SELECT user_role_id FROM user_roles
            WHERE user_id = ? AND role_id = ? AND scope_type = ?
              AND (
                    (? IS NULL AND scope_id IS NULL)
                 OR (scope_id <=> ?)
              )
              AND is_active = 1
              AND (effective_to IS NULL OR effective_to >= CURDATE())
            LIMIT 1
        ");
        $check->execute([$targetUserId, $role['role_id'], $scopeType, $scopeId, $scopeId]);
        if ($check->fetch()) {
            if ($quiet) return ['ok' => false, 'error' => 'User already has this role with the same scope.'];
            http_response_code(409);
            echo json_encode(['error' => 'User already has this role with the same scope.']);
            return null;
        }

        $userRoleId = sprintf('ur-%s', bin2hex(random_bytes(8)));
        $grantedBy  = AuthMiddleware::currentUser();

        $ins = $this->db->prepare("
            INSERT INTO user_roles
                (user_role_id, user_id, role_id, scope_type, scope_id,
                 effective_from, effective_to, granted_by, reason, is_active)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
        ");
        $ins->execute([
            $userRoleId, $targetUserId, $role['role_id'],
            $scopeType, $scopeId, $from, $to ?: null, $grantedBy, $reason
        ]);

        AuthMiddleware::auditEvent(
            $grantedBy, AuthMiddleware::currentRole(),
            'ROLE_ASSIGNED', 'user_roles', $userRoleId,
            null,
            [
                'target_user' => $targetUserId,
                'target_email'=> $target['email'] ?? null,
                'role'        => $roleCode,
                'scope'       => $scopeType,
                'scope_id'    => $scopeId,
                'reason'      => $reason,
            ]
        );

        $result = [
            'success'      => true,
            'user_role_id' => $userRoleId,
            'user_id'      => $targetUserId,
            'role_code'    => $roleCode,
            'scope_type'   => $scopeType,
            'scope_id'     => $scopeId,
            'message'      => "Role [{$roleCode}] assigned successfully.",
        ];
        if (!$quiet) {
            echo json_encode($result);
        }
        return $result;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=rbac_revoke_role
    // Body: { user_role_id, reason }
    // ─────────────────────────────────────────────────────────────────────────
    public function revokeRole(array $input): void
    {
        AuthMiddleware::requirePermission('users', 'assign_role');

        $userRoleId = $input['user_role_id'] ?? null;
        $reason     = substr($input['reason'] ?? '', 0, 500);
        if (!$userRoleId) {
            http_response_code(400);
            echo json_encode(['error' => 'user_role_id is required.']);
            return;
        }

        // Fetch before update for audit
        $before = $this->db->prepare("
            SELECT ur.*, r.role_code FROM user_roles ur
            JOIN roles r ON r.role_id = ur.role_id
            WHERE ur.user_role_id = ? AND ur.is_active = 1
        ");
        $before->execute([$userRoleId]);
        $old = $before->fetch(PDO::FETCH_ASSOC);
        if (!$old) {
            http_response_code(404);
            echo json_encode(['error' => 'Active role assignment not found.']);
            return;
        }

        $this->db->prepare("UPDATE user_roles SET is_active = 0, effective_to = CURDATE() WHERE user_role_id = ?")
                 ->execute([$userRoleId]);

        AuthMiddleware::auditEvent(
            AuthMiddleware::currentUser(), AuthMiddleware::currentRole(),
            'ROLE_REVOKED', 'user_roles', $userRoleId,
            ['role' => $old['role_code'], 'user_id' => $old['user_id']],
            ['reason' => $reason]
        );

        echo json_encode(['success' => true, 'message' => "Role [{$old['role_code']}] revoked."]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=rbac_bulk_assign
    // Body: { user_ids: [], role_code, scope_type, scope_id, effective_from, effective_to, reason }
    // ─────────────────────────────────────────────────────────────────────────
    public function bulkAssign(array $input): void
    {
        AuthMiddleware::requirePermission('users', 'assign_role');

        $userIds = $input['user_ids'] ?? [];
        if (!is_array($userIds) || count($userIds) < 1) {
            http_response_code(400);
            echo json_encode(['error' => 'user_ids array is required.']);
            return;
        }

        $assigned = [];
        $failed   = [];
        foreach ($userIds as $uid) {
            $one = $this->assignRole(array_merge($input, ['user_id' => $uid]), true);
            if ($one && !empty($one['success'])) {
                $assigned[] = $one;
            } else {
                $failed[] = [
                    'user_id' => $uid,
                    'error'   => $one['error'] ?? 'Assignment failed',
                ];
            }
        }

        echo json_encode([
            'success'       => count($failed) === 0,
            'assigned'      => $assigned,
            'failed'        => $failed,
            'assigned_count'=> count($assigned),
            'failed_count'  => count($failed),
            'message'       => sprintf('%d assigned, %d failed.', count($assigned), count($failed)),
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET ?action=rbac_audit_log&limit=50&offset=0
    // ─────────────────────────────────────────────────────────────────────────
    public function auditLog(): void
    {
        AuthMiddleware::requirePermission('audit', 'view');

        $limit  = max(1, min(200, (int)($_GET['limit']  ?? 50)));
        $offset = max(0, (int)($_GET['offset'] ?? 0));
        $filter = $_GET['action_filter'] ?? null;
        $unitId = $_GET['unit_id'] ?? null;
        $actor  = trim((string)($_GET['actor'] ?? ''));
        $q      = trim((string)($_GET['q'] ?? ''));
        $from   = $_GET['date_from'] ?? null;
        $to     = $_GET['date_to'] ?? null;
        $resourceType = $_GET['resource_type'] ?? null;

        $clauses = [];
        $params  = [];
        if ($filter) {
            $clauses[] = 'action = ?';
            $params[]  = $filter;
        }
        if ($unitId) {
            $clauses[] = '(resource_id = ? OR resource_id IS NULL)';
            $params[]  = $unitId;
        }
        if ($actor !== '') {
            $clauses[] = '(actor_user_id LIKE ? OR actor_role LIKE ?)';
            $params[]  = '%' . $actor . '%';
            $params[]  = '%' . $actor . '%';
        }
        if ($q !== '') {
            $clauses[] = '(action LIKE ? OR resource_type LIKE ? OR resource_id LIKE ?
                          OR target_user_id LIKE ? OR actor_user_id LIKE ?
                          OR CAST(old_value AS CHAR) LIKE ? OR CAST(new_value AS CHAR) LIKE ?)';
            $like = '%' . $q . '%';
            array_push($params, $like, $like, $like, $like, $like, $like, $like);
        }
        if ($from) {
            $clauses[] = 'created_at >= ?';
            $params[]  = $from . ' 00:00:00';
        }
        if ($to) {
            $clauses[] = 'created_at <= ?';
            $params[]  = $to . ' 23:59:59';
        }
        if ($resourceType) {
            $clauses[] = 'resource_type = ?';
            $params[]  = $resourceType;
        }
        $where = $clauses ? ('WHERE ' . implode(' AND ', $clauses)) : '';

        $countStmt = $this->db->prepare("SELECT COUNT(*) FROM rbac_audit_log {$where}");
        $countStmt->execute($params);
        $total = (int) $countStmt->fetchColumn();

        $stmt = $this->db->prepare("
            SELECT log_id, actor_user_id, actor_role, action,
                   resource_type, resource_id, target_user_id,
                   old_value, new_value, ip_address, user_agent, created_at
            FROM rbac_audit_log
            {$where}
            ORDER BY created_at DESC, log_id DESC
            LIMIT ? OFFSET ?
        ");
        $pageParams = array_merge($params, [$limit, $offset]);
        $stmt->execute($pageParams);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($rows as &$row) {
            foreach (['old_value', 'new_value'] as $jsonCol) {
                if (isset($row[$jsonCol]) && is_string($row[$jsonCol]) && $row[$jsonCol] !== '') {
                    $decoded = json_decode($row[$jsonCol], true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        $row[$jsonCol] = $decoded;
                    }
                }
            }
        }
        unset($row);

        echo json_encode([
            'audit_log' => $rows,
            'total'     => $total,
            'limit'     => $limit,
            'offset'    => $offset,
            'unit_id'   => $unitId,
            'has_more'  => ($offset + count($rows)) < $total,
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET ?action=rbac_role_impact&role_code=SUPERVISOR
    // Returns what permissions a role has + how many users would be affected
    // ─────────────────────────────────────────────────────────────────────────
    public function roleImpact(): void
    {
        AuthMiddleware::requirePermission('users', 'read');

        $roleCode = strtoupper($_GET['role_code'] ?? '');
        $stmt = $this->db->prepare("
            SELECT r.role_id, r.role_code, r.role_name_en, r.description,
                   COUNT(DISTINCT ur.user_id) AS user_count
            FROM roles r
            LEFT JOIN user_roles ur ON ur.role_id = r.role_id AND ur.is_active = 1
            WHERE r.role_code = ?
            GROUP BY r.role_id
        ");
        $stmt->execute([$roleCode]);
        $role = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$role) {
            http_response_code(404);
            echo json_encode(['error' => 'Role not found.']);
            return;
        }

        echo json_encode([
            'role'        => $role,
            'permissions' => Rbac::permissionsFor($roleCode),
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=rbac_create_user
    // Body: { email, password, role_code?, scope_type?, scope_id? }
    // ADMIN only (users.create). Optionally assigns an initial role.
    // ─────────────────────────────────────────────────────────────────────────
    public function createUser(array $input): void
    {
        AuthMiddleware::requirePermission('users', 'create');

        $email    = trim(strtolower($input['email'] ?? ''));
        $password = $input['password'] ?? '';
        $roleCode = isset($input['role_code']) ? Rbac::normalise((string)$input['role_code']) : null;
        $scopeType = $input['scope_type'] ?? 'global';
        $scopeId   = $input['scope_id'] ?? null;

        if ($email === '' || $password === '') {
            http_response_code(400);
            echo json_encode(['error' => 'Email and password are required.']);
            return;
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid email format.']);
            return;
        }
        if (strlen($password) < 8) {
            http_response_code(400);
            echo json_encode(['error' => 'Password must be at least 8 characters.']);
            return;
        }
        if (!in_array($scopeType, ['global', 'department', 'unit'], true)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid scope_type.']);
            return;
        }
        if ($scopeType !== 'global' && ($scopeId === null || $scopeId === '')) {
            http_response_code(400);
            echo json_encode(['error' => 'scope_id is required for department/unit scope.']);
            return;
        }

        $exists = $this->db->prepare('SELECT user_id FROM users WHERE email = ? LIMIT 1');
        $exists->execute([$email]);
        if ($exists->fetchColumn()) {
            http_response_code(409);
            echo json_encode(['error' => 'A user with this email already exists.']);
            return;
        }

        $userId = sprintf('u-%s', bin2hex(random_bytes(8)));
        $hash   = password_hash($password, PASSWORD_DEFAULT);

        try {
            $this->db->beginTransaction();

            // users table may have a legacy `role` column from migration seed pattern
            try {
                $this->db->prepare("
                    INSERT INTO users (user_id, email, password_hash, role, is_active, password_changed_at)
                    VALUES (?, ?, ?, ?, 1, NOW())
                ")->execute([$userId, $email, $hash, $roleCode ?: Rbac::STAFF_NURSE]);
            } catch (\Throwable $e) {
                $this->db->prepare("
                    INSERT INTO users (user_id, email, password_hash, is_active, password_changed_at)
                    VALUES (?, ?, ?, 1, NOW())
                ")->execute([$userId, $email, $hash]);
            }

            $userRoleId = null;
            if ($roleCode) {
                $roleStmt = $this->db->prepare('SELECT role_id FROM roles WHERE role_code = ? AND is_active = 1 LIMIT 1');
                $roleStmt->execute([$roleCode]);
                $roleId = $roleStmt->fetchColumn();
                if (!$roleId) {
                    $this->db->rollBack();
                    http_response_code(400);
                    echo json_encode(['error' => "Unknown role_code: {$roleCode}"]);
                    return;
                }
                $userRoleId = sprintf('ur-%s', bin2hex(random_bytes(8)));
                $this->db->prepare("
                    INSERT INTO user_roles
                        (user_role_id, user_id, role_id, scope_type, scope_id, granted_by, reason, is_active)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 1)
                ")->execute([
                    $userRoleId,
                    $userId,
                    $roleId,
                    $scopeType,
                    $scopeType === 'global' ? null : $scopeId,
                    AuthMiddleware::currentUser(),
                    substr($input['reason'] ?? 'Created via Access Matrix', 0, 500),
                ]);
            }

            $this->db->commit();
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            http_response_code(500);
            echo json_encode(['error' => 'Failed to create user.', 'detail' => $e->getMessage()]);
            return;
        }

        AuthMiddleware::auditEvent(
            AuthMiddleware::currentUser(),
            AuthMiddleware::currentRole(),
            'USER_CREATED',
            'users',
            $userId,
            null,
            ['email' => $email, 'role_code' => $roleCode, 'scope_type' => $scopeType, 'scope_id' => $scopeId]
        );

        echo json_encode([
            'success'      => true,
            'user_id'      => $userId,
            'email'        => $email,
            'user_role_id' => $userRoleId,
            'message'      => 'User created successfully.',
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=rbac_update_user
    // Body: { user_id, email?, password?, is_active? }
    // ADMIN only (users.update). Soft fields only — roles use assign/revoke.
    // ─────────────────────────────────────────────────────────────────────────
    public function updateUser(array $input): void
    {
        AuthMiddleware::requirePermission('users', 'update');

        $userId = $input['user_id'] ?? null;
        if (!$userId) {
            http_response_code(400);
            echo json_encode(['error' => 'user_id is required.']);
            return;
        }

        $stmt = $this->db->prepare('SELECT user_id, email, is_active FROM users WHERE user_id = ? LIMIT 1');
        $stmt->execute([$userId]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$existing) {
            http_response_code(404);
            echo json_encode(['error' => 'User not found.']);
            return;
        }

        $newEmail  = array_key_exists('email', $input) ? trim(strtolower((string)$input['email'])) : null;
        $password  = array_key_exists('password', $input) ? (string)$input['password'] : null;
        $isActive  = array_key_exists('is_active', $input) ? (int)((bool)$input['is_active']) : null;

        if ($newEmail !== null) {
            if ($newEmail === '' || !filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
                http_response_code(400);
                echo json_encode(['error' => 'Invalid email format.']);
                return;
            }
            $dup = $this->db->prepare('SELECT user_id FROM users WHERE email = ? AND user_id <> ? LIMIT 1');
            $dup->execute([$newEmail, $userId]);
            if ($dup->fetchColumn()) {
                http_response_code(409);
                echo json_encode(['error' => 'A user with this email already exists.']);
                return;
            }
        }
        if ($password !== null && $password !== '' && strlen($password) < 8) {
            http_response_code(400);
            echo json_encode(['error' => 'Password must be at least 8 characters.']);
            return;
        }

        $sets   = [];
        $params = [];
        if ($newEmail !== null) {
            $sets[]   = 'email = ?';
            $params[] = $newEmail;
        }
        if ($password !== null && $password !== '') {
            $sets[]   = 'password_hash = ?';
            $params[] = password_hash($password, PASSWORD_DEFAULT);
            $sets[]   = 'password_changed_at = NOW()';
            $sets[]   = 'failed_attempts = 0';
            $sets[]   = 'locked_until = NULL';
        }
        if ($isActive !== null) {
            $sets[]   = 'is_active = ?';
            $params[] = $isActive;
        }
        if (!$sets) {
            http_response_code(400);
            echo json_encode(['error' => 'No updatable fields provided (email, password, is_active).']);
            return;
        }

        $params[] = $userId;
        $this->db->prepare('UPDATE users SET ' . implode(', ', $sets) . ' WHERE user_id = ?')
                 ->execute($params);

        AuthMiddleware::auditEvent(
            AuthMiddleware::currentUser(),
            AuthMiddleware::currentRole(),
            'USER_UPDATED',
            'users',
            $userId,
            ['email' => $existing['email'], 'is_active' => $existing['is_active']],
            ['email' => $newEmail, 'is_active' => $isActive, 'password_changed' => ($password !== null && $password !== '')]
        );

        echo json_encode(['success' => true, 'user_id' => $userId, 'message' => 'User updated successfully.']);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=rbac_delete_user
    // Body: { user_id, hard_delete?: bool }
    // ADMIN only (users.delete). Default is soft-delete (is_active = 0).
    // ─────────────────────────────────────────────────────────────────────────
    public function deleteUser(array $input): void
    {
        AuthMiddleware::requirePermission('users', 'delete');

        $userId     = $input['user_id'] ?? null;
        $hardDelete = !empty($input['hard_delete']);
        if (!$userId) {
            http_response_code(400);
            echo json_encode(['error' => 'user_id is required.']);
            return;
        }

        if ($userId === AuthMiddleware::currentUser()) {
            http_response_code(400);
            echo json_encode(['error' => 'You cannot delete your own account.']);
            return;
        }

        $stmt = $this->db->prepare('SELECT user_id, email, is_active FROM users WHERE user_id = ? LIMIT 1');
        $stmt->execute([$userId]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$existing) {
            http_response_code(404);
            echo json_encode(['error' => 'User not found.']);
            return;
        }

        try {
            $this->db->beginTransaction();
            if ($hardDelete) {
                $this->db->prepare('DELETE FROM user_roles WHERE user_id = ?')->execute([$userId]);
                $this->db->prepare('DELETE FROM users WHERE user_id = ?')->execute([$userId]);
            } else {
                $this->db->prepare('UPDATE users SET is_active = 0 WHERE user_id = ?')->execute([$userId]);
                $this->db->prepare("
                    UPDATE user_roles
                    SET is_active = 0, effective_to = CURDATE()
                    WHERE user_id = ? AND is_active = 1
                ")->execute([$userId]);
            }
            $this->db->commit();
        } catch (\Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            http_response_code(500);
            echo json_encode(['error' => 'Failed to delete user.', 'detail' => $e->getMessage()]);
            return;
        }

        AuthMiddleware::auditEvent(
            AuthMiddleware::currentUser(),
            AuthMiddleware::currentRole(),
            $hardDelete ? 'USER_DELETED' : 'USER_DEACTIVATED',
            'users',
            $userId,
            ['email' => $existing['email'], 'is_active' => $existing['is_active']],
            ['hard_delete' => $hardDelete]
        );

        echo json_encode([
            'success' => true,
            'user_id' => $userId,
            'message' => $hardDelete ? 'User permanently deleted.' : 'User deactivated.',
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=rbac_export_csv
    // Generates a CSV of current user→role assignments for ADMIN
    // ─────────────────────────────────────────────────────────────────────────
    public function exportCsv(): void
    {
        AuthMiddleware::requirePermission('reports', 'export');

        $stmt = $this->db->query("
            SELECT u.email, r.role_code, ur.scope_type, ur.scope_id,
                   ur.effective_from, ur.effective_to, ur.reason,
                   ur.is_active, ur.created_at
            FROM user_roles ur
            JOIN users u ON u.user_id = ur.user_id
            JOIN roles r ON r.role_id = ur.role_id
            ORDER BY u.email, r.hierarchy_level DESC
        ");

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $csv  = "email,role,scope_type,scope_id,effective_from,effective_to,reason,is_active,assigned_at\n";
        foreach ($rows as $r) {
            $csv .= implode(',', array_map(fn($v) => '"' . str_replace('"', '""', $v ?? '') . '"', $r)) . "\n";
        }

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="rbac_export_' . date('Ymd_His') . '.csv"');
        echo $csv;
    }
}
