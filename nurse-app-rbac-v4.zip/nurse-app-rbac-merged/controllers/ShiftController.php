<?php
// controllers/ShiftController.php – Shift Scheduling Matrix, Assignment & Publishing
namespace Controllers;

use Config\Database;
use Config\Rbac;
use Middleware\AuthMiddleware;
use PDO;

class ShiftController
{
    private PDO $db;

    // Allowed shift codes
    private const VALID_SHIFTS = ['M', 'A', 'N', 'OFF', 'AL', 'SL', 'H', ''];
    // M=Morning, A=Afternoon, N=Night, OFF=Day off, AL=Annual leave,
    // SL=Sick leave, H=Holiday, ''=Unassigned

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET ?action=get_shifts_matrix&unit_id=X&year=YYYY&month=MM
    // Returns the shift matrix for the requested unit + month as a 2D array.
    // ─────────────────────────────────────────────────────────────────────────
    public function matrix(array $params): void
    {
        $unitId = trim($params['unit_id'] ?? '');
        $year   = (int)($params['year']   ?? date('Y'));
        $month  = (int)($params['month']  ?? date('n'));

        if (!$unitId) {
            http_response_code(400);
            echo json_encode(['error' => 'unit_id is required.']);
            return;
        }
        if ($month < 1 || $month > 12) {
            http_response_code(400);
            echo json_encode(['error' => 'month must be between 1 and 12.']);
            return;
        }

        $daysInMonth = (int)date('t', mktime(0, 0, 0, $month, 1, $year));

        // Fetch nurses assigned to this unit
        $nurseStmt = $this->db->prepare("
            SELECT n.nurse_id, n.employee_id, n.full_name_en, n.full_name_ar,
                   n.job_title, n.employment_type
            FROM nurses n
            WHERE n.unit_id = ? AND n.is_active = 1
            ORDER BY n.full_name_en
        ");
        $nurseStmt->execute([$unitId]);
        $nurses = $nurseStmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($nurses)) {
            echo json_encode([
                'unit_id'      => $unitId,
                'year'         => $year,
                'month'        => $month,
                'days_in_month'=> $daysInMonth,
                'nurses'       => [],
                'shifts'       => [],
                'published'    => false,
            ]);
            return;
        }

        $nurseIds = array_column($nurses, 'nurse_id');
        $placeholders = implode(',', array_fill(0, count($nurseIds), '?'));

        // Fetch existing shift assignments for the month
        $shiftStmt = $this->db->prepare("
            SELECT s.nurse_id, s.shift_date, s.shift_code,
                   s.shift_id, s.is_open, s.notes
            FROM shifts s
            WHERE s.unit_id = ?
              AND YEAR(s.shift_date)  = ?
              AND MONTH(s.shift_date) = ?
              AND s.nurse_id IN ({$placeholders})
            ORDER BY s.shift_date, s.nurse_id
        ");
        $shiftStmt->execute(array_merge([$unitId, $year, $month], $nurseIds));
        $shiftRows = $shiftStmt->fetchAll(PDO::FETCH_ASSOC);

        // Build shift map: [nurse_id][day] = shift_code
        $shiftMap = [];
        foreach ($shiftRows as $r) {
            $day = (int)date('j', strtotime($r['shift_date']));
            $shiftMap[$r['nurse_id']][$day] = [
                'code'     => $r['shift_code'],
                'shift_id' => $r['shift_id'],
                'is_open'  => (bool)$r['is_open'],
                'notes'    => $r['notes'],
            ];
        }

        // Check publish status
        $pubStmt = $this->db->prepare("
            SELECT published_at FROM shift_publishes
            WHERE unit_id = ? AND pub_year = ? AND pub_month = ?
            LIMIT 1
        ");
        $pubStmt->execute([$unitId, $year, $month]);
        $pubRow = $pubStmt->fetch(PDO::FETCH_ASSOC);

        echo json_encode([
            'unit_id'       => $unitId,
            'year'          => $year,
            'month'         => $month,
            'days_in_month' => $daysInMonth,
            'nurses'        => $nurses,
            'shifts'        => $shiftMap,
            'published'     => (bool)$pubRow,
            'published_at'  => $pubRow['published_at'] ?? null,
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=save_shift_cell  (SUPERVISOR+)
    // Body: { unit_id, nurse_id, shift_date, shift_code, notes? }
    // ─────────────────────────────────────────────────────────────────────────
    public function assign(array $input, string $currentRole): void
    {
        $unitId    = trim($input['unit_id']    ?? '');
        $nurseId   = trim($input['nurse_id']   ?? '');
        $shiftDate = trim($input['shift_date'] ?? '');
        $shiftCode = strtoupper(trim($input['shift_code'] ?? ''));
        $notes     = trim($input['notes']      ?? '');

        // Validate inputs
        if (!$unitId || !$nurseId || !$shiftDate) {
            http_response_code(400);
            echo json_encode(['error' => 'unit_id, nurse_id, and shift_date are required.']);
            return;
        }
        if (!in_array($shiftCode, self::VALID_SHIFTS, true)) {
            http_response_code(400);
            echo json_encode(['error' => "Invalid shift_code. Allowed: " . implode(', ', array_filter(self::VALID_SHIFTS, fn($s) => $s !== ''))]);
            return;
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $shiftDate) || !strtotime($shiftDate)) {
            http_response_code(400);
            echo json_encode(['error' => 'shift_date must be YYYY-MM-DD format.']);
            return;
        }

        // UPSERT: update if exists, insert if not
        $checkStmt = $this->db->prepare("
            SELECT shift_id, shift_code FROM shifts
            WHERE unit_id = ? AND nurse_id = ? AND shift_date = ?
            LIMIT 1
        ");
        $checkStmt->execute([$unitId, $nurseId, $shiftDate]);
        $existing = $checkStmt->fetch(PDO::FETCH_ASSOC);

        $currentUser = AuthMiddleware::currentUser();

        if ($existing) {
            $stmt = $this->db->prepare("
                UPDATE shifts SET shift_code = ?, notes = ?, updated_by = ?, updated_at = NOW()
                WHERE shift_id = ?
            ");
            $stmt->execute([$shiftCode, $notes, $currentUser, $existing['shift_id']]);

            AuthMiddleware::auditEvent(
                $currentUser, $currentRole,
                'SHIFT_UPDATED', 'shifts', $existing['shift_id'],
                ['shift_code' => $existing['shift_code']],
                ['shift_code' => $shiftCode, 'nurse_id' => $nurseId, 'date' => $shiftDate]
            );
            echo json_encode(['success' => true, 'shift_id' => $existing['shift_id'], 'action' => 'updated']);
        } else {
            $newId = 'sh-' . bin2hex(random_bytes(6));
            $stmt  = $this->db->prepare("
                INSERT INTO shifts
                    (shift_id, unit_id, nurse_id, shift_date, shift_code,
                     notes, is_open, created_by, updated_by)
                VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?)
            ");
            $stmt->execute([$newId, $unitId, $nurseId, $shiftDate, $shiftCode,
                            $notes, $currentUser, $currentUser]);

            AuthMiddleware::auditEvent(
                $currentUser, $currentRole,
                'SHIFT_CREATED', 'shifts', $newId,
                null,
                ['shift_code' => $shiftCode, 'nurse_id' => $nurseId,
                 'unit_id' => $unitId, 'date' => $shiftDate]
            );
            echo json_encode(['success' => true, 'shift_id' => $newId, 'action' => 'created']);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=publish_unit_schedule  (SUPERVISOR+)
    // Body: { unit_id, year, month }
    // Publishes the current month's schedule — marks it read-only.
    // ─────────────────────────────────────────────────────────────────────────
    public function publish(array $input, string $currentRole): void
    {
        $unitId = trim($input['unit_id'] ?? '');
        $year   = (int)($input['year']   ?? date('Y'));
        $month  = (int)($input['month']  ?? date('n'));

        if (!$unitId) {
            http_response_code(400);
            echo json_encode(['error' => 'unit_id is required.']);
            return;
        }

        $currentUser = AuthMiddleware::currentUser();

        // Check if already published
        $check = $this->db->prepare("
            SELECT pub_id FROM shift_publishes
            WHERE unit_id = ? AND pub_year = ? AND pub_month = ?
        ");
        $check->execute([$unitId, $year, $month]);
        if ($check->fetch()) {
            http_response_code(409);
            echo json_encode(['error' => 'Schedule for this unit/month is already published.']);
            return;
        }

        $pubId = 'pub-' . bin2hex(random_bytes(6));
        $stmt  = $this->db->prepare("
            INSERT INTO shift_publishes (pub_id, unit_id, pub_year, pub_month, published_by, published_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([$pubId, $unitId, $year, $month, $currentUser]);

        AuthMiddleware::auditEvent(
            $currentUser, $currentRole,
            'SCHEDULE_PUBLISHED', 'shifts', $pubId,
            null, ['unit_id' => $unitId, 'year' => $year, 'month' => $month]
        );

        echo json_encode([
            'success'      => true,
            'pub_id'       => $pubId,
            'published_at' => date('Y-m-d H:i:s'),
            'message'      => "Schedule for {$year}-{$month} published for unit {$unitId}.",
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=claim_open_shift  (any authenticated nurse)
    // Body: { shift_id }
    // Nurse claims an open (unassigned) shift cell for themselves.
    // ─────────────────────────────────────────────────────────────────────────
    public function claim(array $input, ?string $currentUser): void
    {
        $shiftId = trim($input['shift_id'] ?? '');
        if (!$shiftId || !$currentUser) {
            http_response_code(400);
            echo json_encode(['error' => 'shift_id is required and you must be logged in.']);
            return;
        }

        // Look up the nurse record for this user
        $nurseStmt = $this->db->prepare("SELECT nurse_id FROM nurses WHERE user_id = ? AND is_active = 1 LIMIT 1");
        $nurseStmt->execute([$currentUser]);
        $nurseRow = $nurseStmt->fetch(PDO::FETCH_ASSOC);

        if (!$nurseRow) {
            http_response_code(403);
            echo json_encode(['error' => 'No active nurse profile linked to your account.']);
            return;
        }

        // Verify the shift is open and unassigned
        $shiftStmt = $this->db->prepare("
            SELECT shift_id, nurse_id, is_open, shift_date, unit_id, shift_code
            FROM shifts WHERE shift_id = ? LIMIT 1
        ");
        $shiftStmt->execute([$shiftId]);
        $shift = $shiftStmt->fetch(PDO::FETCH_ASSOC);

        if (!$shift) {
            http_response_code(404);
            echo json_encode(['error' => 'Shift not found.']);
            return;
        }
        if (!$shift['is_open']) {
            http_response_code(409);
            echo json_encode(['error' => 'This shift is not open for claiming.']);
            return;
        }
        if ($shift['nurse_id'] && $shift['nurse_id'] !== $nurseRow['nurse_id']) {
            http_response_code(409);
            echo json_encode(['error' => 'This shift has already been claimed.']);
            return;
        }

        $stmt = $this->db->prepare("
            UPDATE shifts
            SET nurse_id = ?, is_open = 0, updated_by = ?, updated_at = NOW()
            WHERE shift_id = ?
        ");
        $stmt->execute([$nurseRow['nurse_id'], $currentUser, $shiftId]);

        AuthMiddleware::auditEvent(
            $currentUser, AuthMiddleware::currentRole(),
            'SHIFT_CLAIMED', 'shifts', $shiftId,
            ['is_open' => true],
            ['nurse_id' => $nurseRow['nurse_id'], 'date' => $shift['shift_date'],
             'unit_id' => $shift['unit_id'], 'code' => $shift['shift_code']]
        );

        echo json_encode([
            'success'  => true,
            'shift_id' => $shiftId,
            'date'     => $shift['shift_date'],
            'code'     => $shift['shift_code'],
            'message'  => 'Shift claimed successfully.',
        ]);
    }
}
