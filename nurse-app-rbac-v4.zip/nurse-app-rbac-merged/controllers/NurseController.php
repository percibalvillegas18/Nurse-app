<?php
// controllers/NurseController.php – Nurse Profile CRUD
namespace Controllers;

use Config\Database;
use Config\Rbac;
use Middleware\AuthMiddleware;
use PDO;

class NurseController
{
    private PDO $db;

    // Max upload size: 5 MB per file
    private const MAX_FILE_BYTES = 5 * 1024 * 1024;

    // Allowed MIME types for document uploads
    private const ALLOWED_MIMES = [
        'application/pdf',
        'image/jpeg',
        'image/png',
    ];

    // Document fields accepted from the form
    private const DOC_FIELDS = [
        'passport_photo', 'academic_transcripts', 'dataflow_psv',
        'prometric_results', 'work_experience', 'good_standing_certificates',
        'medical_fitness_cert', 'communicable_disease_screening', 'police_clearance',
    ];

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // GET ?action=get_nurses[&unit_id=X&search=Z]
    // Returns field names the JS loadDirectory() expects:
    //   first_name_en, last_name_en, employee_number, identification_type,
    //   identification_number, unit_name_en, credential_number, days_to_expiry
    // ─────────────────────────────────────────────────────────────────────────
    public function index(): void
    {
        $role        = AuthMiddleware::currentRole();
        $currentUser = AuthMiddleware::currentUser();
        $unitId      = $_GET['unit_id'] ?? null;
        $search      = trim($_GET['search'] ?? '');

        // STAFF_NURSE: return only own record
        if ($role === Rbac::STAFF_NURSE) {
            $stmt = $this->db->prepare("
                SELECT n.nurse_id, n.employee_id, n.full_name_en, n.full_name_ar,
                       n.nationality, n.gender, n.phone, n.email,
                       n.job_title, n.specialisation, n.unit_id,
                       su.unit_name_en,
                       n.license_number, n.license_expiry, n.contract_start,
                       n.contract_end, n.employment_type, n.is_active,
                       DATEDIFF(n.license_expiry, CURDATE()) AS days_to_expiry,
                       n.created_at, n.updated_at
                FROM nurses n
                LEFT JOIN sub_units su ON su.unit_id = n.unit_id
                WHERE n.user_id = ? AND n.is_active = 1
                LIMIT 1
            ");
            $stmt->execute([$currentUser]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['nurses' => $this->normaliseRows($rows), 'scope' => 'self']);
            return;
        }

        // Build dynamic WHERE conditions
        $conditions = ['n.is_active = 1'];
        $params     = [];

        if ($unitId) {
            $conditions[] = 'n.unit_id = ?';
            $params[]     = $unitId;
        }

        if ($search) {
            $conditions[] = '(n.full_name_en LIKE ? OR n.employee_id LIKE ? OR n.email LIKE ?)';
            $like = "%{$search}%";
            array_push($params, $like, $like, $like);
        }

        $where = implode(' AND ', $conditions);
        $stmt  = $this->db->prepare("
            SELECT n.nurse_id, n.employee_id, n.full_name_en, n.full_name_ar,
                   n.nationality, n.gender, n.phone, n.email,
                   n.job_title, n.specialisation, n.unit_id,
                   su.unit_name_en, su.dept_id, d.dept_name_en,
                   n.license_number, n.license_expiry, n.contract_start,
                   n.contract_end, n.employment_type, n.is_active,
                   DATEDIFF(n.license_expiry, CURDATE()) AS days_to_expiry,
                   n.created_at, n.updated_at
            FROM nurses n
            LEFT JOIN sub_units su ON su.unit_id = n.unit_id
            LEFT JOIN departments d ON d.dept_id = su.dept_id
            WHERE {$where}
            ORDER BY n.full_name_en
            LIMIT 500
        ");
        $stmt->execute($params);

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['nurses' => $this->normaliseRows($rows), 'scope' => 'global']);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POST ?action=save_nurse_profile  (ADMIN / MANAGER)
    //
    // Accepts multipart/form-data (file uploads) OR JSON.
    // index.php merges $_POST into $input so this method always sees $input.
    //
    // Form field → DB column mappings:
    //   employee_number  → employee_id
    //   first_name_en + last_name_en → full_name_en
    //   first_name_ar + last_name_ar → full_name_ar
    //   phone_number     → phone
    //   gender MALE/FEMALE/OTHER → M/F/U
    //   primary_unit_id  → unit_id
    //   mumaris_id       → license_number  (Mumaris+ IS the credential number)
    //   employment_type  (passed directly)
    //
    // Returns: { success, nurse_id, documents }
    // ─────────────────────────────────────────────────────────────────────────
    public function save(array $input, string $currentRole): void
    {
        // ── field extraction & mapping ──────────────────────────────────────
        $nurseId   = trim($input['nurse_id'] ?? '');

        // employee_id: accept both 'employee_number' (form) and 'employee_id' (JSON)
        $employeeId = strtoupper(trim($input['employee_number'] ?? $input['employee_id'] ?? ''));

        // full_name_en: accept split fields (form) or combined (JSON)
        $firstEn   = trim($input['first_name_en'] ?? '');
        $lastEn    = trim($input['last_name_en']  ?? '');
        $fullNameEn = $firstEn && $lastEn
            ? "{$firstEn} {$lastEn}"
            : trim($input['full_name_en'] ?? '');

        $firstAr   = trim($input['first_name_ar'] ?? '');
        $lastAr    = trim($input['last_name_ar']  ?? '');
        $fullNameAr = $firstAr && $lastAr
            ? "{$firstAr} {$lastAr}"
            : trim($input['full_name_ar'] ?? '');

        $nationality = trim($input['nationality'] ?? '');

        // gender: form sends MALE/FEMALE/OTHER, DB expects M/F/U
        $genderRaw = strtoupper(trim($input['gender'] ?? 'U'));
        $gender    = match($genderRaw) {
            'MALE', 'M'   => 'M',
            'FEMALE', 'F' => 'F',
            default       => 'U',
        };

        // phone: accept phone_number (form) or phone (JSON)
        $phone     = trim($input['phone_number'] ?? $input['phone'] ?? '');
        $email     = strtolower(trim($input['email'] ?? ''));
        $jobTitle  = trim($input['job_title'] ?? '');
        $spec      = trim($input['specialisation'] ?? '');

        // unit_id: accept primary_unit_id (form) or unit_id (JSON)
        $unitId    = trim($input['primary_unit_id'] ?? $input['unit_id'] ?? '');

        // license_number: Mumaris+ ID is the Saudi nursing credential
        $licenseNo = trim($input['mumaris_id'] ?? $input['license_number'] ?? '');

        $licenseExpiry = $input['license_expiry'] ?? null;
        $contractStart = $input['contract_start'] ?? null;
        $contractEnd   = $input['contract_end']   ?? null;
        $empType       = strtoupper(trim($input['employment_type'] ?? 'FULL_TIME'));
        $validEmpTypes = ['FULL_TIME', 'PART_TIME', 'LOCUM', 'AGENCY'];
        if (!in_array($empType, $validEmpTypes, true)) { $empType = 'FULL_TIME'; }

        // ── validation ──────────────────────────────────────────────────────
        if (!$employeeId || !$fullNameEn || !$email) {
            http_response_code(400);
            echo json_encode(['error' => 'employee_number, first_name_en + last_name_en, and email are required.']);
            return;
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid email format.']);
            return;
        }

        // ── file handling ────────────────────────────────────────────────────
        $docCount    = 0;
        $storageDir  = __DIR__ . '/../storage/nurse_documents/';
        if (!is_dir($storageDir)) { @mkdir($storageDir, 0750, true); }

        // R-SEC-4: Sanitise nurse ID to prevent path traversal attacks
        $targetNurseId = $nurseId ?: ('n-' . bin2hex(random_bytes(6)));
        $targetNurseId = preg_replace('/[^a-zA-Z0-9\-_]/', '', $targetNurseId);
        if (!$targetNurseId) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid nurse ID format.']);
            return;
        }

        $nurseDir = $storageDir . $targetNurseId . '/';
        if (!is_dir($nurseDir)) { @mkdir($nurseDir, 0750, true); }

        // Verify the resolved path is still within the storage directory
        $realStorageDir = realpath($storageDir);
        $realNurseDir   = realpath($nurseDir);
        if ($realStorageDir === false || $realNurseDir === false
            || !str_starts_with($realNurseDir, $realStorageDir)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid storage path.']);
            return;
        }

        foreach (self::DOC_FIELDS as $field) {
            $files = $_FILES[$field] ?? null;
            if (!$files) continue;

            // Handle both single and multiple file inputs
            $isMultiple = is_array($files['tmp_name']);
            $names      = $isMultiple ? $files['name']     : [$files['name']];
            $tmps       = $isMultiple ? $files['tmp_name'] : [$files['tmp_name']];
            $errors     = $isMultiple ? $files['error']    : [$files['error']];
            $sizes      = $isMultiple ? $files['size']     : [$files['size']];

            foreach ($tmps as $i => $tmp) {
                if ($errors[$i] !== UPLOAD_ERR_OK || !$tmp) continue;
                if ($sizes[$i] > self::MAX_FILE_BYTES) continue; // skip oversized

                $ext      = strtolower(pathinfo($names[$i], PATHINFO_EXTENSION));
                $allowed  = ['pdf', 'jpg', 'jpeg', 'png'];
                if (!in_array($ext, $allowed, true)) continue;

                // R-SEC-4: Validate actual MIME type (not just extension)
                $finfo    = new \finfo(FILEINFO_MIME_TYPE);
                $mimeType = $finfo->file($tmp);
                if (!in_array($mimeType, self::ALLOWED_MIMES, true)) continue;

                $destName = $field . ($isMultiple ? "_{$i}" : '') . '_' . time() . '.' . $ext;
                if (move_uploaded_file($tmp, $nurseDir . $destName)) {
                    $docCount++;
                }
            }
        }

        $currentUser = AuthMiddleware::currentUser();

        // ── INSERT or UPDATE ─────────────────────────────────────────────────
        if ($nurseId) {
            $stmt = $this->db->prepare("
                UPDATE nurses SET
                    employee_id = ?, full_name_en = ?, full_name_ar = ?,
                    nationality = ?, gender = ?, phone = ?, email = ?,
                    job_title = ?, specialisation = ?, unit_id = ?,
                    license_number = ?, license_expiry = ?,
                    contract_start = ?, contract_end = ?,
                    employment_type = ?, updated_at = NOW()
                WHERE nurse_id = ?
            ");
            $stmt->execute([
                $employeeId, $fullNameEn, $fullNameAr,
                $nationality, $gender, $phone, $email,
                $jobTitle, $spec, $unitId ?: null,
                $licenseNo, $licenseExpiry ?: null,
                $contractStart ?: null, $contractEnd ?: null,
                $empType, $nurseId,
            ]);

            if ($stmt->rowCount() === 0) {
                http_response_code(404);
                echo json_encode(['error' => 'Nurse record not found.']);
                return;
            }

            AuthMiddleware::auditEvent(
                $currentUser, $currentRole,
                'NURSE_UPDATED', 'nurses', $nurseId,
                null, ['employee_id' => $employeeId, 'name' => $fullNameEn]
            );
            echo json_encode([
                'success'   => true,
                'nurse_id'  => $nurseId,
                'documents' => $docCount,
                'message'   => 'Nurse profile updated.',
            ]);
        } else {
            // Check duplicate employee_id or email
            $dup = $this->db->prepare("SELECT nurse_id FROM nurses WHERE employee_id = ? OR email = ? LIMIT 1");
            $dup->execute([$employeeId, $email]);
            if ($dup->fetch()) {
                http_response_code(409);
                echo json_encode(['error' => 'A nurse with that employee number or email already exists.']);
                return;
            }

            $stmt = $this->db->prepare("
                INSERT INTO nurses
                    (nurse_id, employee_id, full_name_en, full_name_ar,
                     nationality, gender, phone, email,
                     job_title, specialisation, unit_id,
                     license_number, license_expiry,
                     contract_start, contract_end, employment_type, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
            ");
            $stmt->execute([
                $targetNurseId, $employeeId, $fullNameEn, $fullNameAr,
                $nationality, $gender, $phone, $email,
                $jobTitle, $spec, $unitId ?: null,
                $licenseNo, $licenseExpiry ?: null,
                $contractStart ?: null, $contractEnd ?: null, $empType,
            ]);

            AuthMiddleware::auditEvent(
                $currentUser, $currentRole,
                'NURSE_CREATED', 'nurses', $targetNurseId,
                null, ['employee_id' => $employeeId, 'name' => $fullNameEn, 'unit_id' => $unitId]
            );
            echo json_encode([
                'success'   => true,
                'nurse_id'  => $targetNurseId,
                'documents' => $docCount,
                'message'   => 'Nurse profile created.',
            ]);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PRIVATE: normalise DB rows → JS-compatible field names
    //   full_name_en  → first_name_en + last_name_en (split on first space)
    //   employee_id   → employee_number
    //   license_number → credential_number
    //   days_to_expiry is already computed in SQL (null → PHP_INT_MAX so badge shows "Valid")
    // ─────────────────────────────────────────────────────────────────────────
    private function normaliseRows(array $rows): array
    {
        return array_map(function (array $row): array {
            // Split full_name_en into first / last
            $parts = explode(' ', $row['full_name_en'], 2);
            $row['first_name_en'] = $parts[0] ?? '';
            $row['last_name_en']  = $parts[1] ?? '';

            // Same for Arabic
            $partsAr = explode(' ', $row['full_name_ar'] ?? '', 2);
            $row['first_name_ar'] = $partsAr[0] ?? '';
            $row['last_name_ar']  = $partsAr[1] ?? '';

            // Aliases
            $row['employee_number']       = $row['employee_id'];
            $row['credential_number']     = $row['license_number'];

            // identification_type / identification_number not in current schema —
            // return empty strings so the JS template renders safely.
            $row['identification_type']   = $row['identification_type']   ?? '';
            $row['identification_number'] = $row['identification_number'] ?? '';

            // days_to_expiry: null (no expiry set) → large positive so badge = "Valid"
            if ($row['days_to_expiry'] === null) {
                $row['days_to_expiry'] = 9999;
            } else {
                $row['days_to_expiry'] = (int)$row['days_to_expiry'];
            }

            return $row;
        }, $rows);
    }
}
