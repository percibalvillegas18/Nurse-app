<?php
// config/Database.php – PDO singleton used by AuthMiddleware, RbacController, etc.
// R6 FIX: This file was missing from the merged package; login/RBAC fatals without it.
//
// Configure via environment variables (preferred) or edit the defaults below:
//   DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASS, DB_CHARSET

namespace Config;

use PDO;
use PDOException;

class Database
{
    private static ?PDO $pdo = null;

    public static function getConnection(): PDO
    {
        if (self::$pdo instanceof PDO) {
            return self::$pdo;
        }

        $host    = getenv('DB_HOST')    ?: '127.0.0.1';
        $port    = getenv('DB_PORT')    ?: '3306';
        $name    = getenv('DB_NAME')    ?: 'nurse_scheduling';
        $user    = getenv('DB_USER')    ?: 'root';
        $pass    = getenv('DB_PASS')    ?: '';
        $charset = getenv('DB_CHARSET') ?: 'utf8mb4';

        $dsn = "mysql:host={$host};port={$port};dbname={$name};charset={$charset}";

        try {
            self::$pdo = new PDO($dsn, $user, $pass, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES {$charset}",
            ]);
        } catch (PDOException $e) {
            // Log the real error server-side; never expose connection details to the client
            error_log('[DATABASE ERROR] ' . $e->getMessage());
            http_response_code(503);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'error' => 'Database connection failed.',
                'hint'  => 'Check DB_HOST, DB_NAME, DB_USER, DB_PASS environment variables and ensure the database server is running.',
            ]);
            exit;
        }

        return self::$pdo;
    }

    /** Reset the singleton (tests / reconnect after schema change). */
    public static function reset(): void
    {
        self::$pdo = null;
    }
}
