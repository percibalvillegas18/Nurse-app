// public/js/app.js - Hardened Error-Resistant Controller (RBAC-enabled)
class App {
    constructor() {
        this.currentLang = 'en';
        this.currentRole = 'HEAD_NURSE';
        this.matrixDates = [];
        this.deptsCache = [];
        this.subUnitsCache = [];
        // RBAC caches
        this.rbacUsersCache = [];
        this.rbacRolesCache = [];
        this.rbacPermsCache = [];
        this.rbacActiveView = 'users';
        // R3: permission list from /me — used to gate Access UI client-side
        this.permissions = [];
    }

    /** R3: true if current session holds resource.action (from /me permissions) */
    hasPerm(resource, action) {
        const key = `${resource}.${action}`;
        if (Array.isArray(this.permissions) && this.permissions.length) {
            return this.permissions.includes(key);
        }
        // Fallback by role until /me loads
        const role = (this.currentRole || '').toUpperCase();
        const map = {
            'users.read':        ['ADMIN', 'MANAGER', 'SUPERVISOR', 'HEAD_NURSE'],
            'users.create':      ['ADMIN'],
            'users.update':      ['ADMIN'],
            'users.delete':      ['ADMIN'],
            'users.assign_role': ['ADMIN'],
            'audit.view':        ['ADMIN'],
            'reports.export':    ['ADMIN', 'MANAGER'],
        };
        return (map[key] || []).includes(role);
    }

    // C1 FIX: XSS sanitizer — escape all dynamic content before innerHTML insertion
    esc(str) {
        if (str === null || str === undefined) return '';
        const div = document.createElement('div');
        div.appendChild(document.createTextNode(String(str)));
        return div.innerHTML;
    }

    init() {
        try {
            // M6 FIX: Sync role from server-embedded data attribute
            const roleAttr = document.body.dataset.currentRole;
            if (roleAttr) {
                this.currentRole = roleAttr;
                const roleSelect = document.getElementById('appRoleSelect');
                if (roleSelect) roleSelect.value = roleAttr;
            }

            // C3 FIX: Read CSRF token from meta tag
            const csrfMeta = document.querySelector('meta[name="csrf-token"]');
            this.csrfToken = csrfMeta ? csrfMeta.content : '';

            this.initDates();
            this.ensureModalsHidden();
            // R2: show who is signed in (also drives graceful 401 if session already dead)
            this.loadSessionUser();
            // Layer 1: populate Active Unit Context from DB, then load data
            this.loadUnitContext().then(() => this.refreshAll());
        } catch (err) {
            console.error("Critical initialization failure caught:", err);
        }
    }

    /**
     * Layer 1: Load units into hubUnitSelect from get_sub_units.
     * Layer 4: list is already server-filtered by the caller's scope.
     * Persists selection in sessionStorage.
     */
    async loadUnitContext() {
        const sel = document.getElementById('hubUnitSelect');
        if (!sel) return;
        const res = await this.safeFetch('index.php?action=get_sub_units');
        if (!res.ok) {
            sel.innerHTML = '<option value="">Units unavailable</option>';
            return;
        }

        // Support both array and { units, empty, message } shapes
        let units = Array.isArray(res.data) ? res.data : (res.data.units || []);
        if (res.data && res.data.empty) {
            sel.innerHTML = `<option value="">${this.esc(res.data.message || 'No units assigned')}</option>`;
            this.currentUnit = '';
            this.showToast(res.data.message || 'No units assigned to your account.', 'error');
            return;
        }

        const prev = sessionStorage.getItem('hubUnitId') || sel.value || '';
        sel.innerHTML = units.map(u => {
            const id = u.unit_id || '';
            const label = `${u.name_en || id}${u.code ? ' (' + u.code + ')' : ''}${u.rollout_wave ? ' [' + u.rollout_wave + ']' : ''}`;
            return `<option value="${this.esc(id)}">${this.esc(label)}</option>`;
        }).join('');

        if (!units.length) {
            sel.innerHTML = '<option value="">No units available</option>';
            this.currentUnit = '';
            return;
        }

        if (prev && Array.from(sel.options).some(o => o.value === prev)) {
            sel.value = prev;
        } else {
            sel.selectedIndex = 0;
        }
        this.currentUnit = sel.value;
        sessionStorage.setItem('hubUnitId', this.currentUnit || '');
    }

    /** Layer 1/2 + R9: unit dropdown changed — only reload unit-scoped views */
    onUnitContextChange() {
        const sel = document.getElementById('hubUnitSelect');
        this.currentUnit = sel ? sel.value : '';
        sessionStorage.setItem('hubUnitId', this.currentUnit || '');
        // Unit-scoped: shifts, handovers, access. Others stay on cache.
        this.loadShifts();
        this.loadHandovers();
        const accessView = document.getElementById('view-access');
        if (accessView && !accessView.classList.contains('hidden')) {
            this.loadAccessMatrix();
        }
    }

    /** Layer 2: clear unit filter on Access Matrix (show hospital-wide) */
    clearUnitScopeFilter() {
        this._rbacIgnoreUnit = true;
        this.loadAccessMatrix();
    }

    currentUnitId() {
        const sel = document.getElementById('hubUnitSelect');
        return (sel && sel.value) || this.currentUnit || '';
    }

    ensureModalsHidden() {
        // Guarantee all backdrop overlays are physically inert on load
        ['nurseModal', 'leaveModal', 'handoverModal', 'ticketModal', 'deptModal', 'subUnitModal', 'rbacAssignModal', 'rbacCreateUserModal'].forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                el.classList.add('hidden');
                el.style.display = 'none';
            }
        });
    }

    initDates() {
        this.matrixDates = [];
        const today = new Date();
        for (let i = -1; i <= 5; i++) {
            const d = new Date(today);
            d.setDate(today.getDate() + i);
            this.matrixDates.push(d.toISOString().split('T')[0]);
        }
        const lrStart = document.getElementById('lrStart');
        const lrEnd = document.getElementById('lrEnd');
        if (lrStart && this.matrixDates[1]) lrStart.value = this.matrixDates[1];
        if (lrEnd && this.matrixDates[4]) lrEnd.value = this.matrixDates[4];
    }

    async safeFetch(url, options = {}) {
        try {
            // C3 FIX: Attach CSRF token to all POST requests
            if (options.method && options.method.toUpperCase() === 'POST' && this.csrfToken) {
                if (!options.headers) options.headers = {};
                options.headers['X-CSRF-Token'] = this.csrfToken;
            }
            const res = await fetch(url, options);
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                console.error("Server non-JSON response:", text);
                return { ok: false, error: "Server returned a non-JSON payload." };
            }
            // R10 FIX: idle timeout / unauthenticated → kick back to login
            // (previously every panel silently stopped updating with a dead UI)
            if (res.status === 401) {
                window.location.href = 'index.php';
                return { ok: false, status: 401, error: data.error || 'Session expired', data };
            }
            return { ok: res.ok, status: res.status, data: data };
        } catch (err) {
            console.error("Network communication failure:", err);
            return { ok: false, error: "Network connection error." };
        }
    }

    // R2 FIX: End session via the existing public logout route, then reload → login
    async logout() {
        try {
            await this.safeFetch('index.php?action=logout', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' }
            });
        } catch (e) {
            // Still clear the UI even if the network call fails
        }
        window.location.href = 'index.php';
    }

    // R2 / R11: Load signed-in identity from /me and show it in the header
    async loadSessionUser() {
        const res = await this.safeFetch('index.php?action=me');
        if (!res.ok || !res.data) return;
        const email = res.data.email || res.data.user_id || '';
        const role  = res.data.role || this.currentRole || '';
        if (res.data.role) {
            this.currentRole = res.data.role;
            const roleSelect = document.getElementById('appRoleSelect');
            if (roleSelect) roleSelect.value = res.data.role;
        }
        // R3: store full permission list for client-side gating
        if (Array.isArray(res.data.permissions)) {
            this.permissions = res.data.permissions;
        }
        const el = document.getElementById('sessionUser');
        if (el) {
            el.textContent = email || role || 'Signed in';
            el.title = [email, role].filter(Boolean).join(' · ');
        }
        // Keep role badge in sync if /me returns a canonical role
        const badge = document.getElementById('appRoleBadge');
        if (badge && role) {
            const labels = {
                ADMIN: '🔑 Admin',
                MANAGER: '📋 Manager',
                SUPERVISOR: '👑 Supervisor',
                STAFF_NURSE: '👩‍⚕️ Staff Nurse',
                HEAD_NURSE: '👑 Supervisor',
            };
            badge.textContent = labels[role] || role;
        }
        this.applyAccessUiGates();
    }

    /**
     * R3 FIX: Hide Access controls the role cannot use (avoid silent 403 empty panels).
     * Server already gates the nav button; this covers sub-tabs / actions after /me loads
     * and if the user lands on the section somehow.
     */
    applyAccessUiGates() {
        const accessTab = document.getElementById('tab-access');
        if (accessTab) {
            accessTab.classList.toggle('hidden', !this.hasPerm('users', 'read'));
        }
        const auditTab = document.getElementById('rbac-tab-audit');
        if (auditTab) {
            auditTab.classList.toggle('hidden', !this.hasPerm('audit', 'view'));
        }
        const btnExport = document.getElementById('rbacBtnExport');
        if (btnExport) {
            btnExport.classList.toggle('hidden', !this.hasPerm('reports', 'export'));
        }
        const btnAssign = document.getElementById('rbacBtnAssign');
        if (btnAssign) {
            btnAssign.classList.toggle('hidden', !this.hasPerm('users', 'assign_role'));
        }
        const btnCreate = document.getElementById('rbacBtnCreateUser');
        if (btnCreate) {
            btnCreate.classList.toggle('hidden', !this.hasPerm('users', 'create'));
        }
        // If current sub-view is audit but user lost rights, fall back to users
        if (this.rbacActiveView === 'audit' && !this.hasPerm('audit', 'view')) {
            this.rbacActiveView = 'users';
        }
    }

    toggleLang() {
        this.currentLang = this.currentLang === 'en' ? 'ar' : 'en';
        document.documentElement.setAttribute('dir', this.currentLang === 'ar' ? 'rtl' : 'ltr');
        document.documentElement.setAttribute('lang', this.currentLang);
        const langBtn = document.getElementById('langBtn');
        if (langBtn) langBtn.innerText = this.currentLang === 'ar' ? 'English' : 'العربية';
        this.refreshAll();
    }

    switchTab(tabId) {
        // R3: block Access tab for roles without users.read
        if (tabId === 'access' && !this.hasPerm('users', 'read')) {
            this.showToast('You do not have permission to open Access Control.', 'error');
            return;
        }
        const tabs = ['shifts', 'departments', 'directory', 'leaves', 'handovers', 'rollout', 'analytics', 'access'];
        tabs.forEach(t => {
            const view = document.getElementById(`view-${t}`);
            if (view) view.classList.toggle('hidden', t !== tabId);

            const btn = document.getElementById(`tab-${t}`);
            if (btn) {
                if (t === tabId) {
                    btn.className = "px-3.5 py-2 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200 flex items-center gap-1.5 whitespace-nowrap font-bold shadow-sm";
                } else {
                    btn.className = "px-3.5 py-2 rounded-lg hover:bg-slate-100 text-slate-600 flex items-center gap-1.5 whitespace-nowrap";
                }
            }
        });

        if (tabId === 'shifts') this.loadShifts();
        if (tabId === 'departments') this.loadDepartmentsConsole();
        if (tabId === 'directory') this.loadDirectory();
        if (tabId === 'leaves') this.loadLeaves();
        if (tabId === 'handovers') this.loadHandovers();
        if (tabId === 'rollout') this.loadRollout();
        if (tabId === 'analytics') this.loadAnalytics();
        if (tabId === 'access') this.loadAccessMatrix();
    }

    // R1 FIX: Role switching is no longer a public session-minter.
    // The unauthenticated switch_user route was removed. Demo switching (if
    // APP_DEMO_MODE is enabled server-side) requires an authenticated Admin
    // with config.manage. Ordinary users cannot change their role from the UI.
    async switchRole(role) {
        this.showToast('Role is set by your signed-in account. Sign out and sign in as a different user to change role.', 'info');
        // Keep UI in sync with the real session role (do not pretend the switch worked).
        const roleSelect = document.getElementById('appRoleSelect');
        if (roleSelect && this.currentRole) {
            roleSelect.value = this.currentRole;
        }
    }

    refreshAll() {
        this.loadShifts();
        this.loadDepartmentsConsole();
        this.loadDirectory();
        this.loadLeaves();
        this.loadHandovers();
        this.loadRollout();
        this.loadAnalytics();
        // Load access matrix if the access tab is currently visible
        const accessView = document.getElementById('view-access');
        if (accessView && !accessView.classList.contains('hidden')) {
            this.loadAccessMatrix();
        }
    }

    // Modal Display Helpers (Removes invisible blocking layer)
    openModal(id) {
        const el = document.getElementById(id);
        if (el) {
            el.classList.remove('hidden');
            el.style.display = 'flex';
        }
    }

    /**
     * Layer 3: Open Assign Role modal pre-filled with current unit as scope.
     * Optional userId pre-selects that user (row-level Assign action).
     */
    openRbacAssign(userId = null) {
        if (!this.hasPerm('users', 'assign_role')) {
            this.showToast('You do not have permission to assign roles.', 'error');
            return;
        }

        // Ensure user dropdown is populated from cache
        const assignUserSelect = document.getElementById('rbacAssignUser');
        if (assignUserSelect && this.rbacUsersCache && this.rbacUsersCache.length) {
            const current = assignUserSelect.value;
            assignUserSelect.innerHTML = '<option value="">— Select user —</option>';
            this.rbacUsersCache.forEach(u => {
                assignUserSelect.innerHTML += `<option value="${this.esc(u.user_id)}">${this.esc(u.email || u.user_id)}</option>`;
            });
            if (userId) {
                assignUserSelect.value = userId;
            } else if (current) {
                assignUserSelect.value = current;
            }
        } else if (assignUserSelect && userId) {
            assignUserSelect.value = userId;
        }

        // Scope targets from hub unit + departments
        const scopeIdEl = document.getElementById('rbacAssignScopeId');
        if (scopeIdEl) {
            scopeIdEl.innerHTML = '';
            const unitSelect = document.getElementById('hubUnitSelect');
            if (unitSelect) {
                Array.from(unitSelect.options).forEach(opt => {
                    if (opt.value) {
                        scopeIdEl.innerHTML += `<option value="${this.esc(opt.value)}">${this.esc(opt.text)}</option>`;
                    }
                });
            }
            (this.deptsCache || []).forEach(d => {
                scopeIdEl.innerHTML += `<option value="${this.esc(d.department_id)}">${this.esc(d.code)} - ${this.esc(d.name_en)}</option>`;
            });
        }

        const unit = this.currentUnitId();
        const scopeEl = document.getElementById('rbacAssignScope');
        if (unit && scopeEl && scopeIdEl) {
            scopeEl.value = 'unit';
            scopeIdEl.value = unit;
            this.toggleRbacScopeId();
        } else if (scopeEl) {
            scopeEl.value = 'global';
            this.toggleRbacScopeId();
        }

        // Default effective_from = today
        const fromEl = document.getElementById('rbacAssignFrom');
        if (fromEl && !fromEl.value) {
            fromEl.value = new Date().toISOString().slice(0, 10);
        }

        this.openModal('rbacAssignModal');
        this.updateRbacImpact();
    }

    /** Open Create User modal (ADMIN / users.create) */
    openRbacCreateUser() {
        if (!this.hasPerm('users', 'create')) {
            this.showToast('You do not have permission to create users.', 'error');
            return;
        }
        const email = document.getElementById('rbacCreateEmail');
        const password = document.getElementById('rbacCreatePassword');
        const role = document.getElementById('rbacCreateRole');
        const scope = document.getElementById('rbacCreateScope');
        const reason = document.getElementById('rbacCreateReason');
        if (email) email.value = '';
        if (password) password.value = '';
        if (role) role.value = '';
        if (scope) scope.value = 'global';
        if (reason) reason.value = '';

        const scopeIdEl = document.getElementById('rbacCreateScopeId');
        if (scopeIdEl) {
            scopeIdEl.innerHTML = '';
            const unitSelect = document.getElementById('hubUnitSelect');
            if (unitSelect) {
                Array.from(unitSelect.options).forEach(opt => {
                    if (opt.value) {
                        scopeIdEl.innerHTML += `<option value="${this.esc(opt.value)}">${this.esc(opt.text)}</option>`;
                    }
                });
            }
            (this.deptsCache || []).forEach(d => {
                scopeIdEl.innerHTML += `<option value="${this.esc(d.department_id)}">${this.esc(d.code)} - ${this.esc(d.name_en)}</option>`;
            });
        }
        this.toggleRbacCreateScopeId();
        this.openModal('rbacCreateUserModal');
    }

    toggleRbacCreateScopeId() {
        const scopeType = document.getElementById('rbacCreateScope')?.value;
        const group = document.getElementById('rbacCreateScopeIdGroup');
        if (!group) return;
        group.style.display = scopeType === 'global' ? 'none' : '';
    }

    async submitRbacCreateUser() {
        const email = document.getElementById('rbacCreateEmail')?.value || '';
        const password = document.getElementById('rbacCreatePassword')?.value || '';
        const roleCode = document.getElementById('rbacCreateRole')?.value || '';
        const scopeType = document.getElementById('rbacCreateScope')?.value || 'global';
        const scopeId = document.getElementById('rbacCreateScopeId')?.value || null;
        const reason = document.getElementById('rbacCreateReason')?.value || '';

        const payload = {
            email: email.trim(),
            password,
            scope_type: scopeType,
            scope_id: scopeType === 'global' ? null : scopeId,
            reason,
        };
        if (roleCode) payload.role_code = roleCode;

        const res = await this.safeFetch('index.php?action=rbac_create_user', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });

        if (res.ok) {
            this.closeModal('rbacCreateUserModal');
            this.showToast(res.data.message || 'User created.', 'success');
            this.loadAccessMatrix();
        } else {
            this.showToast((res.data && res.data.error) || 'Failed to create user.', 'error');
        }
    }

    async toggleRbacUserActive(userId, isActive) {
        if (!this.hasPerm('users', 'update')) {
            this.showToast('You do not have permission to update users.', 'error');
            return;
        }
        const res = await this.safeFetch('index.php?action=rbac_update_user', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: userId, is_active: !!isActive }),
        });
        if (res.ok) {
            this.showToast(res.data.message || 'User updated.', 'success');
            this.loadAccessMatrix();
        } else {
            this.showToast((res.data && res.data.error) || 'Failed to update user.', 'error');
        }
    }

    async deleteRbacUser(userId) {
        if (!this.hasPerm('users', 'delete')) {
            this.showToast('You do not have permission to delete users.', 'error');
            return;
        }
        if (!confirm('Deactivate this user? They will be unable to sign in. Role assignments will be ended.')) return;

        const res = await this.safeFetch('index.php?action=rbac_delete_user', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: userId, hard_delete: false }),
        });
        if (res.ok) {
            this.showToast(res.data.message || 'User deactivated.', 'success');
            this.loadAccessMatrix();
        } else {
            this.showToast((res.data && res.data.error) || 'Failed to delete user.', 'error');
        }
    }

    closeModal(id) {
        const el = document.getElementById(id);
        if (el) {
            el.classList.add('hidden');
            el.style.display = 'none';
        }
    }

    // --- 1. SHIFTS MATRIX ---
    async loadShifts() {
        const unitEl = document.getElementById('hubUnitSelect');
        if (!unitEl) return;
        const unit = unitEl.value;

        const res = await this.safeFetch(`index.php?action=get_shifts_matrix&unit_id=${unit}&start_date=${this.matrixDates[0]}&end_date=${this.matrixDates[this.matrixDates.length-1]}`);
        if (!res.ok) return;
        const data = res.data;

        const thead = document.getElementById('shiftsThead');
        if (thead) {
            let th = `<tr><th class="p-2.5 text-left rtl:text-right w-40">Nurse</th>`;
            this.matrixDates.forEach(d => {
                const day = new Date(d).toLocaleDateString('en-US', { weekday: 'short' });
                th += `<th class="p-2 border-l">${day}<br><span class="text-[9px] text-slate-400 font-mono">${d.slice(5)}</span></th>`;
            });
            thead.innerHTML = th + `</tr>`;
        }

        const tbody = document.getElementById('shiftsTbody');
        if (tbody) {
            tbody.innerHTML = '';
            (data.nurses || []).forEach(n => {
                let tr = `<tr><td class="p-2.5 text-left rtl:text-right font-bold bg-slate-50">${this.esc(n.first_name_en)} ${this.esc(n.last_name_en)} <div class="text-[9px] text-slate-400 font-mono">${this.esc(n.employee_number)}</div></td>`;
                this.matrixDates.forEach(d => {
                    const shift = (data.shifts || []).find(s => s.nurse_id === n.nurse_id && s.shift_date === d);
                    const code = shift ? shift.duty_code : '-';
                    const isPub = shift ? (shift.is_published == 1) : false;
                    let color = "bg-slate-100 text-slate-400";
                    if (code === 'D') color = "bg-sky-100 text-sky-800 font-bold border border-sky-300";
                    if (code === 'E') color = "bg-amber-100 text-amber-800 font-bold border border-amber-300";
                    if (code === 'N') color = "bg-indigo-100 text-indigo-800 font-bold border border-indigo-300";
                    if (code === 'AL') color = "bg-emerald-100 text-emerald-800 font-bold";
                    tr += `<td class="p-1 border-l relative cursor-pointer hover:bg-slate-100" onclick="window.app.assignShiftPrompt('${this.esc(n.nurse_id)}', '${this.esc(d)}')">
                        <span class="inline-flex items-center justify-center w-7 h-7 rounded-lg text-xs ${color}">${this.esc(code)}</span>
                        ${isPub ? `<span class="absolute top-0.5 right-0.5 text-[8px] text-emerald-600 font-bold">✓</span>` : ''}
                    </td>`;
                });
                tbody.innerHTML += tr + `</tr>`;
            });
        }

        const openDiv = document.getElementById('openShiftsList');
        if (openDiv) {
            openDiv.innerHTML = '';
            const openShifts = data.open_shifts || [];
            if (openShifts.length === 0) {
                openDiv.innerHTML = '<div class="text-xs text-slate-400 col-span-3">No uncovered shifts broadcasted.</div>';
            } else {
                openShifts.forEach(os => {
                    openDiv.innerHTML += `
                        <div class="bg-white border border-amber-200 rounded-xl p-3 flex justify-between items-center text-xs">
                            <div><span class="font-bold text-amber-900">${this.esc(os.shift_date)}</span> • Duty ${this.esc(os.duty_code)}</div>
                            <button onclick="window.app.claimShift('${this.esc(os.assignment_id)}')" class="bg-emerald-600 text-white font-bold px-2.5 py-1 rounded shadow-sm hover:bg-emerald-700">Claim</button>
                        </div>
                    `;
                });
            }
        }
    }

    async assignShiftPrompt(nurseId, dateStr) {
        if (this.currentRole === 'STAFF_NURSE') {
            this.showToast('Staff nurses cannot edit schedules directly.', 'error');
            return;
        }
        const code = prompt("Enter Duty Code (D = Day, E = Evening, N = Night, AL = Annual Leave, X = Off):", "D");
        if (!code) return;

        const res = await this.safeFetch('index.php?action=save_shift_cell', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                nurse_id: nurseId,
                unit_id: document.getElementById('hubUnitSelect').value,
                shift_date: dateStr,
                duty_code: code
            })
        });

        if (res.ok) {
            this.showToast('Shift assigned successfully.', 'success');
            this.loadShifts();
        } else {
            this.showToast((res.data && res.data.error) || res.error || 'Blocked by scheduling lock.', 'error');
        }
    }

    async claimShift(id) {
        const res = await this.safeFetch('index.php?action=claim_open_shift', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ assignment_id: id })
        });
        if (res.ok) {
            this.showToast('Open shift claimed.', 'success');
            this.loadShifts();
        } else {
            this.showToast((res.data && res.data.error) || 'Failed to claim shift.', 'error');
        }
    }

    async publishSchedule() {
        const res = await this.safeFetch('index.php?action=publish_unit_schedule', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ unit_id: document.getElementById('hubUnitSelect').value })
        });
        if (res.ok) {
            this.showToast(`Published ${res.data.count} shifts to Microsoft Teams Shifts!`, 'success');
            this.loadShifts();
        }
    }

    async runAutoSweep() {
        const res = await this.safeFetch('index.php?action=run_automated_sweep');
        if (res.ok) {
            this.showToast(`Swept 30-day alerts. ${res.data.dispatched} notifications created.`, 'success');
        }
    }

    // --- 2. DEPARTMENTS & SUB-UNITS ---
    async loadDepartmentsConsole() {
        const resDepts = await this.safeFetch('index.php?action=get_departments');
        if (!resDepts.ok) return;
        this.deptsCache = resDepts.data || [];

        let totalStaff = 0;
        this.deptsCache.forEach(d => { totalStaff += parseInt(d.nurse_count || 0); });

        const countDepts = document.getElementById('countTotalDepts');
        const countStaff = document.getElementById('countTotalStaff');
        if (countDepts) countDepts.innerText = this.deptsCache.length;
        if (countStaff) countStaff.innerText = totalStaff;

        const selDept = document.getElementById('selSelectedDept');
        const smParentDept = document.getElementById('smParentDept');
        if (selDept) {
            selDept.innerHTML = '<option value="ALL">All Departments</option>';
            if (smParentDept) smParentDept.innerHTML = '';

            this.deptsCache.forEach(d => {
                selDept.innerHTML += `<option value="${this.esc(d.department_id)}">${this.esc(d.code)} - ${this.esc(d.name_en)}</option>`;
                if (smParentDept) smParentDept.innerHTML += `<option value="${this.esc(d.department_id)}">${this.esc(d.code)} - ${this.esc(d.name_en)}</option>`;
            });
        }

        await this.renderDeptTable();
    }

    async renderDeptTable() {
        const selView = document.getElementById('selViewMode');
        const selDept = document.getElementById('selSelectedDept');
        const thead = document.getElementById('deptTableHead');
        const tbody = document.getElementById('deptTableBody');
        const caption = document.getElementById('tableHeaderCaption');
        if (!tbody || !thead || !selView || !selDept) return;

        const viewMode = selView.value;
        const selectedDeptId = selDept.value;
        tbody.innerHTML = '';

        if (viewMode === 'SUB_UNITS') {
            if (caption) caption.innerText = selectedDeptId === 'ALL' ? 'All Hospital Sub-Units' : 'Department Sub-Units';
            thead.innerHTML = `
                <tr>
                    <th class="p-3">Unit Code</th>
                    <th class="p-3">Sub-Unit Name</th>
                    <th class="p-3">Day Shift Quota</th>
                    <th class="p-3">Night Shift Quota</th>
                    <th class="p-3">Total Staff</th>
                    <th class="p-3">Status</th>
                    <th class="p-3 text-center">Actions</th>
                </tr>
            `;

            let url = 'index.php?action=get_sub_units';
            if (selectedDeptId !== 'ALL') {
                url += `&dept_id=${selectedDeptId}`;
            }

            const res = await this.safeFetch(url);
            if (!res.ok) return;
            const subUnits = res.data || [];

            if (subUnits.length === 0) {
                tbody.innerHTML = `<tr><td colspan="7" class="p-6 text-center text-slate-400">No sub-units found. Click "+ Add Sub-Unit" to create one.</td></tr>`;
                return;
            }

            subUnits.forEach(u => {
                const uJson = JSON.stringify(u).replace(/"/g, '&quot;');
                tbody.innerHTML += `
                    <tr class="hover:bg-slate-50 transition">
                        <td class="p-3 font-mono font-bold text-indigo-700">${this.esc(u.code)}</td>
                        <td class="p-3 font-semibold text-slate-800">${this.esc(u.name_en)}</td>
                        <td class="p-3 font-mono">${this.esc(u.min_staffing_day)} Day</td>
                        <td class="p-3 font-mono">${this.esc(u.min_staffing_night)} Night</td>
                        <td class="p-3"><span class="bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded font-mono font-bold">${this.esc(u.total_staff)} Staff</span></td>
                        <td class="p-3"><span class="px-2 py-0.5 rounded text-[10px] font-bold ${u.go_live_status === 'STABILIZED' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}">${this.esc(u.go_live_status)}</span></td>
                        <td class="p-3 text-center space-x-2 rtl:space-x-reverse">
                            <button onclick="window.app.editSubUnit(${uJson})" class="text-indigo-600 font-bold hover:underline">Edit</button>
                            <button onclick="window.app.deleteSubUnit('${this.esc(u.unit_id)}')" class="text-red-500 font-bold hover:underline">Delete</button>
                        </td>
                    </tr>
                `;
            });
        } else {
            if (caption) caption.innerText = 'Departments Overview';
            thead.innerHTML = `
                <tr>
                    <th class="p-3">Code</th>
                    <th class="p-3">Department Name (English)</th>
                    <th class="p-3">اسم القسم (العربية)</th>
                    <th class="p-3">Sub-Units</th>
                    <th class="p-3">Total Staff</th>
                    <th class="p-3 text-center">Actions</th>
                </tr>
            `;

            this.deptsCache.forEach(d => {
                const dJson = JSON.stringify(d).replace(/"/g, '&quot;');
                tbody.innerHTML += `
                    <tr class="hover:bg-slate-50 transition">
                        <td class="p-3 font-mono font-bold text-indigo-700">${this.esc(d.code)}</td>
                        <td class="p-3 font-bold text-slate-800">${this.esc(d.name_en)}</td>
                        <td class="p-3 text-slate-600">${this.esc(d.name_ar)}</td>
                        <td class="p-3 font-mono font-bold text-indigo-600">${this.esc(d.unit_count)} Units</td>
                        <td class="p-3 font-mono font-bold text-slate-800">${this.esc(d.nurse_count)} Nurses</td>
                        <td class="p-3 text-center space-x-2 rtl:space-x-reverse">
                            <button onclick='window.app.drillDownDept("${this.esc(d.department_id)}")' class="text-emerald-600 font-bold hover:underline">View Units</button>
                            <button onclick="window.app.editDept(${dJson})" class="text-indigo-600 font-bold hover:underline">Edit</button>
                            <button onclick="window.app.deleteDept('${this.esc(d.department_id)}')" class="text-red-500 font-bold hover:underline">Delete</button>
                        </td>
                    </tr>
                `;
            });
        }
    }

    onDeptViewModeChange() {
        this.renderDeptTable();
    }

    onSelectedDeptDropdownChange() {
        document.getElementById('selViewMode').value = 'SUB_UNITS';
        this.renderDeptTable();
    }

    drillDownDept(deptId) {
        document.getElementById('selSelectedDept').value = deptId;
        document.getElementById('selViewMode').value = 'SUB_UNITS';
        this.renderDeptTable();
    }

    openDeptModal() {
        document.getElementById('deptModalTitle').innerText = 'Add Department';
        document.getElementById('dmDeptId').value = '';
        document.getElementById('dmCode').value = '';
        document.getElementById('dmNameEn').value = '';
        document.getElementById('dmNameAr').value = '';
        this.openModal('deptModal');
    }

    editDept(d) {
        document.getElementById('deptModalTitle').innerText = 'Edit Department';
        document.getElementById('dmDeptId').value = d.department_id;
        document.getElementById('dmCode').value = d.code;
        document.getElementById('dmNameEn').value = d.name_en;
        document.getElementById('dmNameAr').value = d.name_ar;
        this.openModal('deptModal');
    }

    async submitDept() {
        const payload = {
            department_id: document.getElementById('dmDeptId').value,
            code: document.getElementById('dmCode').value,
            name_en: document.getElementById('dmNameEn').value,
            name_ar: document.getElementById('dmNameAr').value
        };

        const res = await this.safeFetch('index.php?action=save_department', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            this.closeModal('deptModal');
            this.showToast('Department saved successfully.', 'success');
            this.loadDepartmentsConsole();
        } else {
            this.showToast((res.data && res.data.error) || 'Failed to save department', 'error');
        }
    }

    async deleteDept(deptId) {
        if (!confirm('Are you sure you want to delete this department?')) return;
        const res = await this.safeFetch('index.php?action=delete_department', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ department_id: deptId })
        });
        if (res.ok) {
            this.showToast('Department deleted.', 'success');
            this.loadDepartmentsConsole();
        } else {
            this.showToast((res.data && res.data.error) || 'Delete blocked by safety constraint.', 'error');
        }
    }

    openSubUnitModal() {
        const currentSelectedDept = document.getElementById('selSelectedDept').value;
        if (currentSelectedDept !== 'ALL') {
            document.getElementById('smParentDept').value = currentSelectedDept;
        }
        document.getElementById('subUnitModalTitle').innerText = 'Add Sub-Unit';
        document.getElementById('smUnitId').value = '';
        document.getElementById('smCode').value = '';
        document.getElementById('smNameEn').value = '';
        document.getElementById('smDayQuota').value = 2;
        document.getElementById('smNightQuota').value = 2;
        this.openModal('subUnitModal');
    }

    editSubUnit(u) {
        document.getElementById('subUnitModalTitle').innerText = 'Edit Sub-Unit';
        document.getElementById('smUnitId').value = u.unit_id;
        document.getElementById('smParentDept').value = u.department_id;
        document.getElementById('smCode').value = u.code;
        document.getElementById('smNameEn').value = u.name_en;
        document.getElementById('smDayQuota').value = u.min_staffing_day;
        document.getElementById('smNightQuota').value = u.min_staffing_night;
        document.getElementById('smWave').value = u.rollout_wave || 'PILOT';
        document.getElementById('smStatus').value = u.go_live_status || 'PLANNED';
        this.openModal('subUnitModal');
    }

    async submitSubUnit() {
        const payload = {
            unit_id: document.getElementById('smUnitId').value,
            department_id: document.getElementById('smParentDept').value,
            code: document.getElementById('smCode').value,
            name_en: document.getElementById('smNameEn').value,
            min_staffing_day: document.getElementById('smDayQuota').value,
            min_staffing_night: document.getElementById('smNightQuota').value,
            rollout_wave: document.getElementById('smWave').value,
            go_live_status: document.getElementById('smStatus').value
        };

        const res = await this.safeFetch('index.php?action=save_sub_unit', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            this.closeModal('subUnitModal');
            this.showToast('Sub-Unit saved successfully.', 'success');
            this.loadDepartmentsConsole();
        } else {
            this.showToast((res.data && res.data.error) || 'Failed to save sub-unit', 'error');
        }
    }

    async deleteSubUnit(unitId) {
        if (!confirm('Are you sure you want to delete this sub-unit?')) return;
        const res = await this.safeFetch('index.php?action=delete_sub_unit', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ unit_id: unitId })
        });
        if (res.ok) {
            this.showToast('Sub-unit deleted.', 'success');
            this.renderDeptTable();
        } else {
            this.showToast((res.data && res.data.error) || 'Delete blocked by safety constraint.', 'error');
        }
    }

    filterDeptTable() {
        const query = document.getElementById('deptSearchInput').value.toLowerCase();
        const rows = document.querySelectorAll('#deptTableBody tr');
        rows.forEach(r => {
            const text = r.innerText.toLowerCase();
            r.style.display = text.includes(query) ? '' : 'none';
        });
    }

    // --- 3. NURSE DIRECTORY ---
    async loadDirectory() {
        const res = await this.safeFetch('index.php?action=get_nurses');
        if (!res.ok) return;
        const nurses = res.data || [];
        const tbody = document.getElementById('directoryTbody');
        if (!tbody) return;
        tbody.innerHTML = '';
        nurses.forEach(n => {
            let badge = '<span class="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-bold">Valid</span>';
            if (n.days_to_expiry < 0) badge = '<span class="bg-red-100 text-red-800 px-2 py-0.5 rounded font-bold">Expired</span>';
            else if (n.days_to_expiry <= 30) badge = `<span class="bg-amber-100 text-amber-800 px-2 py-0.5 rounded font-bold">${n.days_to_expiry}d left</span>`;
            tbody.innerHTML += `
                <tr>
                    <td class="p-3 font-bold">${this.esc(n.first_name_en)} ${this.esc(n.last_name_en)} <div class="text-[10px] text-slate-400 font-mono">${this.esc(n.employee_number)}</div></td>
                    <td class="p-3 font-mono">${this.esc(n.identification_type)}: ${this.esc(n.identification_number)}</td>
                    <td class="p-3">${this.esc(n.unit_name_en || '-')}</td>
                    <td class="p-3 font-mono">${this.esc(n.credential_number || 'N/A')}</td>
                    <td class="p-3">${badge}</td>
                </tr>
            `;
        });
    }

    async submitNurse(event) {
        event.preventDefault();
        const form = document.getElementById('nmForm');
        if (!form || !form.reportValidity()) return;
        const payload = new FormData(form);
        payload.append('primary_unit_id', document.getElementById('hubUnitSelect').value);
        const button = document.getElementById('nmSubmit');
        if (button) { button.disabled = true; button.textContent = 'Saving…'; }
        const res = await this.safeFetch('index.php?action=save_nurse_profile', {
            method: 'POST',
            body: payload
        });
        if (button) { button.disabled = false; button.textContent = 'Save Nurse'; }
        if (res.ok) {
            form.reset();
            this.closeModal('nurseModal');
            this.showToast(`Nurse master profile saved with ${res.data.documents || 0} document(s).`, 'success');
            this.loadDirectory();
        } else {
            this.showToast((res.data && res.data.error) || res.error || 'Failed to save nurse', 'error');
        }
    }

    // --- 4. LEAVES ---
    async loadLeaves() {
        const res = await this.safeFetch('index.php?action=get_leaves');
        if (!res.ok) return;
        const leaves = res.data || [];
        const tbody = document.getElementById('leavesTbody');
        if (!tbody) return;
        tbody.innerHTML = '';
        leaves.forEach(l => {
            tbody.innerHTML += `
                <tr>
                    <td class="p-3 font-bold">${this.esc(l.first_name_en)} ${this.esc(l.last_name_en)}</td>
                    <td class="p-3">${this.esc(l.leave_type)}</td>
                    <td class="p-3 font-mono">${this.esc(l.start_date)} → ${this.esc(l.end_date)}</td>
                    <td class="p-3 font-bold ${l.status === 'APPROVED' ? 'text-emerald-600' : 'text-amber-600'}">${this.esc(l.status)}</td>
                    <td class="p-3 text-center">
                        ${l.status === 'PENDING' && this.currentRole === 'HEAD_NURSE' ? `
                            <button onclick="window.app.decideLeave('${this.esc(l.leave_id)}', 'APPROVED')" class="bg-emerald-600 text-white font-bold px-2 py-1 rounded shadow-sm hover:bg-emerald-700">Approve</button>
                        ` : '-'}
                    </td>
                </tr>
            `;
        });
    }

    async submitLeave() {
        const res = await this.safeFetch('index.php?action=submit_leave', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                leave_type: document.getElementById('lrType').value,
                start_date: document.getElementById('lrStart').value,
                end_date: document.getElementById('lrEnd').value,
                reason: 'Statutory leave'
            })
        });
        if (res.ok) {
            this.closeModal('leaveModal');
            this.showToast('Leave submitted.', 'success');
            this.loadLeaves();
        } else {
            this.showToast((res.data && res.data.error) || 'Failed to submit leave', 'error');
        }
    }

    async decideLeave(id, dec) {
        const res = await this.safeFetch('index.php?action=decide_leave', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ leave_id: id, decision: dec })
        });
        if (res.ok) {
            this.showToast(`Leave ${dec.toLowerCase()}. Shifts locked.`, 'success');
            this.loadLeaves();
        }
    }

    // --- 5. SBAR HANDOVERS ---
    async loadHandovers() {
        const unit = document.getElementById('hubUnitSelect').value;
        const res = await this.safeFetch(`index.php?action=get_channel_messages&unit_id=${unit}`);
        if (!res.ok) return;
        const posts = res.data || [];
        const list = document.getElementById('handoverList');
        if (!list) return;
        list.innerHTML = '';
        posts.forEach(p => {
            list.innerHTML += `
                <div class="border rounded-xl p-4 bg-white shadow-sm space-y-1">
                    <div class="flex justify-between font-bold">
                        <span>${this.esc(p.sender_name)} (${this.esc(p.sender_role)})</span>
                        <span class="text-indigo-600">Census: ${this.esc(p.patient_count)} Patients</span>
                    </div>
                    <div class="font-bold text-slate-900">${this.esc(p.title)}</div>
                    <pre class="font-sans text-slate-600 whitespace-pre-line leading-relaxed">${this.esc(p.content)}</pre>
                </div>
            `;
        });
    }

    async submitHandover() {
        const res = await this.safeFetch('index.php?action=post_channel_message', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                unit_id: document.getElementById('hubUnitSelect').value,
                title: document.getElementById('hoTitle').value,
                patient_count: document.getElementById('hoCensus').value,
                content: document.getElementById('hoContent').value
            })
        });
        if (res.ok) {
            this.closeModal('handoverModal');
            this.showToast('Handover posted.', 'success');
            this.loadHandovers();
        }
    }

    // --- 6. ROLLOUT & HYPERCARE ---
    async loadRollout() {
        const res = await this.safeFetch('index.php?action=get_rollout_data');
        if (!res.ok) return;
        const data = res.data;

        const wList = document.getElementById('wavesList');
        if (wList) {
            wList.innerHTML = '';
            (data.units || []).forEach(u => {
                wList.innerHTML += `
                    <div class="flex justify-between items-center p-2 bg-white rounded border">
                        <span class="font-bold">${this.esc(u.name_en)} (${this.esc(u.rollout_wave)})</span>
                        <span class="px-2 py-0.5 rounded text-[10px] font-bold ${u.go_live_status === 'STABILIZED' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}">${this.esc(u.go_live_status)}</span>
                    </div>
                `;
            });
        }

        const tList = document.getElementById('ticketsList');
        if (tList) {
            tList.innerHTML = '';
            (data.tickets || []).forEach(t => {
                tList.innerHTML += `
                    <div class="p-2 border rounded flex justify-between items-center">
                        <div><span class="font-bold font-mono text-indigo-700">${this.esc(t.ticket_number)}</span>: ${this.esc(t.title)}</div>
                        ${t.status === 'OPEN' || t.status === 'IN_PROGRESS' ? `
                            <button onclick="window.app.resolveTicket('${this.esc(t.ticket_id)}')" class="bg-emerald-600 text-white px-2 py-0.5 rounded text-[10px]">Resolve</button>
                        ` : '<span class="text-emerald-600 font-bold text-[10px]">RESOLVED</span>'}
                    </div>
                `;
            });
        }
    }

    async submitTicket() {
        const res = await this.safeFetch('index.php?action=create_hypercare_ticket', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                unit_id: document.getElementById('hubUnitSelect').value,
                priority: document.getElementById('tkPriority').value,
                category: 'ROSTER_CONFLICT',
                title: document.getElementById('tkTitle').value,
                description: document.getElementById('tkDesc').value
            })
        });
        if (res.ok) {
            this.closeModal('ticketModal');
            this.showToast('Hypercare ticket logged.', 'success');
            this.loadRollout();
        }
    }

    async resolveTicket(id) {
        const res = await this.safeFetch('index.php?action=resolve_hypercare_ticket', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ ticket_id: id, resolution_notes: 'Resolved in clinical huddle.' })
        });
        if (res.ok) {
            this.showToast('Ticket marked resolved.', 'success');
            this.loadRollout();
        }
    }

    // --- 7. ANALYTICS ---
    async loadAnalytics() {
        const res = await this.safeFetch('index.php?action=get_stage7_analytics');
        if (!res.ok) return;
        const d = res.data;

        const compEl = document.getElementById('kpi-compliance');
        const csatEl = document.getElementById('kpi-csat');
        if (compEl) compEl.innerText = `${d.compliance_rate}%`;
        if (csatEl) csatEl.innerText = `${d.csat_avg} ★`;

        const otTbody = document.getElementById('overtimeTbody');
        if (otTbody) {
            otTbody.innerHTML = '';
            (d.overtime || []).forEach(o => {
                const over = o.scheduled_hours > o.weekly_hours_limit;
                otTbody.innerHTML += `
                    <tr>
                        <td class="p-2.5 font-bold">${this.esc(o.first_name_en)} ${this.esc(o.last_name_en)}</td>
                        <td class="p-2.5">${this.esc(o.unit_name || 'Floater')}</td>
                        <td class="p-2.5 font-bold ${over ? 'text-red-600' : 'text-slate-800'}">${this.esc(o.scheduled_hours)} hrs/wk</td>
                        <td class="p-2.5">${this.esc(o.weekly_hours_limit)} hrs</td>
                        <td class="p-2.5 font-bold text-[10px] ${over ? 'text-red-600' : 'text-emerald-600'}">${over ? 'OVERTIME ALERT' : 'OPTIMAL'}</td>
                    </tr>
                `;
            });
        }
    }

    async runAuditScanner() {
        const res = await this.safeFetch('index.php?action=run_data_drift_scan');
        if (!res.ok) return;
        const d = res.data;
        const kpiEl = document.getElementById('kpi-anomalies');
        if (kpiEl) kpiEl.innerText = (d.anomalies || []).length;

        if (!d.anomalies || d.anomalies.length === 0) {
            this.showToast('Drift Scan: 0 anomalies detected. System fully compliant.', 'success');
        } else {
            this.showToast(`Drift Scan: ${d.anomalies[0]}`, 'error');
        }
    }

    // =========================================================================
    // 8. ACCESS CONTROL MATRIX (RBAC Management)
    // =========================================================================

    /** Switch between RBAC sub-views (users / roles / permissions / audit) */
    switchAccessView(viewId) {
        // R3: Audit requires audit.view — do not open an empty 403 panel
        if (viewId === 'audit' && !this.hasPerm('audit', 'view')) {
            this.showToast('Audit Log requires administrator access.', 'error');
            viewId = 'users';
        }
        this.rbacActiveView = viewId;
        const views = ['users', 'roles', 'permissions', 'audit'];
        views.forEach(v => {
            const el = document.getElementById(`rbac-view-${v}`);
            if (el) el.classList.toggle('hidden', v !== viewId);
            const btn = document.getElementById(`rbac-tab-${v}`);
            if (btn) {
                if (v === viewId) {
                    btn.classList.add('active');
                } else {
                    btn.classList.remove('active');
                }
            }
        });
        // Trigger data load for selected view
        if (viewId === 'audit') this.loadAuditLog();
        if (viewId === 'permissions') this.renderRbacMatrix(this.rbacPermsCache);
        if (viewId === 'roles') this.renderRbacRoles(this.rbacRolesCache);
        if (viewId === 'users') this.renderRbacUsers(this.rbacUsersCache);
    }

    /** Master loader — fetches users, roles, permissions from API and populates all sub-views */
    async loadAccessMatrix() {
        if (!this.hasPerm('users', 'read')) {
            this.showToast('Access Control is not available for your role.', 'error');
            return;
        }
        this.applyAccessUiGates();
        const unit = this._rbacIgnoreUnit ? '' : this.currentUnitId();
        this._rbacIgnoreUnit = false;
        const q = unit ? `&unit_id=${encodeURIComponent(unit)}` : '';
        const [usersRes, rolesRes, permsRes] = await Promise.all([
            this.safeFetch(`index.php?action=rbac_list_users${q}`),
            this.safeFetch('index.php?action=rbac_list_roles'),
            this.safeFetch('index.php?action=rbac_list_permissions')
        ]);

        if (usersRes.ok) this.rbacUsersCache = usersRes.data.users || [];
        if (rolesRes.ok) this.rbacRolesCache = rolesRes.data.roles || [];
        if (permsRes.ok) this.rbacPermsCache = permsRes.data.permissions || [];

        // Layer 2: surface the active unit filter chip
        const chip = document.getElementById('rbacUnitScopeChip');
        const chipText = document.getElementById('rbacUnitScopeText');
        if (chip && chipText) {
            if (unit && usersRes.ok) {
                const sel = document.getElementById('hubUnitSelect');
                const label = sel && sel.selectedOptions[0] ? sel.selectedOptions[0].text : unit;
                const scoped = usersRes.data.scoped_count ?? '—';
                const global = usersRes.data.global_count ?? '—';
                chipText.textContent = `Showing access for ${label} · ${scoped} scoped + ${global} global`;
                chip.classList.remove('hidden');
            } else {
                chip.classList.add('hidden');
            }
        }

        // Populate stat tiles
        const users = this.rbacUsersCache;
        const totalRoleAssignments = users.reduce((sum, u) => sum + (u.roles ? u.roles.length : 0), 0);
        const activeUsers = users.filter(u => u.is_active == 1).length;
        const lockedUsers = users.filter(u => (u.failed_attempts || 0) >= 5).length;

        const statUsers = document.getElementById('rbacStatUsers');
        const statRoles = document.getElementById('rbacStatRoles');
        const statActive = document.getElementById('rbacStatActive');
        const statLocked = document.getElementById('rbacStatLocked');
        if (statUsers) statUsers.innerText = users.length;
        if (statRoles) statRoles.innerText = totalRoleAssignments;
        if (statActive) statActive.innerText = activeUsers;
        if (statLocked) statLocked.innerText = lockedUsers;

        // Populate the assign modal user dropdown
        const assignUserSelect = document.getElementById('rbacAssignUser');
        if (assignUserSelect) {
            assignUserSelect.innerHTML = '<option value="">— Select user —</option>';
            users.forEach(u => {
                assignUserSelect.innerHTML += `<option value="${this.esc(u.user_id)}">${this.esc(u.email || u.user_id)}</option>`;
            });
        }

        // Populate scope target dropdown from unit selector values
        const scopeIdSelect = document.getElementById('rbacAssignScopeId');
        if (scopeIdSelect) {
            scopeIdSelect.innerHTML = '';
            const unitSelect = document.getElementById('hubUnitSelect');
            if (unitSelect) {
                Array.from(unitSelect.options).forEach(opt => {
                    scopeIdSelect.innerHTML += `<option value="${this.esc(opt.value)}">${this.esc(opt.text)}</option>`;
                });
            }
            // Also add departments
            this.deptsCache.forEach(d => {
                scopeIdSelect.innerHTML += `<option value="${this.esc(d.department_id)}">${this.esc(d.code)} - ${this.esc(d.name_en)}</option>`;
            });
        }

        // Render active sub-view
        this.switchAccessView(this.rbacActiveView);
    }

    /** Render users table with role pills, scope, status, action buttons */
    renderRbacUsers(users) {
        const tbody = document.getElementById('rbacUsersBody');
        if (!tbody) return;
        tbody.innerHTML = '';

        if (!users || users.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="p-6 text-center text-slate-400">No users found.</td></tr>';
            return;
        }

        users.forEach(u => {
            const rolePills = (u.roles || []).map(r =>
                `<span class="rbac-pill pill-${this.esc(r.role_code)}">${this.esc(r.role_code)}</span>`
            ).join(' ');
            const scopeText = (u.roles || []).map(r => {
                if (r.scope_type === 'global') return 'Global';
                return `${this.esc(r.scope_type)}: ${this.esc(r.scope_id || '—')}`;
            }).join(', ') || '—';

            const isLocked = (u.failed_attempts || 0) >= 5;
            const statusBadge = isLocked
                ? '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-red-100 text-red-800">LOCKED</span>'
                : u.is_active == 1
                    ? '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">ACTIVE</span>'
                    : '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-200 text-slate-600">INACTIVE</span>';

            const lastLogin = u.last_login_at ? this.esc(u.last_login_at) : 'Never';

            // Build revoke buttons for each role assignment
            const roleActions = (u.roles || []).map(r => {
                if (r.user_role_id && this.hasPerm('users', 'assign_role')) {
                    return `<button onclick="window.app.revokeRbacUser('${this.esc(r.user_role_id)}')" class="text-red-500 hover:underline font-bold text-[10px]" title="Revoke ${this.esc(r.role_code)}">Revoke</button>`;
                }
                return '';
            }).filter(Boolean).join(' ');

            const userActions = [];
            if (this.hasPerm('users', 'assign_role')) {
                userActions.push(`<button onclick="window.app.openRbacAssign('${this.esc(u.user_id)}')" class="text-indigo-600 hover:underline font-bold text-[10px]">Assign</button>`);
            }
            if (this.hasPerm('users', 'update')) {
                const nextActive = u.is_active == 1 ? 0 : 1;
                const label = u.is_active == 1 ? 'Deactivate' : 'Activate';
                userActions.push(`<button onclick="window.app.toggleRbacUserActive('${this.esc(u.user_id)}', ${nextActive})" class="text-amber-600 hover:underline font-bold text-[10px]">${label}</button>`);
            }
            if (this.hasPerm('users', 'delete')) {
                userActions.push(`<button onclick="window.app.deleteRbacUser('${this.esc(u.user_id)}')" class="text-red-700 hover:underline font-bold text-[10px]">Delete</button>`);
            }
            const actions = [roleActions, userActions.join(' ')].filter(Boolean).join(' ') || '—';

            tbody.innerHTML += `
                <tr>
                    <td class="p-3"><div class="font-bold text-slate-800">${this.esc(u.email || u.user_id)}</div><div class="text-[10px] text-slate-400 font-mono">${this.esc(u.user_id)}</div></td>
                    <td class="p-3">${rolePills || '<span class="text-slate-400">None</span>'}</td>
                    <td class="p-3 text-[11px]">${scopeText}</td>
                    <td class="p-3 font-mono text-[11px]">${lastLogin}</td>
                    <td class="p-3">${statusBadge}</td>
                    <td class="p-3 text-center space-x-1">${actions}</td>
                </tr>
            `;
        });
    }

    /** Client-side filter by search text and role dropdown */
    filterRbacUsers() {
        const query = (document.getElementById('rbacUserSearch')?.value || '').toLowerCase();
        const roleFilter = document.getElementById('rbacRoleFilter')?.value || '';

        let filtered = this.rbacUsersCache;

        if (query) {
            filtered = filtered.filter(u =>
                (u.email || u.user_id || '').toLowerCase().includes(query)
            );
        }
        if (roleFilter) {
            filtered = filtered.filter(u =>
                (u.roles || []).some(r => r.role_code === roleFilter)
            );
        }

        this.renderRbacUsers(filtered);
    }

    /** Render role definition cards with hierarchy level and permission tags */
    renderRbacRoles(roles) {
        const grid = document.getElementById('rbacRolesGrid');
        if (!grid) return;
        grid.innerHTML = '';

        if (!roles || roles.length === 0) {
            grid.innerHTML = '<div class="col-span-2 text-center text-slate-400 p-6">No role definitions found.</div>';
            return;
        }

        // Sort by hierarchy level descending
        const sorted = [...roles].sort((a, b) => (b.hierarchy_level || 0) - (a.hierarchy_level || 0));
        const roleColorMap = {
            'ADMIN': 'border-red-200 bg-red-50/30',
            'MANAGER': 'border-purple-200 bg-purple-50/30',
            'SUPERVISOR': 'border-amber-200 bg-amber-50/30',
            'STAFF_NURSE': 'border-teal-200 bg-teal-50/30'
        };

        sorted.forEach(r => {
            const borderClass = roleColorMap[r.role_code] || 'border-slate-200 bg-white';
            // Find permissions for this role
            const rolePerms = this.rbacPermsCache.filter(p =>
                (p.granted_to_roles || []).includes(r.role_code)
            );
            const permTags = rolePerms.slice(0, 8).map(p =>
                `<span class="inline-block px-2 py-0.5 bg-white border border-slate-200 rounded text-[10px] font-mono text-slate-600">${this.esc(p.resource)}.${this.esc(p.action)}</span>`
            ).join(' ');
            const moreCount = rolePerms.length > 8 ? `<span class="text-[10px] text-slate-400 font-bold">+${rolePerms.length - 8} more</span>` : '';

            grid.innerHTML += `
                <div class="rounded-xl border ${borderClass} p-4 space-y-3">
                    <div class="flex items-center justify-between">
                        <div>
                            <span class="rbac-pill pill-${this.esc(r.role_code)}">${this.esc(r.role_code)}</span>
                            <span class="ml-2 font-bold text-sm text-slate-800">${this.esc(r.role_name_en || r.role_code)}</span>
                        </div>
                        <span class="text-[10px] font-mono text-slate-400">Level ${this.esc(r.hierarchy_level)}</span>
                    </div>
                    <p class="text-xs text-slate-600">${this.esc(r.description || 'No description provided.')}</p>
                    <div>
                        <div class="text-[10px] font-bold text-slate-500 uppercase tracking-wide mb-1">Permissions (${rolePerms.length})</div>
                        <div class="flex flex-wrap gap-1">${permTags} ${moreCount}</div>
                    </div>
                    <div class="flex items-center gap-3 text-[10px] text-slate-400 pt-1 border-t border-slate-100">
                        <span>${r.is_system_role == 1 ? '🔒 System Role' : '📝 Custom Role'}</span>
                        <span>${r.is_active == 1 ? '✅ Active' : '⛔ Inactive'}</span>
                    </div>
                </div>
            `;
        });
    }

    /** Render the permissions matrix with resource groups and check marks */
    renderRbacMatrix(permissions) {
        const tbody = document.getElementById('rbacMatrixBody');
        if (!tbody) return;
        tbody.innerHTML = '';

        if (!permissions || permissions.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="p-6 text-center text-slate-400">No permissions data available.</td></tr>';
            return;
        }

        const allRoles = ['ADMIN', 'MANAGER', 'SUPERVISOR', 'STAFF_NURSE'];

        // Group by resource
        const grouped = {};
        permissions.forEach(p => {
            if (!grouped[p.resource]) grouped[p.resource] = [];
            grouped[p.resource].push(p);
        });

        let lastResource = '';
        Object.keys(grouped).sort().forEach(resource => {
            grouped[resource].forEach(p => {
                const showResource = resource !== lastResource;
                lastResource = resource;

                let row = '<tr class="border-b border-slate-50">';
                row += `<td class="p-2.5 text-left">`;
                if (showResource) {
                    row += `<span class="font-bold text-slate-800 text-xs">${this.esc(resource)}</span><br>`;
                }
                row += `<span class="text-[11px] text-slate-500 font-mono">.${this.esc(p.action)}</span></td>`;
                row += `<td class="p-2.5 text-center"><span class="text-[10px] font-mono text-slate-400">${this.esc(p.scope || 'global')}</span></td>`;

                allRoles.forEach(role => {
                    const granted = (p.granted_to_roles || []).includes(role);
                    row += `<td class="p-2.5 text-center">`;
                    if (granted) {
                        row += `<span class="inline-flex items-center justify-center w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 font-bold text-xs">✓</span>`;
                    } else {
                        row += `<span class="inline-flex items-center justify-center w-6 h-6 rounded-full bg-slate-50 text-slate-300 text-xs">·</span>`;
                    }
                    row += `</td>`;
                });

                row += '</tr>';
                tbody.innerHTML += row;
            });
        });
    }

    /** Fetch and render audit log entries (full viewer with filters + pagination) */
    async loadAuditLog(reset = false) {
        if (!this.hasPerm('audit', 'view')) {
            this.showToast('Audit Log requires administrator access.', 'error');
            return;
        }
        if (reset || this._auditOffset === undefined) {
            this._auditOffset = 0;
        }
        this._auditLimit = this._auditLimit || 50;

        const filter = document.getElementById('rbacAuditFilter')?.value || '';
        const q = document.getElementById('rbacAuditSearch')?.value?.trim() || '';
        const from = document.getElementById('rbacAuditFrom')?.value || '';
        const to = document.getElementById('rbacAuditTo')?.value || '';

        let url = `index.php?action=rbac_audit_log&limit=${this._auditLimit}&offset=${this._auditOffset}`;
        if (filter) url += `&action_filter=${encodeURIComponent(filter)}`;
        if (q) url += `&q=${encodeURIComponent(q)}`;
        if (from) url += `&date_from=${encodeURIComponent(from)}`;
        if (to) url += `&date_to=${encodeURIComponent(to)}`;
        const unit = this.currentUnitId();
        if (unit) url += `&unit_id=${encodeURIComponent(unit)}`;

        const container = document.getElementById('rbacAuditList');
        if (container) {
            container.innerHTML = '<div class="p-6 text-center text-slate-400 text-xs">Loading audit events…</div>';
        }

        const res = await this.safeFetch(url);
        if (!container) return;

        if (!res.ok) {
            container.innerHTML = `<div class="p-6 text-center text-red-500 text-xs">${this.esc((res.data && res.data.error) || 'Failed to load audit log.')}</div>`;
            return;
        }

        this._auditTotal = res.data.total ?? 0;
        this._auditHasMore = !!res.data.has_more;
        const entries = res.data.audit_log || [];

        const countEl = document.getElementById('rbacAuditCount');
        if (countEl) {
            countEl.textContent = `${this._auditTotal} event${this._auditTotal === 1 ? '' : 's'}`;
        }

        if (entries.length === 0) {
            container.innerHTML = '<div class="p-6 text-center text-slate-400 text-xs">No audit events match the selected filters.</div>';
        } else {
            this.renderAuditLog(entries, container);
        }

        const pager = document.getElementById('rbacAuditPager');
        const pageLabel = document.getElementById('rbacAuditPageLabel');
        const prevBtn = document.getElementById('rbacAuditPrev');
        const nextBtn = document.getElementById('rbacAuditNext');
        if (pager) {
            const showPager = this._auditTotal > this._auditLimit;
            pager.classList.toggle('hidden', !showPager);
            const start = this._auditOffset + 1;
            const end = Math.min(this._auditOffset + entries.length, this._auditTotal);
            if (pageLabel) pageLabel.textContent = `${start}–${end} of ${this._auditTotal}`;
            if (prevBtn) prevBtn.disabled = this._auditOffset <= 0;
            if (nextBtn) nextBtn.disabled = !this._auditHasMore;
        }
    }

    auditLogPage(direction) {
        const limit = this._auditLimit || 50;
        const next = (this._auditOffset || 0) + (direction * limit);
        if (next < 0) return;
        this._auditOffset = next;
        this.loadAuditLog(false);
    }

    clearAuditFilters() {
        const ids = ['rbacAuditFilter', 'rbacAuditSearch', 'rbacAuditFrom', 'rbacAuditTo'];
        ids.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.value = '';
        });
        this.loadAuditLog(true);
    }

    /** Format audit JSON payloads for display */
    formatAuditJson(val) {
        if (val === null || val === undefined || val === '') return '';
        if (typeof val === 'object') {
            try {
                return JSON.stringify(val, null, 2);
            } catch (e) {
                return String(val);
            }
        }
        if (typeof val === 'string') {
            try {
                const parsed = JSON.parse(val);
                return JSON.stringify(parsed, null, 2);
            } catch (e) {
                return val;
            }
        }
        return String(val);
    }

    /** Render audit entries with event type icons, expandable JSON, and meta */
    renderAuditLog(entries, container) {
        const eventConfig = {
            'ROLE_ASSIGNED':    { icon: '🟢', color: 'border-l-emerald-500', label: 'Role Assigned' },
            'ROLE_REVOKED':     { icon: '🔴', color: 'border-l-red-500', label: 'Role Revoked' },
            'USER_CREATED':     { icon: '👤', color: 'border-l-emerald-600', label: 'User Created' },
            'USER_UPDATED':     { icon: '✏️', color: 'border-l-sky-500', label: 'User Updated' },
            'USER_DEACTIVATED': { icon: '⏸️', color: 'border-l-amber-500', label: 'User Deactivated' },
            'USER_DELETED':     { icon: '🗑️', color: 'border-l-red-700', label: 'User Deleted' },
            'LOGIN_SUCCESS':    { icon: '🔓', color: 'border-l-blue-500', label: 'Login Success' },
            'LOGIN_FAILED':     { icon: '⚠️', color: 'border-l-amber-500', label: 'Login Failed' },
            'LOGIN_BLOCKED':    { icon: '🛑', color: 'border-l-red-600', label: 'Login Blocked' },
            'LOGOUT':           { icon: '🚪', color: 'border-l-slate-400', label: 'Logout' },
            'SESSION_EXPIRED':  { icon: '⏱️', color: 'border-l-amber-400', label: 'Session Expired' },
            'ACCESS_DENIED':    { icon: '🚫', color: 'border-l-red-400', label: 'Access Denied' },
            'ACCOUNT_LOCKED':   { icon: '🔒', color: 'border-l-red-600', label: 'Account Locked' },
            'PERMISSION_CHECK': { icon: '🔍', color: 'border-l-slate-400', label: 'Permission Check' },
        };

        let html = '<div class="divide-y divide-slate-100">';
        entries.forEach((e, idx) => {
            const cfg = eventConfig[e.action] || { icon: '📌', color: 'border-l-slate-300', label: e.action };
            const timestamp = e.created_at || '—';
            const meta = [];
            if (e.resource_type) meta.push(`Resource: <span class="font-mono">${this.esc(e.resource_type)}</span>`);
            if (e.resource_id) meta.push(`ID: <span class="font-mono">${this.esc(e.resource_id)}</span>`);
            if (e.target_user_id) meta.push(`Target: <span class="font-mono">${this.esc(e.target_user_id)}</span>`);
            if (e.ip_address) meta.push(`IP: <span class="font-mono">${this.esc(e.ip_address)}</span>`);

            const oldStr = this.formatAuditJson(e.old_value);
            const newStr = this.formatAuditJson(e.new_value);
            const hasDetail = !!(oldStr || newStr || e.user_agent);
            const detailId = `audit-detail-${e.log_id || idx}`;

            html += `
                <div class="border-l-4 ${cfg.color} hover:bg-slate-50/80 transition">
                    <div class="flex items-start gap-3 px-4 py-3">
                        <span class="text-base mt-0.5 shrink-0">${cfg.icon}</span>
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center gap-2 flex-wrap">
                                <span class="font-bold text-xs text-slate-800">${this.esc(cfg.label)}</span>
                                <span class="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-500 font-mono">${this.esc(e.action || '')}</span>
                                <span class="text-[10px] text-slate-400 font-mono ml-auto">${this.esc(timestamp)}</span>
                            </div>
                            <div class="text-[11px] text-slate-600 mt-0.5">
                                Actor: <span class="font-mono font-bold">${this.esc(e.actor_user_id || '—')}</span>
                                ${e.actor_role ? ` <span class="text-slate-400">(${this.esc(e.actor_role)})</span>` : ''}
                            </div>
                            ${meta.length ? `<div class="text-[10px] text-slate-500 mt-1 flex flex-wrap gap-x-2 gap-y-0.5">${meta.join('<span class="text-slate-300">·</span>')}</div>` : ''}
                            ${hasDetail ? `<button type="button" onclick="document.getElementById('${detailId}').classList.toggle('hidden')" class="mt-1.5 text-[10px] font-bold text-indigo-600 hover:underline">Show details</button>` : ''}
                            ${hasDetail ? `
                            <div id="${detailId}" class="hidden mt-2 space-y-2">
                                ${oldStr ? `<div><div class="text-[10px] font-bold text-slate-500 uppercase">Before</div><pre class="text-[10px] font-mono bg-slate-50 border border-slate-100 rounded p-2 overflow-x-auto max-h-40 whitespace-pre-wrap">${this.esc(oldStr)}</pre></div>` : ''}
                                ${newStr ? `<div><div class="text-[10px] font-bold text-slate-500 uppercase">After</div><pre class="text-[10px] font-mono bg-emerald-50/50 border border-emerald-100 rounded p-2 overflow-x-auto max-h-40 whitespace-pre-wrap">${this.esc(newStr)}</pre></div>` : ''}
                                ${e.user_agent ? `<div class="text-[10px] text-slate-400 truncate" title="${this.esc(e.user_agent)}">UA: ${this.esc(e.user_agent)}</div>` : ''}
                            </div>` : ''}
                        </div>
                    </div>
                </div>
            `;
        });
        html += '</div>';
        container.innerHTML = html;
    }

    /** Fetch role impact preview for assign modal (Layer 3: names the scope) */
    async updateRbacImpact() {
        const roleCode = document.getElementById('rbacAssignRole')?.value;
        const panel = document.getElementById('rbacImpactPanel');
        const title = document.getElementById('rbacImpactTitle');
        const permsDiv = document.getElementById('rbacImpactPerms');
        if (!panel || !permsDiv) return;

        if (!roleCode) {
            panel.classList.add('hidden');
            return;
        }

        const res = await this.safeFetch(`index.php?action=rbac_role_impact&role_code=${encodeURIComponent(roleCode)}`);
        if (!res.ok || !res.data) {
            panel.classList.add('hidden');
            return;
        }

        const data = res.data;
        panel.classList.remove('hidden');

        const scopeType = document.getElementById('rbacAssignScope')?.value || 'global';
        const scopeIdEl = document.getElementById('rbacAssignScopeId');
        let scopeLabel = 'global (all units)';
        if (scopeType === 'unit' && scopeIdEl && scopeIdEl.selectedOptions[0]) {
            scopeLabel = `unit · ${scopeIdEl.selectedOptions[0].text}`;
        } else if (scopeType === 'department' && scopeIdEl && scopeIdEl.selectedOptions[0]) {
            scopeLabel = `department · ${scopeIdEl.selectedOptions[0].text}`;
        }

        if (title) {
            title.innerHTML = `<span class="rbac-pill pill-${this.esc(roleCode)}">${this.esc(roleCode)}</span> on <strong>${this.esc(scopeLabel)}</strong> — ${this.esc(data.role?.user_count || 0)} user(s) currently hold this role`;
        }

        if (permsDiv) {
            const permsList = data.permissions || [];
            const scopeNote = scopeType === 'global'
                ? ''
                : `<div class="w-full text-[10px] text-amber-700 mb-1">Grants listed permissions on <strong>${this.esc(scopeLabel)}</strong> only.</div>`;
            permsDiv.innerHTML = scopeNote + permsList.map(p =>
                `<span class="inline-block px-2 py-0.5 bg-white border border-slate-200 rounded text-[10px] font-mono text-slate-600">${this.esc(p.resource)}.${this.esc(p.action)}</span>`
            ).join(' ');
            if (permsList.length === 0) {
                permsDiv.innerHTML = scopeNote + '<span class="text-slate-400 text-[10px]">No permissions assigned to this role.</span>';
            }
        }
    }

    /** Show/hide scope target field based on scope type selection */
    toggleRbacScopeId() {
        const scopeType = document.getElementById('rbacAssignScope')?.value;
        const group = document.getElementById('rbacScopeIdGroup');
        if (!group) return;
        group.style.display = scopeType === 'global' ? 'none' : '';
        // Layer 3: refresh impact text when scope changes
        this.updateRbacImpact();
    }

    /** POST to rbac_assign_role — full validation before submit */
    async submitRbacAssign() {
        if (!this.hasPerm('users', 'assign_role')) {
            this.showToast('You do not have permission to assign roles.', 'error');
            return;
        }
        const userId = document.getElementById('rbacAssignUser')?.value;
        const roleCode = document.getElementById('rbacAssignRole')?.value;
        const scopeType = document.getElementById('rbacAssignScope')?.value || 'global';
        const scopeId = document.getElementById('rbacAssignScopeId')?.value || null;
        const from = document.getElementById('rbacAssignFrom')?.value || null;
        const to = document.getElementById('rbacAssignTo')?.value || null;
        const reason = document.getElementById('rbacAssignReason')?.value || '';

        if (!userId || !roleCode) {
            this.showToast('Please select both a user and a role.', 'error');
            return;
        }
        if (scopeType !== 'global' && !scopeId) {
            this.showToast('Select a scope target (unit or department).', 'error');
            return;
        }

        const payload = {
            user_id: userId,
            role_code: roleCode,
            scope_type: scopeType,
            scope_id: scopeType !== 'global' ? scopeId : null,
            effective_from: from || new Date().toISOString().slice(0, 10),
            effective_to: to || null,
            reason: reason
        };

        const res = await this.safeFetch('index.php?action=rbac_assign_role', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            this.closeModal('rbacAssignModal');
            this.showToast(res.data.message || 'Role assigned successfully.', 'success');
            this.loadAccessMatrix();
        } else {
            this.showToast((res.data && res.data.error) || 'Failed to assign role.', 'error');
        }
    }

    /** POST to rbac_revoke_role */
    async revokeRbacUser(userRoleId) {
        if (!confirm('Are you sure you want to revoke this role assignment? This action is logged.')) return;

        const res = await this.safeFetch('index.php?action=rbac_revoke_role', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                user_role_id: userRoleId,
                reason: 'Revoked via Access Matrix UI'
            })
        });

        if (res.ok) {
            this.showToast(res.data.message || 'Role revoked.', 'success');
            this.loadAccessMatrix();
        } else {
            this.showToast((res.data && res.data.error) || 'Failed to revoke role.', 'error');
        }
    }

    /** R12 FIX: fetch CSV via safeFetch and download as Blob (no blank 403 tab) */
    async exportRbacCsv() {
        if (!this.hasPerm('reports', 'export')) {
            this.showToast('CSV export requires reports.export permission.', 'error');
            return;
        }
        const unit = this.currentUnitId();
        const q = unit ? `&unit_id=${encodeURIComponent(unit)}` : '';
        try {
            const res = await fetch(`index.php?action=rbac_export_csv${q}`, {
                headers: this.csrfToken ? { 'X-CSRF-Token': this.csrfToken } : {},
            });
            if (res.status === 401) {
                window.location.href = 'index.php';
                return;
            }
            if (res.status === 403) {
                this.showToast('Export denied — you lack reports.export.', 'error');
                return;
            }
            if (!res.ok) {
                this.showToast('Export failed.', 'error');
                return;
            }
            const contentType = res.headers.get('content-type') || '';
            if (contentType.includes('application/json')) {
                const data = await res.json();
                this.showToast(data.error || 'Export failed.', 'error');
                return;
            }
            const blob = await res.blob();
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `rbac-export-${new Date().toISOString().slice(0, 10)}.csv`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            URL.revokeObjectURL(url);
            this.showToast('CSV export downloaded.', 'success');
        } catch (e) {
            this.showToast('Export network error.', 'error');
        }
    }

    // =========================================================================
    // R13: Wire previously orphaned endpoints (notifications / feedback / backlog)
    // =========================================================================

    async loadNotifications() {
        const res = await this.safeFetch('index.php?action=get_notifications');
        if (!res.ok) return [];
        return Array.isArray(res.data) ? res.data : (res.data.notifications || []);
    }

    async submitFeedback(message, category = 'general') {
        if (!message || !String(message).trim()) {
            this.showToast('Feedback message is required.', 'error');
            return false;
        }
        const res = await this.safeFetch('index.php?action=submit_feedback', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: String(message).trim(), category }),
        });
        if (res.ok) {
            this.showToast(res.data.message || 'Feedback submitted. Thank you.', 'success');
            return true;
        }
        this.showToast((res.data && res.data.error) || 'Failed to submit feedback.', 'error');
        return false;
    }

    async upvoteBacklog(itemId) {
        if (!itemId) return false;
        const res = await this.safeFetch('index.php?action=upvote_backlog', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ item_id: itemId }),
        });
        if (res.ok) {
            this.showToast(res.data.message || 'Upvoted.', 'success');
            return true;
        }
        this.showToast((res.data && res.data.error) || 'Upvote failed.', 'error');
        return false;
    }

    // =========================================================================
    // TOAST NOTIFICATIONS
    // =========================================================================

    showToast(msg, type) {
        const box = document.getElementById('toastBox');
        if (!box) return;
        box.classList.remove('hidden');
        document.getElementById('toastMsg').innerText = msg;
        box.className = (type === 'error')
            ? "p-3 rounded-xl border border-red-200 bg-red-50 text-red-900 text-xs font-semibold flex items-center justify-between shadow-sm"
            : "p-3 rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-900 text-xs font-semibold flex items-center justify-between shadow-sm";
        setTimeout(() => { box.classList.add('hidden'); }, 5000);
    }
}

// Global Single Instance Binding with Immediate Execution Guard
window.app = new App();

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => window.app.init());
} else {
    window.app.init();
}
