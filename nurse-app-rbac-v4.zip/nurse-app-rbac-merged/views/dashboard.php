<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AIGH Nursing Management</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <!-- L7 FIX: Removed Segoe+UI from Google Fonts (proprietary Microsoft font, not hosted on Google Fonts) -->
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="public/css/aigh-theme.css">
    <!-- C3 FIX: CSRF token for all POST requests -->
    <meta name="csrf-token" content="<?php echo htmlspecialchars($_SESSION['csrf_token'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
    <style>
        body { font-family: 'Segoe UI', system-ui, sans-serif; }
        [dir="rtl"] body { font-family: 'Tajawal', sans-serif; }
    </style>
</head>
<!-- M6 FIX: Embed current role from server session into data attribute -->
<body class="aigh-app bg-[#f3f4f6] text-slate-800 min-h-screen flex flex-col" data-current-role="<?php echo htmlspecialchars($_SESSION['role'] ?? 'HEAD_NURSE', ENT_QUOTES, 'UTF-8'); ?>">

    <!-- Top Window Bar -->
    <header class="bg-[#464775] text-white h-12 flex items-center justify-between px-3 z-30 shadow-sm shrink-0">
        <div class="flex items-center space-x-3 rtl:space-x-reverse">
            <div>
                <div class="aigh-title">Nursing Management</div>
                <div class="aigh-subtitle">Hospital workforce, scheduling and compliance</div>
            </div>
        </div>
        <div class="flex items-center space-x-2 rtl:space-x-reverse text-xs">
            <!-- Layer 1: options populated from get_sub_units (not hardcoded) -->
            <select id="hubUnitSelect" onchange="window.app.onUnitContextChange()"
                    class="bg-[#33344a] text-white font-bold rounded px-2 py-1 outline-none cursor-pointer min-w-[12rem]">
                <option value="">Loading units…</option>
            </select>
            <!-- R1 FIX: Role is identity from the authenticated session, not a free switcher.
                 The old <select> called switch_user and minted sessions with no password.
                 Show current role as a read-only badge. Demo role-switch (if APP_DEMO_MODE)
                 is only available to authenticated Admins via the gated API. -->
            <span id="appRoleBadge" class="bg-indigo-900 font-bold text-amber-300 rounded px-2 py-1 select-none"
                  title="Signed-in role (from session)">
                <?php
                $displayRole = $_SESSION['user_role'] ?? $_SESSION['role'] ?? '—';
                $label = match (\Config\Rbac::normalise((string)$displayRole)) {
                    'ADMIN'       => '🔑 Admin',
                    'MANAGER'     => '📋 Manager',
                    'SUPERVISOR'  => '👑 Supervisor',
                    'STAFF_NURSE' => '👩‍⚕️ Staff Nurse',
                    default       => htmlspecialchars((string)$displayRole, ENT_QUOTES, 'UTF-8'),
                };
                echo $label;
                ?>
            </span>
            <!-- Hidden for any residual JS that still looks up appRoleSelect -->
            <select id="appRoleSelect" class="hidden" aria-hidden="true" tabindex="-1">
                <option value="<?php echo htmlspecialchars($_SESSION['role'] ?? 'SUPERVISOR', ENT_QUOTES, 'UTF-8'); ?>" selected></option>
            </select>
            <button onclick="window.app.toggleLang()" class="bg-[#33344a] hover:bg-[#3d3e59] px-2.5 py-1 rounded font-bold">
                <span id="langBtn">العربية</span>
            </button>
            <!-- R2 FIX: Visible session identity + logout — login/logout cycle was unreachable -->
            <span id="sessionUser" class="text-[11px] text-slate-300 max-w-[140px] truncate" title="Signed-in user">…</span>
            <button type="button" onclick="window.app.logout()"
                    class="bg-[#33344a] hover:bg-red-800/80 px-2.5 py-1 rounded font-bold text-white"
                    title="Sign out">
                Sign out
            </button>
        </div>
    </header>

    <!-- App Container -->
    <div class="flex flex-1 overflow-hidden">

        <!-- Left Navigation Rail -->
        <!-- M2 FIX: Removed duplicate horizontal tab bar; keeping only the left rail -->
        <nav class="w-16 bg-[#ebebeb] border-r border-slate-300 flex flex-col items-center py-2 space-y-3 shrink-0 text-[10px] font-semibold text-slate-600">
        <button onclick="window.app.switchTab('shifts')" id="tab-shifts" class="flex flex-col items-center p-2 rounded-lg text-indigo-700 font-bold bg-slate-200 w-12"><span class="text-lg">📅</span> Shifts</button>
        <button onclick="window.app.switchTab('directory')" id="tab-directory" class="flex flex-col items-center p-2 rounded-lg hover:bg-slate-200 w-12"><span class="text-lg">👥</span> Nurses</button>
        <button onclick="window.app.switchTab('leaves')" id="tab-leaves" class="flex flex-col items-center p-2 rounded-lg hover:bg-slate-200 w-12"><span class="text-lg">🏖️</span> Leaves</button>
        <button onclick="window.app.switchTab('handovers')" id="tab-handovers" class="flex flex-col items-center p-2 rounded-lg hover:bg-slate-200 w-12"><span class="text-lg">📋</span> SBAR</button>
        <button onclick="window.app.switchTab('rollout')" id="tab-rollout" class="flex flex-col items-center p-2 rounded-lg hover:bg-slate-200 w-12"><span class="text-lg">🚀</span> Waves</button>
        <button onclick="window.app.switchTab('analytics')" id="tab-analytics" class="flex flex-col items-center p-2 rounded-lg hover:bg-slate-200 w-12"><span class="text-lg">📈</span> Insights</button>
        <button onclick="window.app.switchTab('departments')" id="tab-departments" class="flex flex-col items-center p-2 rounded-lg hover:bg-slate-200 w-12"><span class="text-lg">🏢</span> Depts</button>
        <?php /* R3 FIX: Only show Access tab when the session role holds users.read
                 (ADMIN / MANAGER / SUPERVISOR). STAFF_NURSE no longer sees a tab that 403s. */ ?>
        <?php if (\Middleware\AuthMiddleware::can('users', 'read')): ?>
        <button onclick="window.app.switchTab('access')" id="tab-access" class="flex flex-col items-center p-2 rounded-lg hover:bg-slate-200 w-12"><span class="text-lg">🔐</span> Access</button>
        <?php endif; ?>
    </nav>

        <!-- Main Workspace -->
        <main class="flex-1 overflow-y-auto bg-white p-6 space-y-6">

            <div id="toastBox" class="hidden p-3.5 rounded-xl border text-xs font-semibold flex items-center justify-between shadow-sm">
                <span id="toastMsg"></span>
                <button onclick="document.getElementById('toastBox').classList.add('hidden')" class="font-bold ml-3">✕</button>
            </div>

 <!-- =================================================================== -->
<!-- DEPARTMENTS & SUB-UNITS CLINICAL MANAGEMENT (M365 THEME)            -->
<!-- =================================================================== -->
<section id="view-departments" class="hidden space-y-6">

    <!-- Top Stats & Filter Bar -->
    <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div class="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-100 pb-3 gap-3">
            <div>
                <h2 class="text-base font-bold text-slate-900">Hospital Departments & Clinical Sub-Units</h2>
                <p class="text-xs text-slate-500">Configure clinical departments, staffing minimums, and child units for pilot waves.</p>
            </div>
            <div class="flex items-center gap-2">
                <button onclick="window.app.openDeptModal()" class="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-sm transition">
                    + Add Department
                </button>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
            <!-- View Mode Switcher -->
            <div>
                <label class="block font-bold text-slate-600 mb-1">View Display</label>
                <select id="selViewMode" onchange="window.app.onDeptViewModeChange()" class="w-full bg-slate-50 border border-slate-300 font-semibold rounded-xl p-2.5 outline-none">
                    <option value="DEPARTMENTS">Departments Overview</option>
                    <option value="SUB_UNITS">Sub-Units Drill-Down</option>
                </select>
            </div>

            <!-- Active Department Filter -->
            <div>
                <label class="block font-bold text-slate-600 mb-1">Selected Department</label>
                <select id="selSelectedDept" onchange="window.app.onSelectedDeptDropdownChange()" class="w-full bg-slate-50 border border-slate-300 font-semibold rounded-xl p-2.5 outline-none">
                    <!-- Populated dynamically -->
                </select>
            </div>

            <!-- Search Filter -->
            <div>
                <label class="block font-bold text-slate-600 mb-1">Search Directory</label>
                <input type="text" id="deptSearchInput" oninput="window.app.filterDeptTable()" placeholder="Search code or unit..." class="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 outline-none">
            </div>

            <!-- Sub-Unit Add Button -->
            <div class="flex items-end">
                <button onclick="window.app.openSubUnitModal()" id="btnAddSubUnit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2.5 px-4 rounded-xl shadow-sm transition">
                    + Add Sub-Unit
                </button>
            </div>
        </div>
    </div>

    <!-- Active Details Table Card -->
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="p-4 bg-slate-50/50 border-b border-slate-200 flex justify-between items-center">
            <span class="font-bold text-xs text-slate-700" id="tableHeaderCaption">Departments List</span>
            <div class="flex items-center gap-4 text-xs font-semibold">
                <span class="text-slate-500">Total Depts: <strong class="text-slate-800" id="countTotalDepts">0</strong></span>
                <span class="text-slate-500">Total Staff: <strong class="text-indigo-600" id="countTotalStaff">0</strong></span>
            </div>
        </div>

        <div class="overflow-x-auto w-full">
            <table class="w-full text-left rtl:text-right border-collapse text-xs min-w-[700px]">
                <thead class="bg-slate-50 font-semibold text-slate-700 border-b border-slate-200" id="deptTableHead">
                    <!-- Dynamic Headers -->
                </thead>
                <tbody id="deptTableBody" class="divide-y divide-slate-100 bg-white">
                    <!-- Dynamic Rows -->
                </tbody>
            </table>
        </div>
    </div>
</section>

<!-- M1 FIX: Single deptModal (removed duplicate at lines 241-263) -->
<!-- MODAL: ADD / EDIT DEPARTMENT -->
<div id="deptModal" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center hidden p-4">
    <div class="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 text-xs">
        <h3 class="font-bold text-sm text-slate-900" id="deptModalTitle">Add Department</h3>
        <input type="hidden" id="dmDeptId">
        <div>
            <label class="font-bold block mb-1">Department Code *</label>
            <input type="text" id="dmCode" placeholder="e.g. CRIT_CARE" class="w-full border border-slate-300 rounded-lg p-2.5 font-mono uppercase font-bold">
        </div>
        <div>
            <label class="font-bold block mb-1">Department Name (English) *</label>
            <input type="text" id="dmNameEn" placeholder="Critical Care Medicine" class="w-full border border-slate-300 rounded-lg p-2.5">
        </div>
        <div>
            <label class="font-bold block mb-1">اسم القسم (العربية) *</label>
            <input type="text" id="dmNameAr" dir="rtl" placeholder="طب العناية الحرجة" class="w-full border border-slate-300 rounded-lg p-2.5">
        </div>
        <div class="flex justify-end gap-2 pt-3 border-t">
            <!-- L8 FIX: Use closeModal() consistently -->
            <button onclick="window.app.closeModal('deptModal')" class="px-4 py-2 border rounded-xl font-semibold">Cancel</button>
            <button onclick="window.app.submitDept()" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold">Save Department</button>
        </div>
    </div>
</div>

<!-- MODAL: ADD / EDIT SUB-UNIT -->
<div id="subUnitModal" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center hidden p-4">
    <div class="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 text-xs">
        <h3 class="font-bold text-sm text-slate-900" id="subUnitModalTitle">Add Sub-Unit to Department</h3>
        <input type="hidden" id="smUnitId">

        <div>
            <label class="font-bold block mb-1">Parent Department *</label>
            <select id="smParentDept" class="w-full border border-slate-300 rounded-lg p-2.5 bg-slate-50 font-semibold">
                <!-- Loaded from Departments -->
            </select>
        </div>

        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="font-bold block mb-1">Sub-Unit Code *</label>
                <input type="text" id="smCode" placeholder="e.g. NICU_A" class="w-full border border-slate-300 rounded-lg p-2.5 font-mono uppercase font-bold">
            </div>
            <div>
                <label class="font-bold block mb-1">Sub-Unit Name (EN) *</label>
                <input type="text" id="smNameEn" placeholder="Neonatal ICU Pod A" class="w-full border border-slate-300 rounded-lg p-2.5">
            </div>
        </div>

        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="font-bold block mb-1">Day Shift Min Staff *</label>
                <input type="number" id="smDayQuota" value="2" min="1" class="w-full border border-slate-300 rounded-lg p-2.5 font-bold font-mono">
            </div>
            <div>
                <label class="font-bold block mb-1">Night Shift Min Staff *</label>
                <input type="number" id="smNightQuota" value="2" min="1" class="w-full border border-slate-300 rounded-lg p-2.5 font-bold font-mono">
            </div>
        </div>

        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="font-bold block mb-1">Rollout Wave</label>
                <select id="smWave" class="w-full border border-slate-300 rounded-lg p-2.5 bg-white font-semibold">
                    <option value="PILOT">PILOT</option>
                    <option value="WAVE_1">WAVE 1 (Critical Care)</option>
                    <option value="WAVE_2">WAVE 2 (Surgical)</option>
                    <option value="WAVE_3">WAVE 3 (Wards)</option>
                </select>
            </div>
            <div>
                <label class="font-bold block mb-1">Go-Live Status</label>
                <select id="smStatus" class="w-full border border-slate-300 rounded-lg p-2.5 bg-white font-semibold">
                    <option value="PLANNED">PLANNED</option>
                    <option value="TRAINING">TRAINING</option>
                    <option value="HYPERCARE">HYPERCARE</option>
                    <option value="STABILIZED">STABILIZED</option>
                </select>
            </div>
        </div>

        <div class="flex justify-end gap-2 pt-3 border-t">
            <!-- L8 FIX: Use closeModal() consistently -->
            <button onclick="window.app.closeModal('subUnitModal')" class="px-4 py-2 border rounded-xl font-semibold">Cancel</button>
            <button onclick="window.app.submitSubUnit()" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold">Save Sub-Unit</button>
        </div>
    </div>
</div>

<!-- M3 FIX: Removed orphan departmentsTbody table (was never populated by app.js) -->
<!-- M1 FIX: Removed duplicate deptModal that was below here -->
<!-- M2 FIX: Removed duplicate horizontal sub-navigation bar -->

            <!-- 1. SHIFTS MATRIX -->
            <section id="view-shifts" class="space-y-4">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between border-b pb-3 gap-2">
                    <div>
                        <h2 class="text-lg font-bold text-slate-900">Weekly Shift Matrix (Teams Shifts)</h2>
                        <p class="text-xs text-slate-500">Tap cell to assign D, E, N, X. Expired licenses and approved leaves are locked automatically.</p>
                    </div>
                    <div class="flex gap-2">
                        <button onclick="window.app.runAutoSweep()" class="bg-indigo-50 border border-indigo-200 text-indigo-700 font-bold text-xs px-3 py-2 rounded-xl">⚡ Run 30-Day Alert Sweep</button>
                        <button onclick="window.app.publishSchedule()" class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-sm">📤 Publish to Teams</button>
                    </div>
                </div>

                <div class="border border-slate-200 rounded-2xl overflow-x-auto shadow-sm">
                    <table class="w-full text-center border-collapse text-xs min-w-[700px]">
                        <thead id="shiftsThead" class="bg-slate-50 font-semibold text-slate-600 border-b"></thead>
                        <tbody id="shiftsTbody" class="divide-y divide-slate-100"></tbody>
                    </table>
                </div>

                <div class="bg-amber-50/50 border border-amber-200 rounded-2xl p-4 space-y-3">
                    <h3 class="font-bold text-xs text-amber-900">⚡ Unassigned Open Shifts Board</h3>
                    <div id="openShiftsList" class="grid grid-cols-1 md:grid-cols-3 gap-3"></div>
                </div>
            </section>

            <!-- 2. DIRECTORY -->
            <section id="view-directory" class="hidden space-y-4">
                <div class="flex justify-between items-center border-b pb-3">
                    <div>
                        <h2 class="text-lg font-bold text-slate-900">Nurse Registry & Master Data</h2>
                        <p class="text-xs text-slate-500">Includes 10-digit Saudi National ID / Iqama validation and license status.</p>
                    </div>
                    <!-- L8 FIX: Use openModal() consistently -->
                    <button onclick="window.app.openModal('nurseModal')" class="bg-emerald-600 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-sm">+ Add Nurse</button>
                </div>
                <div class="border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
                    <table class="w-full text-left rtl:text-right border-collapse text-xs">
                        <thead class="bg-slate-50 border-b text-slate-600 font-semibold">
                            <tr>
                                <th class="p-3">Nurse Profile</th>
                                <th class="p-3">KSA Identification</th>
                                <th class="p-3">Assigned Unit</th>
                                <th class="p-3">SCFHS Credential</th>
                                <th class="p-3">License Health</th>
                            </tr>
                        </thead>
                        <tbody id="directoryTbody" class="divide-y divide-slate-100"></tbody>
                    </table>
                </div>
            </section>

            <!-- 3. LEAVES -->
            <section id="view-leaves" class="hidden space-y-4">
                <div class="flex justify-between items-center border-b pb-3">
                    <div>
                        <h2 class="text-lg font-bold text-slate-900">Leave Management Engine</h2>
                        <p class="text-xs text-slate-500">Approved leaves automatically cross-lock shift creation.</p>
                    </div>
                    <!-- L8 FIX: Use openModal() consistently -->
                    <button onclick="window.app.openModal('leaveModal')" class="bg-emerald-600 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-sm">+ Request Leave</button>
                </div>
                <div class="border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
                    <table class="w-full text-left rtl:text-right border-collapse text-xs">
                        <thead class="bg-slate-50 border-b text-slate-600 font-semibold">
                            <tr>
                                <th class="p-3">Employee</th>
                                <th class="p-3">Leave Type</th>
                                <th class="p-3">Period</th>
                                <th class="p-3">Status</th>
                                <th class="p-3 text-center">Manager Action</th>
                            </tr>
                        </thead>
                        <tbody id="leavesTbody" class="divide-y divide-slate-100"></tbody>
                    </table>
                </div>
            </section>

            <!-- 4. HANDOVERS -->
            <section id="view-handovers" class="hidden space-y-4">
                <div class="flex justify-between items-center border-b pb-3">
                    <div>
                        <h2 class="text-lg font-bold text-slate-900">Shift Handover Feed (SBAR Protocol)</h2>
                        <p class="text-xs text-slate-500">Structured communication: Situation, Background, Assessment, Recommendation.</p>
                    </div>
                    <!-- L8 FIX: Use openModal() consistently -->
                    <button onclick="window.app.openModal('handoverModal')" class="bg-indigo-600 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-sm">+ New Handover</button>
                </div>
                <div id="handoverList" class="space-y-3 text-xs"></div>
            </section>

            <!-- 5. ROLLOUT WAVES -->
            <section id="view-rollout" class="hidden space-y-6">
                <div class="border-b pb-3">
                    <h2 class="text-lg font-bold text-slate-900">Hospital Rollout Waves & Support Desk</h2>
                    <p class="text-xs text-slate-500">Tracks pilot expansion to ED, CCU, OR, and Inpatient Wards.</p>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="border rounded-2xl p-4 bg-slate-50 space-y-3">
                        <h3 class="font-bold text-xs text-slate-800">Hospital Waves Status</h3>
                        <div id="wavesList" class="space-y-2 text-xs"></div>
                    </div>
                    <div class="border rounded-2xl p-4 bg-white space-y-3 shadow-sm">
                        <div class="flex justify-between items-center">
                            <h3 class="font-bold text-xs text-slate-800">Active Hypercare Tickets</h3>
                            <!-- L8 FIX: Use openModal() consistently -->
                            <button onclick="window.app.openModal('ticketModal')" class="text-[11px] text-indigo-600 font-bold underline">+ Log Ticket</button>
                        </div>
                        <div id="ticketsList" class="space-y-2 text-xs"></div>
                    </div>
                </div>
            </section>

            <!-- 6. ANALYTICS -->
            <section id="view-analytics" class="hidden space-y-6">
                <div class="flex justify-between items-center border-b pb-3">
                    <div>
                        <h2 class="text-lg font-bold text-slate-900">Executive Insights & Continuous Optimization</h2>
                        <p class="text-xs text-slate-500">Overtime alerts, satisfaction score (CSAT), and self-healing data audits.</p>
                    </div>
                    <button onclick="window.app.runAuditScanner()" class="bg-indigo-600 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow-sm">🔍 Run Data Drift Scanner</button>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div class="p-4 rounded-2xl border border-emerald-200 bg-emerald-50/40">
                        <p class="text-[10px] uppercase font-bold text-emerald-700">SCFHS Compliance</p>
                        <div class="text-2xl font-black text-emerald-800" id="kpi-compliance">100%</div>
                    </div>
                    <div class="p-4 rounded-2xl border border-amber-200 bg-amber-50/40">
                        <p class="text-[10px] uppercase font-bold text-amber-700">CSAT Satisfaction</p>
                        <div class="text-2xl font-black text-amber-800" id="kpi-csat">4.8 ★</div>
                    </div>
                    <div class="p-4 rounded-2xl border border-indigo-200 bg-indigo-50/40">
                        <p class="text-[10px] uppercase font-bold text-indigo-700">Drift Anomaly Count</p>
                        <div class="text-2xl font-black text-indigo-800" id="kpi-anomalies">0</div>
                    </div>
                </div>

                <div class="border border-slate-200 rounded-2xl p-4 bg-white shadow-sm space-y-3">
                    <h3 class="font-bold text-xs text-slate-800">Statutory Workload & Overtime (48-Hour Threshold)</h3>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left rtl:text-right border-collapse text-xs">
                            <thead class="bg-slate-50 border-b text-slate-600">
                                <tr>
                                    <th class="p-2.5">Nurse</th>
                                    <th class="p-2.5">Unit</th>
                                    <th class="p-2.5">Scheduled Hours</th>
                                    <th class="p-2.5">Legal Limit</th>
                                    <th class="p-2.5">Risk Status</th>
                                </tr>
                            </thead>
                            <tbody id="overtimeTbody" class="divide-y divide-slate-100 font-mono"></tbody>
                        </table>
                    </div>
                </div>
            </section>

            <!-- ================================================================= -->
            <!-- 8. ACCESS CONTROL MATRIX (RBAC Management)                        -->
            <!-- ================================================================= -->
            <section id="view-access" class="hidden space-y-5">

                <!-- Sub-navigation tabs -->
                <div class="rbac-subnav flex items-center gap-1 border-b border-slate-200 pb-0">
                    <button onclick="window.app.switchAccessView('users')" id="rbac-tab-users" class="rbac-subnav-btn active">Users & Roles</button>
                    <button onclick="window.app.switchAccessView('roles')" id="rbac-tab-roles" class="rbac-subnav-btn">Roles</button>
                    <button onclick="window.app.switchAccessView('permissions')" id="rbac-tab-permissions" class="rbac-subnav-btn">Permissions</button>
                    <?php /* R3 FIX: Audit is ADMIN-only (audit.view) — hide rather than 403 */ ?>
                    <?php if (\Middleware\AuthMiddleware::can('audit', 'view')): ?>
                    <button onclick="window.app.switchAccessView('audit')" id="rbac-tab-audit" class="rbac-subnav-btn">Audit Log</button>
                    <?php endif; ?>
                </div>

                <!-- ── SUB-VIEW: Users & Roles ── -->
                <div id="rbac-view-users" class="rbac-subview">
                    <!-- Layer 2: visible unit-scope filter chip -->
                    <div id="rbacUnitScopeChip" class="hidden mb-3 px-3 py-2 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-center justify-between gap-2">
                        <span id="rbacUnitScopeText">Showing access for selected unit</span>
                        <button type="button" onclick="window.app.clearUnitScopeFilter()" class="text-indigo-600 font-bold hover:underline whitespace-nowrap">Show all units</button>
                    </div>
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                        <div>
                            <h2 class="text-base font-bold text-slate-900">Users & Role Assignments</h2>
                            <p class="text-xs text-slate-500">Manage who can access what — assign, revoke, and scope roles per unit or department.</p>
                        </div>
                        <div class="flex gap-2 flex-wrap">
                            <?php if (\Middleware\AuthMiddleware::can('users', 'create')): ?>
                            <button id="rbacBtnCreateUser" onclick="window.app.openRbacCreateUser()" class="rbac-btn rbac-btn-primary text-xs">+ Add User</button>
                            <?php endif; ?>
                            <?php if (\Middleware\AuthMiddleware::can('reports', 'export')): ?>
                            <button id="rbacBtnExport" onclick="window.app.exportRbacCsv()" class="rbac-btn rbac-btn-outline text-xs">↓ Export CSV</button>
                            <?php endif; ?>
                            <?php if (\Middleware\AuthMiddleware::can('users', 'assign_role')): ?>
                            <button id="rbacBtnAssign" onclick="window.app.openRbacAssign()" class="rbac-btn rbac-btn-primary text-xs">+ Assign Role</button>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Stat tiles -->
                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
                        <div class="rbac-stat-tile rbac-stat-teal">
                            <div class="rbac-stat-label">Total Users</div>
                            <div class="rbac-stat-val" id="rbacStatUsers">—</div>
                        </div>
                        <div class="rbac-stat-tile rbac-stat-green">
                            <div class="rbac-stat-label">Roles Assigned</div>
                            <div class="rbac-stat-val" id="rbacStatRoles">—</div>
                        </div>
                        <div class="rbac-stat-tile rbac-stat-amber">
                            <div class="rbac-stat-label">Active Now</div>
                            <div class="rbac-stat-val" id="rbacStatActive">—</div>
                        </div>
                        <div class="rbac-stat-tile rbac-stat-red">
                            <div class="rbac-stat-label">Locked Accounts</div>
                            <div class="rbac-stat-val" id="rbacStatLocked">—</div>
                        </div>
                    </div>

                    <!-- Toolbar -->
                    <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                        <div class="flex items-center gap-2 p-3 border-b border-slate-100 flex-wrap">
                            <input type="text" id="rbacUserSearch" oninput="window.app.filterRbacUsers()" placeholder="Search by email..." class="flex-1 min-w-[180px] bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs outline-none">
                            <select id="rbacRoleFilter" onchange="window.app.filterRbacUsers()" class="bg-white border border-slate-200 rounded-lg px-2.5 py-2 text-xs outline-none">
                                <option value="">All Roles</option>
                                <option value="ADMIN">Admin</option>
                                <option value="MANAGER">Manager</option>
                                <option value="SUPERVISOR">Supervisor</option>
                                <option value="STAFF_NURSE">Staff Nurse</option>
                            </select>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="w-full text-left border-collapse text-xs min-w-[650px]">
                                <thead class="bg-slate-50 border-b text-slate-600 font-semibold">
                                    <tr>
                                        <th class="p-3">User</th>
                                        <th class="p-3">Current Roles</th>
                                        <th class="p-3">Scope</th>
                                        <th class="p-3">Last Login</th>
                                        <th class="p-3">Status</th>
                                        <th class="p-3 text-center">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="rbacUsersBody" class="divide-y divide-slate-100"></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- ── SUB-VIEW: Roles ── -->
                <div id="rbac-view-roles" class="rbac-subview hidden">
                    <div class="mb-4">
                        <h2 class="text-base font-bold text-slate-900">Role Definitions</h2>
                        <p class="text-xs text-slate-500">Four-tier RBAC hierarchy aligned to hospital structure and PDPL least-privilege requirements.</p>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4" id="rbacRolesGrid"></div>
                </div>

                <!-- ── SUB-VIEW: Permissions Matrix ── -->
                <div id="rbac-view-permissions" class="rbac-subview hidden">
                    <div class="mb-4">
                        <h2 class="text-base font-bold text-slate-900">Permissions Matrix</h2>
                        <p class="text-xs text-slate-500">Full CRUD permission map across all resources and roles. Deny-by-default enforced at middleware layer.</p>
                    </div>
                    <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                        <div class="overflow-x-auto">
                            <table class="rbac-matrix-table w-full border-collapse text-xs min-w-[650px]">
                                <thead class="bg-slate-50 border-b">
                                    <tr>
                                        <th class="p-3 text-left text-[11px] font-bold text-slate-600 uppercase tracking-wider" style="min-width:160px">Resource · Action</th>
                                        <th class="p-3 text-center text-[11px] font-bold text-slate-600 uppercase tracking-wider">Scope</th>
                                        <th class="p-3 text-center"><span class="rbac-pill pill-ADMIN">ADMIN</span></th>
                                        <th class="p-3 text-center"><span class="rbac-pill pill-MANAGER">MANAGER</span></th>
                                        <th class="p-3 text-center"><span class="rbac-pill pill-SUPERVISOR">SUPERVISOR</span></th>
                                        <th class="p-3 text-center"><span class="rbac-pill pill-STAFF_NURSE">STAFF NURSE</span></th>
                                    </tr>
                                </thead>
                                <tbody id="rbacMatrixBody"></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- ── SUB-VIEW: Audit Log (ADMIN / audit.view) ── -->
                <div id="rbac-view-audit" class="rbac-subview hidden">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
                        <div>
                            <h2 class="text-base font-bold text-slate-900">Audit Log</h2>
                            <p class="text-xs text-slate-500">Immutable RBAC security events. Retained 7 years per PDPL Art. 29.</p>
                        </div>
                        <div class="flex items-center gap-2">
                            <span id="rbacAuditCount" class="text-[11px] text-slate-500 font-mono">—</span>
                            <button type="button" onclick="window.app.loadAuditLog(true)" class="rbac-btn rbac-btn-outline text-xs">↻ Refresh</button>
                        </div>
                    </div>

                    <!-- Filters -->
                    <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-3 mb-3 flex flex-wrap gap-2 items-end">
                        <div class="flex-1 min-w-[140px]">
                            <label class="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Search</label>
                            <input type="text" id="rbacAuditSearch" placeholder="Actor, resource, JSON…"
                                   class="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs outline-none"
                                   onkeydown="if(event.key==='Enter') window.app.loadAuditLog(true)">
                        </div>
                        <div>
                            <label class="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Event</label>
                            <select id="rbacAuditFilter" class="bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs outline-none">
                                <option value="">All events</option>
                                <option value="ROLE_ASSIGNED">Role Assigned</option>
                                <option value="ROLE_REVOKED">Role Revoked</option>
                                <option value="USER_CREATED">User Created</option>
                                <option value="USER_UPDATED">User Updated</option>
                                <option value="USER_DEACTIVATED">User Deactivated</option>
                                <option value="USER_DELETED">User Deleted</option>
                                <option value="LOGIN_SUCCESS">Login Success</option>
                                <option value="LOGIN_FAILED">Login Failed</option>
                                <option value="LOGIN_BLOCKED">Login Blocked</option>
                                <option value="LOGOUT">Logout</option>
                                <option value="SESSION_EXPIRED">Session Expired</option>
                                <option value="ACCESS_DENIED">Access Denied</option>
                                <option value="ACCOUNT_LOCKED">Account Locked</option>
                            </select>
                        </div>
                        <div>
                            <label class="text-[10px] font-bold text-slate-500 uppercase tracking-wide">From</label>
                            <input type="date" id="rbacAuditFrom" class="bg-white border border-slate-200 rounded-lg px-2 py-1.5 text-xs outline-none">
                        </div>
                        <div>
                            <label class="text-[10px] font-bold text-slate-500 uppercase tracking-wide">To</label>
                            <input type="date" id="rbacAuditTo" class="bg-white border border-slate-200 rounded-lg px-2 py-1.5 text-xs outline-none">
                        </div>
                        <button type="button" onclick="window.app.loadAuditLog(true)" class="rbac-btn rbac-btn-primary text-xs px-3 py-1.5">Apply</button>
                        <button type="button" onclick="window.app.clearAuditFilters()" class="text-xs text-slate-500 hover:underline px-1">Clear</button>
                    </div>

                    <div class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                        <div id="rbacAuditList">
                            <div class="p-6 text-center text-slate-400 text-xs">Loading audit events…</div>
                        </div>
                        <div id="rbacAuditPager" class="hidden border-t border-slate-100 px-4 py-3 flex items-center justify-between gap-2">
                            <button type="button" id="rbacAuditPrev" onclick="window.app.auditLogPage(-1)" class="text-xs font-bold text-indigo-600 hover:underline disabled:opacity-40">← Newer</button>
                            <span id="rbacAuditPageLabel" class="text-[11px] text-slate-500 font-mono"></span>
                            <button type="button" id="rbacAuditNext" onclick="window.app.auditLogPage(1)" class="text-xs font-bold text-indigo-600 hover:underline disabled:opacity-40">Older →</button>
                        </div>
                    </div>
                </div>

            </section>
        </main>
    </div>

    <!-- Modals -->
    <div id="nurseModal" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center hidden p-4">
        <form id="nmForm" class="bg-white rounded-2xl max-w-5xl w-full shadow-2xl text-xs overflow-hidden" enctype="multipart/form-data" onsubmit="window.app.submitNurse(event)">
            <div class="flex items-center justify-between px-6 py-4 border-b bg-slate-50">
                <div><h3 class="font-bold text-base">Add Nurse Master Profile</h3><p class="text-slate-500 mt-1">Complete workforce, identity, professional and compliance information.</p></div>
                <button type="button" onclick="window.app.closeModal('nurseModal')" class="w-9 h-9 border rounded-lg font-bold">✕</button>
            </div>
            <div class="nurse-master-scroll p-6 space-y-5">
                <div class="entry-card">
                    <div class="entry-heading"><span>01</span><div><h3>Employment & Identity</h3><p>Required master-record details</p></div></div>
                    <div class="entry-grid">
                        <label class="entry-field"><span>Employee Number *</span><input id="nmEmp" name="employee_number" required maxlength="40" placeholder="EMP-5001"></label>
                        <label class="entry-field"><span>Gender *</span><select id="nmGender" name="gender" required><option value="">Select gender</option><option value="MALE">Male</option><option value="FEMALE">Female</option><option value="OTHER">Other</option></select></label>
                        <label class="entry-field"><span>First Name (English) *</span><input id="nmFn" name="first_name_en" required maxlength="100" placeholder="Noura"></label>
                        <label class="entry-field"><span>Last Name (English) *</span><input id="nmLn" name="last_name_en" required maxlength="100" placeholder="Al-Harbi"></label>
                        <label class="entry-field"><span>First Name (Arabic)</span><input id="nmFnAr" name="first_name_ar" maxlength="100" dir="rtl"></label>
                        <label class="entry-field"><span>Last Name (Arabic)</span><input id="nmLnAr" name="last_name_ar" maxlength="100" dir="rtl"></label>
                        <label class="entry-field"><span>Date of Birth *</span><input id="nmDob" type="date" name="date_of_birth" required></label>
                        <label class="entry-field"><span>Nationality *</span><select id="nmNationality" name="nationality" required><option value="">Select country</option><option value="SA">Saudi Arabia</option><option value="PH">Philippines</option><option value="IN">India</option><option value="PK">Pakistan</option><option value="BD">Bangladesh</option><option value="EG">Egypt</option><option value="SD">Sudan</option><option value="JO">Jordan</option><option value="AE">United Arab Emirates</option><option value="GB">United Kingdom</option><option value="US">United States</option><option value="OT">Other</option></select></label>
                        <label class="entry-field"><span>ID Type *</span><select id="nmIdType" name="identification_type" required><option value="NATIONAL_ID">Saudi National ID (starts with 1)</option><option value="IQAMA">Resident Iqama (starts with 2)</option></select></label>
                        <label class="entry-field"><span>ID Number *</span><input id="nmIdNo" name="identification_number" required inputmode="numeric" pattern="[12][0-9]{9}" maxlength="10" placeholder="10 digits"></label>
                    </div>
                </div>

                <div class="entry-card">
                    <div class="entry-heading"><span>02</span><div><h3>Passport & Contact</h3><p>Travel, residence and emergency information</p></div></div>
                    <div class="entry-grid">
                        <label class="entry-field"><span>Passport Number</span><input id="nmPassport" name="passport_number" maxlength="30"></label>
                        <label class="entry-field"><span>Place of Issue</span><input id="nmPassportPlace" name="passport_place_of_issue" maxlength="120"></label>
                        <label class="entry-field"><span>Passport Issue Date</span><input id="nmPassportIssue" type="date" name="passport_issue_date"></label>
                        <label class="entry-field"><span>Passport Expiry Date</span><input id="nmPassportExpiry" type="date" name="passport_expiry_date"></label>
                        <label class="entry-field"><span>Passport Photo</span><input type="file" name="passport_photo" accept=".jpg,.jpeg,.png"></label>
                        <label class="entry-field"><span>Phone Number *</span><input id="nmPhone" type="tel" name="phone_number" required maxlength="30" placeholder="+966509988771"></label>
                        <label class="entry-field"><span>Email Address *</span><input id="nmEmail" type="email" name="email" required maxlength="190"></label>
                        <label class="entry-field entry-wide"><span>Home Address *</span><textarea id="nmAddress" name="home_address" rows="2" required></textarea></label>
                        <label class="entry-field"><span>Emergency Contact Name *</span><input id="nmEmergencyName" name="emergency_contact_name" required maxlength="200"></label>
                        <label class="entry-field"><span>Relationship *</span><input id="nmEmergencyRelation" name="emergency_contact_relation" required maxlength="100"></label>
                        <label class="entry-field"><span>Emergency Contact Phone *</span><input id="nmEmergencyPhone" type="tel" name="emergency_contact_phone" required maxlength="30"></label>
                    </div>
                </div>

                <div class="entry-card">
                    <div class="entry-heading"><span>03</span><div><h3>Professional & Educational Records</h3><p>Qualifications, licensing and work history</p></div></div>
                    <div class="entry-grid">
                        <label class="entry-field"><span>Nursing Degrees / Diplomas</span><textarea name="nursing_degrees" rows="3"></textarea></label>
                        <label class="entry-field"><span>Professional Licenses</span><textarea name="professional_licenses" rows="3"></textarea></label>
                        <label class="entry-field"><span>SCFHS Eligibility / Classification</span><textarea name="scfhs_details" rows="3"></textarea></label>
                        <label class="entry-field"><span>Employment History</span><textarea name="employment_history" rows="3"></textarea></label>
                        <label class="entry-field"><span>Academic Transcripts</span><input type="file" name="academic_transcripts" accept=".pdf,.jpg,.jpeg,.png"></label>
                        <label class="entry-field"><span>DataFlow PSV Report</span><input type="file" name="dataflow_psv" accept=".pdf,.jpg,.jpeg,.png"></label>
                        <label class="entry-field"><span>Prometric Exam Results</span><input type="file" name="prometric_results" accept=".pdf,.jpg,.jpeg,.png"></label>
                        <label class="entry-field"><span>Work Experience Certificates</span><input type="file" name="work_experience[]" accept=".pdf,.jpg,.jpeg,.png" multiple></label>
                        <label class="entry-field entry-wide"><span>Good Standing Certificates</span><input type="file" name="good_standing_certificates[]" accept=".pdf,.jpg,.jpeg,.png" multiple></label>
                    </div>
                </div>

                <div class="entry-card">
                    <div class="entry-heading"><span>04</span><div><h3>Administrative & Compliance</h3><p>Health clearance, police clearance and Mumaris+</p></div></div>
                    <div class="entry-grid">
                        <label class="entry-field"><span>Medical Fitness Certificate</span><input type="file" name="medical_fitness_cert" accept=".pdf,.jpg,.jpeg,.png"></label>
                        <label class="entry-field"><span>Communicable Disease Screening</span><input type="file" name="communicable_disease_screening" accept=".pdf,.jpg,.jpeg,.png"></label>
                        <label class="entry-field"><span>Police Clearance Certificate</span><input type="file" name="police_clearance" accept=".pdf,.jpg,.jpeg,.png"></label>
                        <label class="entry-field"><span>Mumaris+ Profile / ID</span><input name="mumaris_id" maxlength="100"></label>
                    </div>
                </div>
            </div>
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-6 py-4 border-t bg-white">
                <span class="text-slate-500">Documents: PDF, JPG or PNG · Maximum 5 MB each</span>
                <div class="flex justify-end gap-2"><button type="button" onclick="window.app.closeModal('nurseModal')" class="px-4 py-2 border rounded-xl">Cancel</button><button id="nmSubmit" type="submit" class="px-5 py-2 bg-emerald-600 text-white rounded-xl font-bold">Save Nurse</button></div>
            </div>
        </form>
    </div>

    <div id="leaveModal" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center hidden p-4">
        <div class="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl space-y-3 text-xs">
            <h3 class="font-bold text-sm">Request Statutory Leave</h3>
            <div>
                <label class="font-bold block mb-1">Type</label>
                <select id="lrType" class="w-full border rounded-lg p-2 bg-white">
                    <option value="ANNUAL">Annual Leave</option>
                    <option value="SICK">Sick Leave</option>
                    <option value="HAJJ">Hajj Leave</option>
                </select>
            </div>
            <div><label class="font-bold block mb-1">Start Date</label><input type="date" id="lrStart" class="w-full border rounded-lg p-2"></div>
            <div><label class="font-bold block mb-1">End Date</label><input type="date" id="lrEnd" class="w-full border rounded-lg p-2"></div>
            <div class="flex justify-end gap-2 pt-2 border-t">
                <!-- L8 FIX: Use closeModal() consistently -->
                <button onclick="window.app.closeModal('leaveModal')" class="px-3 py-1.5 border rounded-lg">Cancel</button>
                <button onclick="window.app.submitLeave()" class="px-3 py-1.5 bg-emerald-600 text-white rounded-lg font-bold">Submit</button>
            </div>
        </div>
    </div>

    <div id="handoverModal" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center hidden p-4">
        <div class="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl space-y-3 text-xs">
            <h3 class="font-bold text-sm">Record Shift Handover</h3>
            <div><label class="font-bold block mb-1">Handover Title</label><input type="text" id="hoTitle" placeholder="e.g. NICU Pod A Day-Night Transition" class="w-full border rounded-lg p-2"></div>
            <div><label class="font-bold block mb-1">Patient Census</label><input type="number" id="hoCensus" value="12" class="w-full border rounded-lg p-2"></div>
            <div><label class="font-bold block mb-1">SBAR Details</label><textarea id="hoContent" rows="4" class="w-full border rounded-lg p-2 font-mono" placeholder="S: Situation&#10;B: Background&#10;A: Assessment&#10;R: Recommendation"></textarea></div>
            <div class="flex justify-end gap-2 pt-2 border-t">
                <!-- L8 FIX: Use closeModal() consistently -->
                <button onclick="window.app.closeModal('handoverModal')" class="px-3 py-1.5 border rounded-lg">Cancel</button>
                <button onclick="window.app.submitHandover()" class="px-3 py-1.5 bg-indigo-600 text-white rounded-lg font-bold">Post Handover</button>
            </div>
        </div>
    </div>

    <div id="ticketModal" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center hidden p-4">
        <div class="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl space-y-3 text-xs">
            <h3 class="font-bold text-sm">Submit Hypercare Issue</h3>
            <div>
                <label class="font-bold block mb-1">Priority</label>
                <select id="tkPriority" class="w-full border rounded-lg p-2 bg-white">
                    <option value="P1_CRITICAL">P1 - Critical (Patient Care Blocker)</option>
                    <option value="P2_HIGH" selected>P2 - High (Roster Shortage)</option>
                    <option value="P3_MEDIUM">P3 - Medium (UI/Sync)</option>
                </select>
            </div>
            <div><label class="font-bold block mb-1">Title</label><input type="text" id="tkTitle" placeholder="e.g. Coverage deficit on Friday Night" class="w-full border rounded-lg p-2"></div>
            <div><label class="font-bold block mb-1">Description</label><textarea id="tkDesc" rows="3" class="w-full border rounded-lg p-2"></textarea></div>
            <div class="flex justify-end gap-2 pt-2 border-t">
                <!-- L8 FIX: Use closeModal() consistently -->
                <button onclick="window.app.closeModal('ticketModal')" class="px-3 py-1.5 border rounded-lg">Cancel</button>
                <button onclick="window.app.submitTicket()" class="px-3 py-1.5 bg-indigo-600 text-white rounded-lg font-bold">Log Ticket</button>
            </div>
        </div>
    </div>

    <!-- ── RBAC: Assign Role Modal ── -->
    <div id="rbacAssignModal" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center hidden p-4">
        <div class="bg-white rounded-2xl max-w-lg w-full shadow-2xl text-xs overflow-hidden">
            <div class="flex items-center justify-between px-5 py-4 border-b bg-slate-50">
                <h3 class="font-bold text-sm text-slate-900">Assign Role</h3>
                <button onclick="window.app.closeModal('rbacAssignModal')" class="w-8 h-8 border rounded-lg font-bold text-slate-500 hover:text-slate-900">✕</button>
            </div>
            <div class="p-5 space-y-4">
                <div>
                    <label class="font-bold block mb-1 text-slate-600 uppercase text-[11px] tracking-wide">User</label>
                    <select id="rbacAssignUser" onchange="window.app.updateRbacImpact()" class="w-full border border-slate-300 rounded-lg p-2.5 bg-white">
                        <option value="">— Select user —</option>
                    </select>
                </div>
                <div>
                    <label class="font-bold block mb-1 text-slate-600 uppercase text-[11px] tracking-wide">Role</label>
                    <select id="rbacAssignRole" onchange="window.app.updateRbacImpact()" class="w-full border border-slate-300 rounded-lg p-2.5 bg-white">
                        <option value="">— Select role —</option>
                        <option value="ADMIN">System Administrator</option>
                        <option value="MANAGER">Department Manager</option>
                        <option value="SUPERVISOR">Unit Supervisor</option>
                        <option value="STAFF_NURSE">Staff Nurse</option>
                    </select>
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="font-bold block mb-1 text-slate-600 uppercase text-[11px] tracking-wide">Scope Type</label>
                        <select id="rbacAssignScope" onchange="window.app.toggleRbacScopeId()" class="w-full border border-slate-300 rounded-lg p-2.5 bg-white">
                            <option value="global">Global (all units)</option>
                            <option value="department">Department</option>
                            <option value="unit">Unit</option>
                        </select>
                    </div>
                    <div id="rbacScopeIdGroup">
                        <label class="font-bold block mb-1 text-slate-600 uppercase text-[11px] tracking-wide">Scope Target</label>
                        <select id="rbacAssignScopeId" class="w-full border border-slate-300 rounded-lg p-2.5 bg-white">
                            <!-- Dynamically populated from unit selector -->
                        </select>
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="font-bold block mb-1 text-slate-600 uppercase text-[11px] tracking-wide">Effective From</label>
                        <input type="date" id="rbacAssignFrom" class="w-full border border-slate-300 rounded-lg p-2.5">
                    </div>
                    <div>
                        <label class="font-bold block mb-1 text-slate-600 uppercase text-[11px] tracking-wide">Effective To (optional)</label>
                        <input type="date" id="rbacAssignTo" class="w-full border border-slate-300 rounded-lg p-2.5">
                    </div>
                </div>
                <div>
                    <label class="font-bold block mb-1 text-slate-600 uppercase text-[11px] tracking-wide">Reason / Justification</label>
                    <input type="text" id="rbacAssignReason" placeholder="e.g. Promoted to Supervisor per HR approval #2024-05" class="w-full border border-slate-300 rounded-lg p-2.5">
                </div>

                <!-- Impact panel -->
                <div id="rbacImpactPanel" class="hidden bg-slate-50 border border-slate-200 rounded-lg p-3">
                    <strong class="text-xs text-slate-700" id="rbacImpactTitle">Role Impact Preview</strong>
                    <div id="rbacImpactPerms" class="flex flex-wrap gap-1 mt-2"></div>
                </div>
            </div>
            <div class="flex justify-end gap-2 px-5 py-3 border-t">
                <button onclick="window.app.closeModal('rbacAssignModal')" class="px-4 py-2 border rounded-xl font-semibold">Cancel</button>
                <button onclick="window.app.submitRbacAssign()" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold">Assign Role</button>
            </div>
        </div>
    </div>

    <!-- ── RBAC: Create User Modal ── -->
    <div id="rbacCreateUserModal" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center hidden p-4">
        <div class="bg-white rounded-2xl max-w-lg w-full shadow-2xl text-xs overflow-hidden">
            <div class="flex items-center justify-between px-5 py-4 border-b bg-slate-50">
                <h3 class="font-bold text-sm text-slate-900">Add User</h3>
                <button onclick="window.app.closeModal('rbacCreateUserModal')" class="w-8 h-8 border rounded-lg font-bold text-slate-500 hover:text-slate-900">✕</button>
            </div>
            <div class="p-5 space-y-4">
                <div>
                    <label class="font-bold block mb-1 text-slate-600 uppercase text-[11px] tracking-wide">Email</label>
                    <input type="email" id="rbacCreateEmail" class="w-full border border-slate-300 rounded-lg p-2.5" placeholder="user@hospital.sa" autocomplete="off">
                </div>
                <div>
                    <label class="font-bold block mb-1 text-slate-600 uppercase text-[11px] tracking-wide">Password</label>
                    <input type="password" id="rbacCreatePassword" class="w-full border border-slate-300 rounded-lg p-2.5" placeholder="Min. 8 characters" autocomplete="new-password">
                </div>
                <div>
                    <label class="font-bold block mb-1 text-slate-600 uppercase text-[11px] tracking-wide">Initial Role (optional)</label>
                    <select id="rbacCreateRole" class="w-full border border-slate-300 rounded-lg p-2.5 bg-white">
                        <option value="">— No role yet —</option>
                        <option value="ADMIN">System Administrator</option>
                        <option value="MANAGER">Department Manager</option>
                        <option value="SUPERVISOR">Unit Supervisor</option>
                        <option value="STAFF_NURSE">Staff Nurse</option>
                    </select>
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="font-bold block mb-1 text-slate-600 uppercase text-[11px] tracking-wide">Scope Type</label>
                        <select id="rbacCreateScope" onchange="window.app.toggleRbacCreateScopeId()" class="w-full border border-slate-300 rounded-lg p-2.5 bg-white">
                            <option value="global">Global</option>
                            <option value="department">Department</option>
                            <option value="unit">Unit</option>
                        </select>
                    </div>
                    <div id="rbacCreateScopeIdGroup" style="display:none">
                        <label class="font-bold block mb-1 text-slate-600 uppercase text-[11px] tracking-wide">Scope Target</label>
                        <select id="rbacCreateScopeId" class="w-full border border-slate-300 rounded-lg p-2.5 bg-white"></select>
                    </div>
                </div>
                <div>
                    <label class="font-bold block mb-1 text-slate-600 uppercase text-[11px] tracking-wide">Reason</label>
                    <input type="text" id="rbacCreateReason" class="w-full border border-slate-300 rounded-lg p-2.5" placeholder="Created via Access Matrix">
                </div>
            </div>
            <div class="flex justify-end gap-2 px-5 py-3 border-t">
                <button onclick="window.app.closeModal('rbacCreateUserModal')" class="px-4 py-2 border rounded-xl font-semibold">Cancel</button>
                <button onclick="window.app.submitRbacCreateUser()" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold">Create User</button>
            </div>
        </div>
    </div>

    <!-- Client-Side Controller Bundle -->
    <script src="public/js/app.js"></script>
</body>
</html>
