<?php
// index.php - Front Controller & Router  (RBAC-enabled, v2.0)
// ─────────────────────────────────────────────────────────────────────────────
// Session bootstrap (secure cookie flags)
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => isset($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_start();
}

// CSRF token generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ─────────────────────────────────────────────────────────────────────────────
// PSR-4 Autoloader  (Config\, Models\, Controllers\, Middleware\)
spl_autoload_register(function (string $class): void {
    $prefixMap = [
        'Config\\'      => __DIR__ . '/config/',
        'Models\\'      => __DIR__ . '/models/',
        'Controllers\\' => __DIR__ . '/controllers/',
        'Middleware\\'  => __DIR__ . '/middleware/',
    ];
    foreach ($prefixMap as $prefix => $baseDir) {
        if (str_starts_with($class, $prefix)) {
            $file = $baseDir . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
            if (file_exists($file)) { require $file; return; }
        }
    }
});

use Controllers\NurseController;
use Controllers\ShiftController;
use Controllers\LeaveController;
use Controllers\OperationsController;
use Controllers\DepartmentController;
use Controllers\AuthController;
use Controllers\RbacController;
use Middleware\AuthMiddleware;
use Config\Rbac;

// Demo / role-switch helper. MUST remain false in production.
// When true, an already-authenticated Admin (config.manage) may temporarily
// assume another role for UI walkthroughs. Never grants a session from zero.
if (!defined('APP_DEMO_MODE')) {
    define('APP_DEMO_MODE', false);
}

$action = $_GET['action'] ?? null;

// ─────────────────────────────────────────────────────────────────────────────
// NO ACTION → Serve the SPA or login page
if (!$action) {
    $userId = $_SESSION['user_id'] ?? null;
    $role   = $_SESSION['user_role'] ?? $_SESSION['role'] ?? null;

    // If not authenticated → serve login page
    if (!$userId || !$role) {
        require __DIR__ . '/views/login.php';
        exit;
    }
    // Authenticated → serve dashboard
    require __DIR__ . '/views/dashboard.php';
    exit;
}

// ─────────────────────────────────────────────────────────────────────────────
// All API responses are JSON
header('Content-Type: application/json; charset=utf-8');

// ─────────────────────────────────────────────────────────────────────────────
// PUBLIC ACTIONS (no auth required)
$publicActions = ['login', 'logout'];
if (in_array($action, $publicActions, true)) {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];

    // R-SEC-1: Login / logout are public but still need CSRF-like protection.
    // Since the login page may not have a session-scoped CSRF token when the
    // session is new, we validate the Origin / Referer header to block cross-site
    // login forgery. The CSRF token header is also accepted when present (logout).
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $csrfHeader = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        $tokenOk    = $csrfHeader && hash_equals($_SESSION['csrf_token'] ?? '', $csrfHeader);

        if (!$tokenOk) {
            // Fallback: verify Origin / Referer matches our own host
            $origin  = $_SERVER['HTTP_ORIGIN'] ?? '';
            $referer = $_SERVER['HTTP_REFERER'] ?? '';
            $host    = $_SERVER['HTTP_HOST'] ?? '';
            $ownOrigin = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $host;

            $originOk  = $origin  && str_starts_with($origin,  $ownOrigin);
            $refererOk = $referer && str_starts_with($referer, $ownOrigin);

            if (!$originOk && !$refererOk) {
                http_response_code(403);
                echo json_encode(['error' => 'Cross-origin request blocked. Please use the login page.']);
                exit;
            }
        }
    }

    switch ($action) {
        case 'login':
            (new AuthController())->login($input);
            break;
        case 'logout':
            (new AuthController())->logout();
            break;
    }
    exit;
}

// ─────────────────────────────────────────────────────────────────────────────
// CSRF check for all POST requests to protected endpoints
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrfHeader = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $csrfHeader)) {
        http_response_code(403);
        echo json_encode(['error' => 'CSRF token validation failed. Please refresh the page.']);
        exit;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Session compatibility shim
// Support both old (user_id + role) and new (user_id + user_role) session keys
if (!empty($_SESSION['user_id']) && empty($_SESSION['user_role']) && !empty($_SESSION['role'])) {
    $_SESSION['user_role'] = Rbac::normalise($_SESSION['role']);
}
if (!empty($_SESSION['user_id']) && !empty($_SESSION['user_role']) && empty($_SESSION['role'])) {
    $_SESSION['role'] = $_SESSION['user_role'];
}

// R1 FIX: Removed unauthenticated switch_user session-minter that sat ABOVE
// requireAuth(). Anyone who could reach the URL previously received a full
// authenticated session with no password. Role switching (if needed for demos)
// is now registered only AFTER requireAuth() and is gated by APP_DEMO_MODE +
// config.manage permission — see case 'switch_user' below.

// All remaining actions require an authenticated session
AuthMiddleware::requireAuth();

$currentUser = AuthMiddleware::currentUser();
$currentRole = AuthMiddleware::currentRole();
$input       = json_decode(file_get_contents('php://input'), true) ?? [];

// ─────────────────────────────────────────────────────────────────────────────
// CONTROLLER ROUTING
switch ($action) {

    // ── Auth / Session ────────────────────────────────────────────────────────
    case 'me':
        (new AuthController())->me();
        break;

    // R1 FIX: Demo-only role switch — only reachable after requireAuth().
    // Requires APP_DEMO_MODE=true AND config.manage (ADMIN). Does not mint a
    // session from zero; only rewrites role on an existing authenticated user.
    case 'switch_user':
        if (!APP_DEMO_MODE) {
            http_response_code(403);
            echo json_encode(['error' => 'Role switching is disabled outside demo mode.']);
            break;
        }
        AuthMiddleware::requirePermission('config', 'manage');
        $demoInput = $input;
        $allowedRoles = [Rbac::ADMIN, Rbac::MANAGER, Rbac::SUPERVISOR, Rbac::STAFF_NURSE,
                         'HEAD_NURSE', 'STAFF_NURSE'];
        $role = $demoInput['role'] ?? Rbac::SUPERVISOR;
        if (!in_array($role, $allowedRoles, true)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid role.']);
            break;
        }
        $canonical = Rbac::normalise($role);
        // Keep the real authenticated user_id; only change the effective role.
        $_SESSION['user_role'] = $canonical;
        $_SESSION['role']      = $canonical;
        echo json_encode([
            'status'      => 'success',
            'role'        => $canonical,
            'permissions' => Rbac::permissionsFor($canonical),
            'demo'        => true,
        ]);
        break;

    // ── RBAC / Access Matrix ──────────────────────────────────────────────────
    case 'rbac_list_users':
        (new RbacController())->listUsers();
        break;
    case 'rbac_list_roles':
        (new RbacController())->listRoles();
        break;
    case 'rbac_list_permissions':
        (new RbacController())->listPermissions();
        break;
    case 'rbac_assign_role':
        (new RbacController())->assignRole($input);
        break;
    case 'rbac_bulk_assign':
        (new RbacController())->bulkAssign($input);
        break;
    case 'rbac_revoke_role':
        (new RbacController())->revokeRole($input);
        break;
    case 'rbac_create_user':
        (new RbacController())->createUser($input);
        break;
    case 'rbac_update_user':
        (new RbacController())->updateUser($input);
        break;
    case 'rbac_delete_user':
        (new RbacController())->deleteUser($input);
        break;
    case 'rbac_audit_log':
        (new RbacController())->auditLog();
        break;
    case 'rbac_role_impact':
        (new RbacController())->roleImpact();
        break;
    case 'rbac_export_csv':
        (new RbacController())->exportCsv();
        break;

    // ── Department Controller ─────────────────────────────────────────────────
    case 'get_departments':
        AuthMiddleware::requirePermission('departments', 'read');
        (new DepartmentController())->index();
        break;
    case 'get_sub_units':
        AuthMiddleware::requirePermission('departments', 'read');
        (new DepartmentController())->subUnits();
        break;
    case 'save_department':
        AuthMiddleware::requirePermission('departments', 'create');
        (new DepartmentController())->saveDept($input, $currentRole);
        break;
    case 'save_sub_unit':
        AuthMiddleware::requirePermission('departments', 'update');
        (new DepartmentController())->saveSubUnit($input, $currentRole);
        break;
    case 'delete_department':
        AuthMiddleware::requirePermission('departments', 'delete');
        (new DepartmentController())->deleteDept($input, $currentRole);
        break;
    case 'delete_sub_unit':
        AuthMiddleware::requirePermission('departments', 'delete');
        (new DepartmentController())->deleteSubUnit($input, $currentRole);
        break;

    // ── Nurse Controller ──────────────────────────────────────────────────────
    case 'get_nurses':
        AuthMiddleware::requirePermission('nurses', 'read');
        (new NurseController())->index();
        break;
    // R5 FIX: frontend posts action=save_nurse_profile (documents on form);
    // keep legacy save_nurse as an alias so older callers still work.
    // The form uses multipart/form-data (file uploads), so read $_POST instead of
    // the JSON body — $input is empty for multipart requests.
    case 'save_nurse':
    case 'save_nurse_profile':
        AuthMiddleware::requirePermission('nurses', 'create');
        $nurseInput = !empty($_POST) ? array_merge($input, $_POST) : $input;
        (new NurseController())->save($nurseInput, $currentRole);
        break;

    // ── Shift Controller ──────────────────────────────────────────────────────
    case 'get_shifts_matrix':
        AuthMiddleware::requirePermission('shifts', 'read');
        (new ShiftController())->matrix($_GET);
        break;
    case 'save_shift_cell':
        AuthMiddleware::requirePermission('shifts', 'update');
        (new ShiftController())->assign($input, $currentRole);
        break;
    case 'publish_unit_schedule':
        AuthMiddleware::requirePermission('shifts', 'publish');
        (new ShiftController())->publish($input, $currentRole);
        break;
    case 'claim_open_shift':
        AuthMiddleware::requirePermission('shifts', 'claim_open');
        (new ShiftController())->claim($input, $currentUser);
        break;

    // ── Leave Controller ──────────────────────────────────────────────────────
    case 'get_leaves':
        AuthMiddleware::requirePermission('leaves', 'read');
        (new LeaveController())->index();
        break;
    case 'submit_leave':
        AuthMiddleware::requirePermission('leaves', 'submit');
        (new LeaveController())->submit($input, $currentUser);
        break;
    case 'decide_leave':
        AuthMiddleware::requirePermission('leaves', 'approve');
        (new LeaveController())->decide($input, $currentUser, $currentRole);
        break;

    // ── Operations & Telemetry ────────────────────────────────────────────────
    case 'get_channel_messages':
        AuthMiddleware::requirePermission('handovers', 'read');
        (new OperationsController())->handovers($_GET['unit_id'] ?? 'u-nicu');
        break;
    case 'post_channel_message':
        AuthMiddleware::requirePermission('handovers', 'post');
        (new OperationsController())->submitHandover($input, $currentUser, $currentRole);
        break;
    case 'get_rollout_data':
        AuthMiddleware::requirePermission('reports', 'view');
        (new OperationsController())->rollout();
        break;
    case 'create_hypercare_ticket':
        AuthMiddleware::requirePermission('tickets', 'create');
        (new OperationsController())->createTicket($input, $currentUser);
        break;
    case 'resolve_hypercare_ticket':
        AuthMiddleware::requirePermission('tickets', 'resolve');
        (new OperationsController())->resolveTicket($input);
        break;
    case 'get_stage7_analytics':
        AuthMiddleware::requirePermission('reports', 'view');
        (new OperationsController())->analytics();
        break;
    case 'run_data_drift_scan':
        AuthMiddleware::requirePermission('reports', 'view');
        (new OperationsController())->drift();
        break;
    case 'run_automated_sweep':
        AuthMiddleware::requirePermission('config', 'manage');
        (new OperationsController())->sweep();
        break;
    case 'submit_feedback':
        AuthMiddleware::requirePermission('feedback', 'submit');
        (new OperationsController())->submitFeedback($input, $currentUser, $currentRole);
        break;
    case 'upvote_backlog':
        AuthMiddleware::requirePermission('feedback', 'submit');
        (new OperationsController())->upvoteBacklog($input);
        break;
    case 'get_notifications':
        AuthMiddleware::requirePermission('notifications', 'read');
        (new OperationsController())->getNotifications($currentUser);
        break;

    default:
        http_response_code(404);
        echo json_encode(['error' => 'Action route not found.']);
        break;
}
