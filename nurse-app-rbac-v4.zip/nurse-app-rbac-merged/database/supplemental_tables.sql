-- =============================================================================
-- AIGH Nursing Management System – Supplemental Tables Migration
-- Version  : 1.0.0
-- Run after: database/rbac_migration.sql
-- Command  : mysql -u root nurse_scheduling < database/supplemental_tables.sql
-- =============================================================================

SET NAMES utf8mb4;
SET foreign_key_checks = 0;

-- ─────────────────────────────────────────────────────────────────────────────
-- DEPARTMENTS
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `departments` (
    `dept_id`       VARCHAR(36)   NOT NULL,
    `dept_code`     VARCHAR(20)   NOT NULL UNIQUE,
    `dept_name_en`  VARCHAR(100)  NOT NULL,
    `dept_name_ar`  VARCHAR(100)  NOT NULL DEFAULT '',
    `is_active`     TINYINT(1)    NOT NULL DEFAULT 1,
    `created_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────────────────────
-- SUB-UNITS  (wards / clinical units within a department)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `sub_units` (
    `unit_id`       VARCHAR(36)   NOT NULL,
    `dept_id`       VARCHAR(36)   NOT NULL,
    `unit_code`     VARCHAR(20)   NOT NULL UNIQUE,
    `unit_name_en`  VARCHAR(100)  NOT NULL,
    `unit_name_ar`  VARCHAR(100)  NOT NULL DEFAULT '',
    `bed_count`     SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    `is_active`     TINYINT(1)    NOT NULL DEFAULT 1,
    `created_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`unit_id`),
    FOREIGN KEY (`dept_id`) REFERENCES `departments`(`dept_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────────────────────
-- NURSES  (clinical staff master record)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `nurses` (
    `nurse_id`        VARCHAR(36)   NOT NULL,
    `user_id`         VARCHAR(36)   DEFAULT NULL,   -- FK to users; NULL if no system account
    `employee_id`     VARCHAR(30)   NOT NULL UNIQUE,
    `full_name_en`    VARCHAR(100)  NOT NULL,
    `full_name_ar`    VARCHAR(100)  NOT NULL DEFAULT '',
    `nationality`     VARCHAR(50)   DEFAULT NULL,
    `gender`          ENUM('M','F','U') NOT NULL DEFAULT 'U',
    `phone`           VARCHAR(20)   DEFAULT NULL,
    `email`           VARCHAR(255)  DEFAULT NULL,
    `job_title`       VARCHAR(100)  DEFAULT NULL,
    `specialisation`  VARCHAR(100)  DEFAULT NULL,
    `unit_id`         VARCHAR(36)   DEFAULT NULL,   -- current unit assignment
    `license_number`  VARCHAR(50)   DEFAULT NULL,
    `license_expiry`  DATE          DEFAULT NULL,
    `contract_start`  DATE          DEFAULT NULL,
    `contract_end`    DATE          DEFAULT NULL,
    `employment_type` ENUM('FULL_TIME','PART_TIME','LOCUM','AGENCY') NOT NULL DEFAULT 'FULL_TIME',
    `is_active`       TINYINT(1)    NOT NULL DEFAULT 1,
    `created_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`nurse_id`),
    KEY `idx_nurses_unit`    (`unit_id`),
    KEY `idx_nurses_license` (`license_expiry`),
    KEY `idx_nurses_contract`(`contract_end`),
    FOREIGN KEY (`unit_id`) REFERENCES `sub_units`(`unit_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────────────────────
-- SHIFTS  (individual shift cell assignments)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `shifts` (
    `shift_id`    VARCHAR(36)   NOT NULL,
    `unit_id`     VARCHAR(36)   NOT NULL,
    `nurse_id`    VARCHAR(36)   DEFAULT NULL,   -- NULL = open shift
    `shift_date`  DATE          NOT NULL,
    `shift_code`  ENUM('M','A','N','OFF','AL','SL','H','') NOT NULL DEFAULT '',
    -- M=Morning  A=Afternoon  N=Night  OFF=Day-off  AL=Annual-leave
    -- SL=Sick-leave  H=Holiday  ''=Unassigned
    `is_open`     TINYINT(1)    NOT NULL DEFAULT 0,  -- 1 = claimable by staff
    `notes`       VARCHAR(500)  DEFAULT NULL,
    `created_by`  VARCHAR(36)   DEFAULT NULL,
    `updated_by`  VARCHAR(36)   DEFAULT NULL,
    `created_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`shift_id`),
    UNIQUE KEY `uq_shift_cell` (`unit_id`, `nurse_id`, `shift_date`),
    KEY `idx_shifts_date`  (`shift_date`),
    KEY `idx_shifts_nurse` (`nurse_id`),
    FOREIGN KEY (`unit_id`)  REFERENCES `sub_units`(`unit_id`) ON DELETE CASCADE,
    FOREIGN KEY (`nurse_id`) REFERENCES `nurses`(`nurse_id`)   ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────────────────────
-- SHIFT_PUBLISHES  (tracks which unit/month schedules have been published)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `shift_publishes` (
    `pub_id`        VARCHAR(36)   NOT NULL,
    `unit_id`       VARCHAR(36)   NOT NULL,
    `pub_year`      SMALLINT UNSIGNED NOT NULL,
    `pub_month`     TINYINT UNSIGNED  NOT NULL,
    `published_by`  VARCHAR(36)   NOT NULL,
    `published_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`pub_id`),
    UNIQUE KEY `uq_pub` (`unit_id`, `pub_year`, `pub_month`),
    FOREIGN KEY (`unit_id`) REFERENCES `sub_units`(`unit_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────────────────────
-- LEAVES  (leave requests and decisions)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `leaves` (
    `leave_id`      VARCHAR(36)   NOT NULL,
    `nurse_id`      VARCHAR(36)   NOT NULL,
    `leave_type`    ENUM('ANNUAL','SICK','EMERGENCY','MATERNITY','PATERNITY','UNPAID','STUDY')
                                  NOT NULL DEFAULT 'ANNUAL',
    `start_date`    DATE          NOT NULL,
    `end_date`      DATE          NOT NULL,
    `reason`        VARCHAR(1000) DEFAULT NULL,
    `status`        ENUM('PENDING','APPROVED','REJECTED','CANCELLED')
                                  NOT NULL DEFAULT 'PENDING',
    `decided_by`    VARCHAR(36)   DEFAULT NULL,
    `decision_note` VARCHAR(500)  DEFAULT NULL,
    `created_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`leave_id`),
    KEY `idx_leaves_nurse`  (`nurse_id`, `status`),
    KEY `idx_leaves_date`   (`start_date`),
    FOREIGN KEY (`nurse_id`) REFERENCES `nurses`(`nurse_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────────────────────
-- HANDOVER_MESSAGES  (SBAR shift handovers per unit)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `handover_messages` (
    `handover_id`    VARCHAR(36)   NOT NULL,
    `unit_id`        VARCHAR(36)   NOT NULL,
    `shift_type`     ENUM('M','A','N') NOT NULL DEFAULT 'M',
    `author_id`      VARCHAR(36)   NOT NULL,
    `patient_count`  SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    `critical_alerts` VARCHAR(2000) DEFAULT NULL,
    `pending_tasks`   VARCHAR(2000) DEFAULT NULL,
    `message_body`    TEXT          NOT NULL,
    `created_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`handover_id`),
    KEY `idx_hv_unit_date` (`unit_id`, `created_at`),
    FOREIGN KEY (`unit_id`)   REFERENCES `sub_units`(`unit_id`) ON DELETE CASCADE,
    FOREIGN KEY (`author_id`) REFERENCES `users`(`user_id`)     ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────────────────────
-- HYPERCARE_TICKETS  (support / issue tickets)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `hypercare_tickets` (
    `ticket_id`       VARCHAR(36)   NOT NULL,
    `title`           VARCHAR(200)  NOT NULL,
    `description`     TEXT          NOT NULL,
    `priority`        ENUM('LOW','MEDIUM','HIGH','CRITICAL') NOT NULL DEFAULT 'MEDIUM',
    `unit_id`         VARCHAR(36)   DEFAULT NULL,
    `status`          ENUM('OPEN','IN_PROGRESS','RESOLVED','CLOSED') NOT NULL DEFAULT 'OPEN',
    `created_by`      VARCHAR(36)   NOT NULL,
    `resolved_by`     VARCHAR(36)   DEFAULT NULL,
    `resolution_note` VARCHAR(2000) DEFAULT NULL,
    `resolved_at`     DATETIME      DEFAULT NULL,
    `created_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`ticket_id`),
    KEY `idx_tickets_status`   (`status`, `priority`),
    KEY `idx_tickets_unit`     (`unit_id`),
    FOREIGN KEY (`created_by`)  REFERENCES `users`(`user_id`) ON DELETE RESTRICT,
    FOREIGN KEY (`resolved_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────────────────────
-- FEEDBACK  (general user feedback / bug reports)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `feedback` (
    `feedback_id`   VARCHAR(36)   NOT NULL,
    `category`      ENUM('GENERAL','BUG','FEATURE','UX','PERFORMANCE','OTHER')
                                  NOT NULL DEFAULT 'GENERAL',
    `feedback_text` TEXT          NOT NULL,
    `submitted_by`  VARCHAR(36)   DEFAULT NULL,
    `role`          VARCHAR(50)   DEFAULT NULL,
    `created_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`feedback_id`),
    KEY `idx_feedback_cat` (`category`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────────────────────
-- BACKLOG_ITEMS  (product backlog for roadmap voting)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `backlog_items` (
    `item_id`    VARCHAR(36)   NOT NULL,
    `title`      VARCHAR(200)  NOT NULL,
    `description` TEXT         DEFAULT NULL,
    `status`     ENUM('OPEN','IN_PROGRESS','DONE','REJECTED') NOT NULL DEFAULT 'OPEN',
    `vote_count` INT UNSIGNED  NOT NULL DEFAULT 0,
    `created_at` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `backlog_votes` (
    `item_id`  VARCHAR(36) NOT NULL,
    `user_id`  VARCHAR(36) NOT NULL,
    `voted_at` DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`item_id`, `user_id`),
    FOREIGN KEY (`item_id`) REFERENCES `backlog_items`(`item_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────────────────────
-- NOTIFICATIONS  (per-user in-app alerts)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `notifications` (
    `notif_id`    VARCHAR(36)   NOT NULL,
    `user_id`     VARCHAR(36)   NOT NULL,
    `notif_type`  VARCHAR(40)   NOT NULL,        -- e.g. LEAVE_APPROVED, LICENSE_EXPIRING
    `title`       VARCHAR(200)  NOT NULL,
    `body`        VARCHAR(1000) DEFAULT NULL,
    `link_action` VARCHAR(100)  DEFAULT NULL,    -- JS action to trigger on click
    `is_read`     TINYINT(1)    NOT NULL DEFAULT 0,
    `created_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`notif_id`),
    KEY `idx_notif_user` (`user_id`, `is_read`, `created_at`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────────────────────
-- SEED PILOT DATA (3 departments, 3 units)
-- ─────────────────────────────────────────────────────────────────────────────
INSERT IGNORE INTO `departments` (`dept_id`, `dept_code`, `dept_name_en`, `dept_name_ar`) VALUES
('dept-icu-001',  'ICU',     'Intensive Care',         'العناية المركزة'),
('dept-emr-001',  'EMERG',   'Emergency',              'الطوارئ'),
('dept-mat-001',  'MATERN',  'Maternity & Neonatal',   'الولادة وحديثي الولادة');

INSERT IGNORE INTO `sub_units` (`unit_id`, `dept_id`, `unit_code`, `unit_name_en`, `unit_name_ar`, `bed_count`) VALUES
('u-micu-001', 'dept-icu-001', 'MICU', 'Medical ICU',         'وحدة العناية المركزة الطبية',    20),
('u-er-001',   'dept-emr-001', 'ER',   'Emergency Room',      'غرفة الطوارئ',                   30),
('u-nicu-001', 'dept-mat-001', 'NICU', 'Neonatal ICU',        'وحدة عناية حديثي الولادة',       16);

-- Update user_roles scope_id references to use the new unit IDs where the old 'u-nicu' placeholder was used
-- (No-op if column is already NULL or different values exist)

SET foreign_key_checks = 1;

-- =============================================================================
-- SUPPLEMENTAL MIGRATION COMPLETE
-- Tables created: departments, sub_units, nurses, shifts, shift_publishes,
--                 leaves, handover_messages, hypercare_tickets,
--                 feedback, backlog_items, backlog_votes, notifications
-- Pilot units:    MICU (u-micu-001), ER (u-er-001), NICU (u-nicu-001)
-- =============================================================================
