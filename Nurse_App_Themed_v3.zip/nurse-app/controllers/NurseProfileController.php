<?php
namespace Controllers;

use Models\NurseProfile;
use Models\Nurse;
use Config\Database;
use PDOException;

class NurseProfileController {
    private NurseProfile $model;
    private Nurse $nurseModel;
    private const MAX_FILE_SIZE = 5242880;
    private const FILE_FIELDS = [
        'passport_photo' => 'PASSPORT_PHOTO',
        'academic_transcripts' => 'ACADEMIC_TRANSCRIPT',
        'dataflow_psv' => 'DATAFLOW_PSV',
        'prometric_results' => 'PROMETRIC_RESULT',
        'work_experience' => 'WORK_EXPERIENCE',
        'good_standing_certificates' => 'GOOD_STANDING',
        'medical_fitness_cert' => 'MEDICAL_FITNESS',
        'communicable_disease_screening' => 'DISEASE_SCREENING',
        'police_clearance' => 'POLICE_CLEARANCE'
    ];

    public function __construct() {
        $this->model = new NurseProfile();
        $this->nurseModel = new Nurse();
    }

    public function index(string $role): void {
        if ($role !== 'HEAD_NURSE') {
            http_response_code(403);
            echo json_encode(['error' => 'Permission denied: Nurse onboarding records are restricted.']);
            return;
        }
        echo json_encode($this->model->getAll());
    }

    public function save(array $input, array $files, string $userId, string $role): void {
        if ($role !== 'HEAD_NURSE') {
            http_response_code(403);
            echo json_encode(['error' => 'Permission denied: Only Head Nurses can create onboarding records.']);
            return;
        }

        $required = ['employee_number', 'first_name_en', 'last_name_en', 'gender', 'date_of_birth', 'nationality', 'identification_type',
            'identification_number', 'home_address', 'phone_number', 'email',
            'emergency_contact_name', 'emergency_contact_relation', 'emergency_contact_phone', 'primary_unit_id'];
        foreach ($required as $field) {
            if (trim((string)($input[$field] ?? '')) === '') {
                http_response_code(422);
                echo json_encode(['error' => "Validation Error: {$field} is required."]);
                return;
            }
        }

        if (!in_array($input['gender'], ['MALE', 'FEMALE', 'OTHER'], true) ||
            !in_array($input['identification_type'], ['NATIONAL_ID', 'IQAMA'], true)) {
            http_response_code(422);
            echo json_encode(['error' => 'Validation Error: Invalid gender or identification type.']);
            return;
        }
        $prefix = $input['identification_type'] === 'NATIONAL_ID' ? '1' : '2';
        if (!preg_match('/^' . $prefix . '[0-9]{9}$/', $input['identification_number'])) {
            http_response_code(422);
            echo json_encode(['error' => 'Validation Error: Saudi ID must contain 10 digits with the correct prefix.']);
            return;
        }
        if (!filter_var($input['email'], FILTER_VALIDATE_EMAIL) || !$this->validDate($input['date_of_birth'])) {
            http_response_code(422);
            echo json_encode(['error' => 'Validation Error: Enter a valid email address and date of birth.']);
            return;
        }
        foreach (['passport_issue_date', 'passport_expiry_date'] as $dateField) {
            if (!empty($input[$dateField]) && !$this->validDate($input[$dateField])) {
                http_response_code(422);
                echo json_encode(['error' => "Validation Error: Invalid {$dateField}."]);
                return;
            }
        }
        if (!empty($input['passport_issue_date']) && !empty($input['passport_expiry_date']) &&
            $input['passport_expiry_date'] < $input['passport_issue_date']) {
            http_response_code(422);
            echo json_encode(['error' => 'Validation Error: Passport expiry cannot be before its issue date.']);
            return;
        }

        $uploadDir = dirname(__DIR__) . '/storage/nurse_documents';
        if (!is_dir($uploadDir) && !mkdir($uploadDir, 0750, true)) {
            http_response_code(500);
            echo json_encode(['error' => 'Upload storage is not available.']);
            return;
        }

        $stored = [];
        try {
            foreach (self::FILE_FIELDS as $field => $type) {
                foreach ($this->normalizeFiles($files[$field] ?? null) as $file) {
                    if ($file['error'] === UPLOAD_ERR_NO_FILE) continue;
                    if ($file['error'] !== UPLOAD_ERR_OK || $file['size'] > self::MAX_FILE_SIZE) {
                        throw new \RuntimeException('Each document must upload successfully and be 5 MB or smaller.');
                    }
                    $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
                    $extensions = ['application/pdf' => 'pdf', 'image/jpeg' => 'jpg', 'image/png' => 'png'];
                    if (!isset($extensions[$mime])) throw new \RuntimeException('Only PDF, JPG and PNG documents are allowed.');
                    $storedName = bin2hex(random_bytes(20)) . '.' . $extensions[$mime];
                    if (!move_uploaded_file($file['tmp_name'], $uploadDir . '/' . $storedName)) {
                        throw new \RuntimeException('A document could not be stored.');
                    }
                    $stored[] = ['document_type' => $type, 'original_name' => basename($file['name']),
                        'stored_name' => $storedName, 'mime_type' => $mime, 'file_size' => (int)$file['size']];
                }
            }

            $data = [];
            foreach (['employee_number','primary_unit_id','first_name_en','last_name_en','first_name_ar','last_name_ar',
                'gender','date_of_birth','nationality','identification_type',
                'identification_number','passport_number','passport_issue_date','passport_expiry_date',
                'passport_place_of_issue','home_address','phone_number','email','emergency_contact_name',
                'emergency_contact_relation','emergency_contact_phone','nursing_degrees','professional_licenses',
                'scfhs_details','employment_history','mumaris_id'] as $field) {
                $data[$field] = trim((string)($input[$field] ?? '')) ?: null;
            }
            $data['first_name_ar'] = $data['first_name_ar'] ?: $data['first_name_en'];
            $data['last_name_ar'] = $data['last_name_ar'] ?: $data['last_name_en'];
            $data['full_name'] = trim($data['first_name_en'] . ' ' . $data['last_name_en']);
            $data['created_by_user_id'] = $userId;
            $db = Database::getConnection();
            $db->beginTransaction();
            try {
                $nurseId = $this->nurseModel->create($data);
                $profileId = $this->model->create($nurseId, $data, $stored);
                $db->commit();
            } catch (\Throwable $e) {
                if ($db->inTransaction()) $db->rollBack();
                throw $e;
            }
            echo json_encode(['status' => 'success', 'nurse_id' => $nurseId, 'profile_id' => $profileId, 'documents' => count($stored)]);
        } catch (\Throwable $e) {
            foreach ($stored as $doc) @unlink($uploadDir . '/' . $doc['stored_name']);
            http_response_code($e instanceof PDOException && $e->getCode() === '23000' ? 409 : 422);
            echo json_encode(['error' => $e instanceof PDOException ? 'This ID number or email already exists.' : $e->getMessage()]);
        }
    }

    private function validDate(string $value): bool {
        $date = \DateTime::createFromFormat('Y-m-d', $value);
        return $date && $date->format('Y-m-d') === $value;
    }

    private function normalizeFiles(?array $file): array {
        if (!$file) return [];
        if (!is_array($file['name'])) return [$file];
        $result = [];
        foreach ($file['name'] as $i => $name) {
            $result[] = ['name' => $name, 'type' => $file['type'][$i], 'tmp_name' => $file['tmp_name'][$i],
                'error' => $file['error'][$i], 'size' => $file['size'][$i]];
        }
        return $result;
    }
}
