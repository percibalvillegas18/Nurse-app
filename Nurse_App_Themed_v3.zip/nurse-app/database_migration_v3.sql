-- Run this once only if database_migration_v2.sql was already imported
-- from Nurse_App_Themed_v2 before upgrading to v3.
ALTER TABLE nurse_profiles
    ADD COLUMN nurse_id VARCHAR(67) NULL AFTER profile_id,
    ADD UNIQUE INDEX uq_nurse_profiles_nurse_id (nurse_id);
