<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AIGH Nursing Management</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <!-- L7 FIX: Removed Segoe+UI from Google Fonts (proprietary Microsoft font, not hosted on Google Fonts) -->
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="public/css/aigh-theme.css">
    <!-- C3 FIX: CSRF token for all POST requests -->
    <meta name="csrf-token" content="<?php echo htmlspecialchars($_SESSION['csrf_token'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
    <style>
        body { font-family: 'Segoe UI', system-ui, sans-serif; }
        [dir="rtl"] body { font-family: 'Tajawal', sans-serif; }
    </style>
</head>
<!-- M6 FIX: Embed current role from server session into data attribute -->
<body class="aigh-app bg-[#f3f4f6] text-slate-800 min-h-screen flex flex-col" data-current-role="<?php echo htmlspecialchars($_SESSION['role'] ?? 'HEAD_NURSE', ENT_QUOTES, 'UTF-8'); ?>">

    <!-- Top Window Bar -->
    <header class="bg-[#464775] text-white h-12 flex items-center justify-between px-3 z-30 shadow-sm shrink-0">
        <div class="flex items-center space-x-3 rtl:space-x-reverse">
            <div>
                <div class="aigh-title">Nursing Management</div>
                <div class="aigh-subtitle">Hospital workforce, scheduling and compliance</div>
            </div>
        </div>
        <div class="flex items-center space-x-2 rtl:space-x-reverse text-xs">
            <select id="hubUnitSelect" onchange="window.app.refreshAll()" class="bg-[#33344a] text-white font-bold rounded px-2 py-1 outline-none cursor-pointer">
                <option value="u-nicu">Neonatal ICU (NICU) [Pilot]</option>
                <option value="u-ed">Emergency Dept (ED) [Wave 1]</option>
                <option value="u-or">Operating Theatres (OR) [Wave 2]</option>
            </select>
            <select id="appRoleSelect" onchange="window.app.switchRole(this.value)" class="bg-indigo-900 font-bold text-amber-300 rounded px-2 py-1 outline-none cursor-pointer">
                <option value="HEAD_NURSE">👑 Head Nurse (Sara)</option>
                <option value="STAFF_NURSE">👩‍⚕️ Staff Nurse (Zainab)</option>
            </select>
            <button onclick="window.app.toggleLang()" class="bg-[#33344a] hover:bg-[#3d3e59] px-2.5 py-1 rounded font-bold">
                <span id="langBtn">العربية</span>
            </button>
        </div>
    </header>

    <!-- App Container -->
    <div class="flex flex-1 overflow-hidden">

        <!-- Left Navigation Rail -->
        <!-- M2 FIX: Removed duplicate horizontal tab bar; keeping only the left rail -->
        <nav class="w-16 bg-[#ebebeb] border-r border-slate-300 flex flex-col items-center py-2 space-y-3 shrink-0 text-[10px] font-semibold text-slate-600">
        <button onclick="window.app.switchTab('shifts')" id="tab-shifts" class="flex flex-col items-center p-2 rounded-lg text-indigo-700 font-bold bg-slate-200 w-12"><span class="text-lg">📅</span> Shifts</button>
        <button onclick="window.app.switchTab('directory')" id="tab-directory" class="flex flex-col items-center p-2 rounded-lg hover:bg-slate-200 w-12"><span class="text-lg">👥</span> Nurses</button>
        <button onclick="window.app.switchTab('leaves')" id="tab-leaves" class="flex flex-col items-center p-2 rounded-lg hover:bg-slate-200 w-12"><span class="text-lg">🏖️</span> Leaves</button>
        <button onclick="window.app.switchTab('handovers')" id="tab-handovers" class="flex flex-col items-center p-2 rounded-lg hover:bg-slate-200 w-12"><span class="text-lg">📋</span> SBAR</button>
        <button onclick="window.app.switchTab('rollout')" id="tab-rollout" class="flex flex-col items-center p-2 rounded-lg hover:bg-slate-200 w-12"><span class="text-lg">🚀</span> Waves</button>
        <button onclick="window.app.switchTab('analytics')" id="tab-analytics" class="flex flex-col items-center p-2 rounded-lg hover:bg-slate-200 w-12"><span class="text-lg">📈</span> Insights</button>
        <button onclick="window.app.switchTab('departments')" id="tab-departments" class="flex flex-col items-center p-2 rounded-lg hover:bg-slate-200 w-12"><span class="text-lg">🏢</span> Depts</button>
    </nav>

        <!-- Main Workspace -->
        <main class="flex-1 overflow-y-auto bg-white p-6 space-y-6">

            <div id="toastBox" class="hidden p-3.5 rounded-xl border text-xs font-semibold flex items-center justify-between shadow-sm">
                <span id="toastMsg"></span>
                <button onclick="document.getElementById('toastBox').classList.add('hidden')" class="font-bold ml-3">✕</button>
            </div>

 <!-- =================================================================== -->
<!-- DEPARTMENTS & SUB-UNITS CLINICAL MANAGEMENT (M365 THEME)            -->
<!-- =================================================================== -->
<section id="view-departments" class="hidden space-y-6">

    <!-- Top Stats & Filter Bar -->
    <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div class="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-100 pb-3 gap-3">
            <div>
                <h2 class="text-base font-bold text-slate-900">Hospital Departments & Clinical Sub-Units</h2>
                <p class="text-xs text-slate-500">Configure clinical departments, staffing minimums, and child units for pilot waves.</p>
            </div>
            <div class="flex items-center gap-2">
                <button onclick="window.app.openDeptModal()" class="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-sm transition">
                    + Add Department
                </button>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
            <!-- View Mode Switcher -->
            <div>
                <label class="block font-bold text-slate-600 mb-1">View Display</label>
                <select id="selViewMode" onchange="window.app.onDeptViewModeChange()" class="w-full bg-slate-50 border border-slate-300 font-semibold rounded-xl p-2.5 outline-none">
                    <option value="DEPARTMENTS">Departments Overview</option>
                    <option value="SUB_UNITS">Sub-Units Drill-Down</option>
                </select>
            </div>

            <!-- Active Department Filter -->
            <div>
                <label class="block font-bold text-slate-600 mb-1">Selected Department</label>
                <select id="selSelectedDept" onchange="window.app.onSelectedDeptDropdownChange()" class="w-full bg-slate-50 border border-slate-300 font-semibold rounded-xl p-2.5 outline-none">
                    <!-- Populated dynamically -->
                </select>
            </div>

            <!-- Search Filter -->
            <div>
                <label class="block font-bold text-slate-600 mb-1">Search Directory</label>
                <input type="text" id="deptSearchInput" oninput="window.app.filterDeptTable()" placeholder="Search code or unit..." class="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 outline-none">
            </div>

            <!-- Sub-Unit Add Button -->
            <div class="flex items-end">
                <button onclick="window.app.openSubUnitModal()" id="btnAddSubUnit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2.5 px-4 rounded-xl shadow-sm transition">
                    + Add Sub-Unit
                </button>
            </div>
        </div>
    </div>

    <!-- Active Details Table Card -->
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="p-4 bg-slate-50/50 border-b border-slate-200 flex justify-between items-center">
            <span class="font-bold text-xs text-slate-700" id="tableHeaderCaption">Departments List</span>
            <div class="flex items-center gap-4 text-xs font-semibold">
                <span class="text-slate-500">Total Depts: <strong class="text-slate-800" id="countTotalDepts">0</strong></span>
                <span class="text-slate-500">Total Staff: <strong class="text-indigo-600" id="countTotalStaff">0</strong></span>
            </div>
        </div>

        <div class="overflow-x-auto w-full">
            <table class="w-full text-left rtl:text-right border-collapse text-xs min-w-[700px]">
                <thead class="bg-slate-50 font-semibold text-slate-700 border-b border-slate-200" id="deptTableHead">
                    <!-- Dynamic Headers -->
                </thead>
                <tbody id="deptTableBody" class="divide-y divide-slate-100 bg-white">
                    <!-- Dynamic Rows -->
                </tbody>
            </table>
        </div>
    </div>
</section>

<!-- M1 FIX: Single deptModal (removed duplicate at lines 241-263) -->
<!-- MODAL: ADD / EDIT DEPARTMENT -->
<div id="deptModal" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center hidden p-4">
    <div class="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 text-xs">
        <h3 class="font-bold text-sm text-slate-900" id="deptModalTitle">Add Department</h3>
        <input type="hidden" id="dmDeptId">
        <div>
            <label class="font-bold block mb-1">Department Code *</label>
            <input type="text" id="dmCode" placeholder="e.g. CRIT_CARE" class="w-full border border-slate-300 rounded-lg p-2.5 font-mono uppercase font-bold">
        </div>
        <div>
            <label class="font-bold block mb-1">Department Name (English) *</label>
            <input type="text" id="dmNameEn" placeholder="Critical Care Medicine" class="w-full border border-slate-300 rounded-lg p-2.5">
        </div>
        <div>
            <label class="font-bold block mb-1">اسم القسم (العربية) *</label>
            <input type="text" id="dmNameAr" dir="rtl" placeholder="طب العناية الحرجة" class="w-full border border-slate-300 rounded-lg p-2.5">
        </div>
        <div class="flex justify-end gap-2 pt-3 border-t">
            <!-- L8 FIX: Use closeModal() consistently -->
            <button onclick="window.app.closeModal('deptModal')" class="px-4 py-2 border rounded-xl font-semibold">Cancel</button>
            <button onclick="window.app.submitDept()" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold">Save Department</button>
        </div>
    </div>
</div>

<!-- MODAL: ADD / EDIT SUB-UNIT -->
<div id="subUnitModal" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center hidden p-4">
    <div class="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 text-xs">
        <h3 class="font-bold text-sm text-slate-900" id="subUnitModalTitle">Add Sub-Unit to Department</h3>
        <input type="hidden" id="smUnitId">

        <div>
            <label class="font-bold block mb-1">Parent Department *</label>
            <select id="smParentDept" class="w-full border border-slate-300 rounded-lg p-2.5 bg-slate-50 font-semibold">
                <!-- Loaded from Departments -->
            </select>
        </div>

        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="font-bold block mb-1">Sub-Unit Code *</label>
                <input type="text" id="smCode" placeholder="e.g. NICU_A" class="w-full border border-slate-300 rounded-lg p-2.5 font-mono uppercase font-bold">
            </div>
            <div>
                <label class="font-bold block mb-1">Sub-Unit Name (EN) *</label>
                <input type="text" id="smNameEn" placeholder="Neonatal ICU Pod A" class="w-full border border-slate-300 rounded-lg p-2.5">
            </div>
        </div>

        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="font-bold block mb-1">Day Shift Min Staff *</label>
                <input type="number" id="smDayQuota" value="2" min="1" class="w-full border border-slate-300 rounded-lg p-2.5 font-bold font-mono">
            </div>
            <div>
                <label class="font-bold block mb-1">Night Shift Min Staff *</label>
                <input type="number" id="smNightQuota" value="2" min="1" class="w-full border border-slate-300 rounded-lg p-2.5 font-bold font-mono">
            </div>
        </div>

        <div class="grid grid-cols-2 gap-3">
            <div>
                <label class="font-bold block mb-1">Rollout Wave</label>
                <select id="smWave" class="w-full border border-slate-300 rounded-lg p-2.5 bg-white font-semibold">
                    <option value="PILOT">PILOT</option>
                    <option value="WAVE_1">WAVE 1 (Critical Care)</option>
                    <option value="WAVE_2">WAVE 2 (Surgical)</option>
                    <option value="WAVE_3">WAVE 3 (Wards)</option>
                </select>
            </div>
            <div>
                <label class="font-bold block mb-1">Go-Live Status</label>
                <select id="smStatus" class="w-full border border-slate-300 rounded-lg p-2.5 bg-white font-semibold">
                    <option value="PLANNED">PLANNED</option>
                    <option value="TRAINING">TRAINING</option>
                    <option value="HYPERCARE">HYPERCARE</option>
                    <option value="STABILIZED">STABILIZED</option>
                </select>
            </div>
        </div>

        <div class="flex justify-end gap-2 pt-3 border-t">
            <!-- L8 FIX: Use closeModal() consistently -->
            <button onclick="window.app.closeModal('subUnitModal')" class="px-4 py-2 border rounded-xl font-semibold">Cancel</button>
            <button onclick="window.app.submitSubUnit()" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold">Save Sub-Unit</button>
        </div>
    </div>
</div>

<!-- M3 FIX: Removed orphan departmentsTbody table (was never populated by app.js) -->
<!-- M1 FIX: Removed duplicate deptModal that was below here -->
<!-- M2 FIX: Removed duplicate horizontal sub-navigation bar -->

            <!-- 1. SHIFTS MATRIX -->
            <section id="view-shifts" class="space-y-4">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between border-b pb-3 gap-2">
                    <div>
                        <h2 class="text-lg font-bold text-slate-900">Weekly Shift Matrix (Teams Shifts)</h2>
                        <p class="text-xs text-slate-500">Tap cell to assign D, E, N, X. Expired licenses and approved leaves are locked automatically.</p>
                    </div>
                    <div class="flex gap-2">
                        <button onclick="window.app.runAutoSweep()" class="bg-indigo-50 border border-indigo-200 text-indigo-700 font-bold text-xs px-3 py-2 rounded-xl">⚡ Run 30-Day Alert Sweep</button>
                        <button onclick="window.app.publishSchedule()" class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-sm">📤 Publish to Teams</button>
                    </div>
                </div>

                <div class="border border-slate-200 rounded-2xl overflow-x-auto shadow-sm">
                    <table class="w-full text-center border-collapse text-xs min-w-[700px]">
                        <thead id="shiftsThead" class="bg-slate-50 font-semibold text-slate-600 border-b"></thead>
                        <tbody id="shiftsTbody" class="divide-y divide-slate-100"></tbody>
                    </table>
                </div>

                <div class="bg-amber-50/50 border border-amber-200 rounded-2xl p-4 space-y-3">
                    <h3 class="font-bold text-xs text-amber-900">⚡ Unassigned Open Shifts Board</h3>
                    <div id="openShiftsList" class="grid grid-cols-1 md:grid-cols-3 gap-3"></div>
                </div>
            </section>

            <!-- 2. DIRECTORY -->
            <section id="view-directory" class="hidden space-y-4">
                <div class="flex justify-between items-center border-b pb-3">
                    <div>
                        <h2 class="text-lg font-bold text-slate-900">Nurse Registry & Master Data</h2>
                        <p class="text-xs text-slate-500">Includes 10-digit Saudi National ID / Iqama validation and license status.</p>
                    </div>
                    <!-- L8 FIX: Use openModal() consistently -->
                    <button onclick="window.app.openModal('nurseModal')" class="bg-emerald-600 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-sm">+ Add Nurse</button>
                </div>
                <div class="border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
                    <table class="w-full text-left rtl:text-right border-collapse text-xs">
                        <thead class="bg-slate-50 border-b text-slate-600 font-semibold">
                            <tr>
                                <th class="p-3">Nurse Profile</th>
                                <th class="p-3">KSA Identification</th>
                                <th class="p-3">Assigned Unit</th>
                                <th class="p-3">SCFHS Credential</th>
                                <th class="p-3">License Health</th>
                            </tr>
                        </thead>
                        <tbody id="directoryTbody" class="divide-y divide-slate-100"></tbody>
                    </table>
                </div>
            </section>

            <!-- 3. LEAVES -->
            <section id="view-leaves" class="hidden space-y-4">
                <div class="flex justify-between items-center border-b pb-3">
                    <div>
                        <h2 class="text-lg font-bold text-slate-900">Leave Management Engine</h2>
                        <p class="text-xs text-slate-500">Approved leaves automatically cross-lock shift creation.</p>
                    </div>
                    <!-- L8 FIX: Use openModal() consistently -->
                    <button onclick="window.app.openModal('leaveModal')" class="bg-emerald-600 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-sm">+ Request Leave</button>
                </div>
                <div class="border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
                    <table class="w-full text-left rtl:text-right border-collapse text-xs">
                        <thead class="bg-slate-50 border-b text-slate-600 font-semibold">
                            <tr>
                                <th class="p-3">Employee</th>
                                <th class="p-3">Leave Type</th>
                                <th class="p-3">Period</th>
                                <th class="p-3">Status</th>
                                <th class="p-3 text-center">Manager Action</th>
                            </tr>
                        </thead>
                        <tbody id="leavesTbody" class="divide-y divide-slate-100"></tbody>
                    </table>
                </div>
            </section>

            <!-- 4. HANDOVERS -->
            <section id="view-handovers" class="hidden space-y-4">
                <div class="flex justify-between items-center border-b pb-3">
                    <div>
                        <h2 class="text-lg font-bold text-slate-900">Shift Handover Feed (SBAR Protocol)</h2>
                        <p class="text-xs text-slate-500">Structured communication: Situation, Background, Assessment, Recommendation.</p>
                    </div>
                    <!-- L8 FIX: Use openModal() consistently -->
                    <button onclick="window.app.openModal('handoverModal')" class="bg-indigo-600 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-sm">+ New Handover</button>
                </div>
                <div id="handoverList" class="space-y-3 text-xs"></div>
            </section>

            <!-- 5. ROLLOUT WAVES -->
            <section id="view-rollout" class="hidden space-y-6">
                <div class="border-b pb-3">
                    <h2 class="text-lg font-bold text-slate-900">Hospital Rollout Waves & Support Desk</h2>
                    <p class="text-xs text-slate-500">Tracks pilot expansion to ED, CCU, OR, and Inpatient Wards.</p>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="border rounded-2xl p-4 bg-slate-50 space-y-3">
                        <h3 class="font-bold text-xs text-slate-800">Hospital Waves Status</h3>
                        <div id="wavesList" class="space-y-2 text-xs"></div>
                    </div>
                    <div class="border rounded-2xl p-4 bg-white space-y-3 shadow-sm">
                        <div class="flex justify-between items-center">
                            <h3 class="font-bold text-xs text-slate-800">Active Hypercare Tickets</h3>
                            <!-- L8 FIX: Use openModal() consistently -->
                            <button onclick="window.app.openModal('ticketModal')" class="text-[11px] text-indigo-600 font-bold underline">+ Log Ticket</button>
                        </div>
                        <div id="ticketsList" class="space-y-2 text-xs"></div>
                    </div>
                </div>
            </section>

            <!-- 6. ANALYTICS -->
            <section id="view-analytics" class="hidden space-y-6">
                <div class="flex justify-between items-center border-b pb-3">
                    <div>
                        <h2 class="text-lg font-bold text-slate-900">Executive Insights & Continuous Optimization</h2>
                        <p class="text-xs text-slate-500">Overtime alerts, satisfaction score (CSAT), and self-healing data audits.</p>
                    </div>
                    <button onclick="window.app.runAuditScanner()" class="bg-indigo-600 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow-sm">🔍 Run Data Drift Scanner</button>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div class="p-4 rounded-2xl border border-emerald-200 bg-emerald-50/40">
                        <p class="text-[10px] uppercase font-bold text-emerald-700">SCFHS Compliance</p>
                        <div class="text-2xl font-black text-emerald-800" id="kpi-compliance">100%</div>
                    </div>
                    <div class="p-4 rounded-2xl border border-amber-200 bg-amber-50/40">
                        <p class="text-[10px] uppercase font-bold text-amber-700">CSAT Satisfaction</p>
                        <div class="text-2xl font-black text-amber-800" id="kpi-csat">4.8 ★</div>
                    </div>
                    <div class="p-4 rounded-2xl border border-indigo-200 bg-indigo-50/40">
                        <p class="text-[10px] uppercase font-bold text-indigo-700">Drift Anomaly Count</p>
                        <div class="text-2xl font-black text-indigo-800" id="kpi-anomalies">0</div>
                    </div>
                </div>

                <div class="border border-slate-200 rounded-2xl p-4 bg-white shadow-sm space-y-3">
                    <h3 class="font-bold text-xs text-slate-800">Statutory Workload & Overtime (48-Hour Threshold)</h3>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left rtl:text-right border-collapse text-xs">
                            <thead class="bg-slate-50 border-b text-slate-600">
                                <tr>
                                    <th class="p-2.5">Nurse</th>
                                    <th class="p-2.5">Unit</th>
                                    <th class="p-2.5">Scheduled Hours</th>
                                    <th class="p-2.5">Legal Limit</th>
                                    <th class="p-2.5">Risk Status</th>
                                </tr>
                            </thead>
                            <tbody id="overtimeTbody" class="divide-y divide-slate-100 font-mono"></tbody>
                        </table>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <!-- Modals -->
    <div id="nurseModal" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center hidden p-4">
        <div class="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl space-y-3 text-xs">
            <h3 class="font-bold text-sm">Add Nurse Master Profile</h3>
            <div><label class="font-bold block mb-1">Employee Number</label><input type="text" id="nmEmp" placeholder="EMP-5001" class="w-full border rounded-lg p-2 font-mono"></div>
            <div class="grid grid-cols-2 gap-2">
                <div><label class="font-bold block mb-1">First Name (EN)</label><input type="text" id="nmFn" placeholder="Noura" class="w-full border rounded-lg p-2"></div>
                <div><label class="font-bold block mb-1">Last Name (EN)</label><input type="text" id="nmLn" placeholder="Al-Harbi" class="w-full border rounded-lg p-2"></div>
            </div>
            <div class="grid grid-cols-2 gap-2">
                <div>
                    <label class="font-bold block mb-1">ID Type</label>
                    <select id="nmIdType" class="w-full border rounded-lg p-2 bg-white">
                        <option value="NATIONAL_ID">Saudi National ID (Starts with 1)</option>
                        <option value="IQAMA">Resident Iqama (Starts with 2)</option>
                    </select>
                </div>
                <div><label class="font-bold block mb-1">ID Number (10 Digits)</label><input type="text" id="nmIdNo" maxlength="10" placeholder="1038472911" class="w-full border rounded-lg p-2 font-mono"></div>
            </div>
            <div><label class="font-bold block mb-1">Phone Number</label><input type="text" id="nmPhone" placeholder="+966509988771" class="w-full border rounded-lg p-2 font-mono"></div>
            <div class="flex justify-end gap-2 pt-2 border-t">
                <!-- L8 FIX: Use closeModal() consistently -->
                <button onclick="window.app.closeModal('nurseModal')" class="px-4 py-2 border rounded-xl">Cancel</button>
                <button onclick="window.app.submitNurse()" class="px-4 py-2 bg-emerald-600 text-white rounded-xl font-bold">Save Nurse</button>
            </div>
        </div>
    </div>

    <div id="leaveModal" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center hidden p-4">
        <div class="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl space-y-3 text-xs">
            <h3 class="font-bold text-sm">Request Statutory Leave</h3>
            <div>
                <label class="font-bold block mb-1">Type</label>
                <select id="lrType" class="w-full border rounded-lg p-2 bg-white">
                    <option value="ANNUAL">Annual Leave</option>
                    <option value="SICK">Sick Leave</option>
                    <option value="HAJJ">Hajj Leave</option>
                </select>
            </div>
            <div><label class="font-bold block mb-1">Start Date</label><input type="date" id="lrStart" class="w-full border rounded-lg p-2"></div>
            <div><label class="font-bold block mb-1">End Date</label><input type="date" id="lrEnd" class="w-full border rounded-lg p-2"></div>
            <div class="flex justify-end gap-2 pt-2 border-t">
                <!-- L8 FIX: Use closeModal() consistently -->
                <button onclick="window.app.closeModal('leaveModal')" class="px-3 py-1.5 border rounded-lg">Cancel</button>
                <button onclick="window.app.submitLeave()" class="px-3 py-1.5 bg-emerald-600 text-white rounded-lg font-bold">Submit</button>
            </div>
        </div>
    </div>

    <div id="handoverModal" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center hidden p-4">
        <div class="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl space-y-3 text-xs">
            <h3 class="font-bold text-sm">Record Shift Handover</h3>
            <div><label class="font-bold block mb-1">Handover Title</label><input type="text" id="hoTitle" placeholder="e.g. NICU Pod A Day-Night Transition" class="w-full border rounded-lg p-2"></div>
            <div><label class="font-bold block mb-1">Patient Census</label><input type="number" id="hoCensus" value="12" class="w-full border rounded-lg p-2"></div>
            <div><label class="font-bold block mb-1">SBAR Details</label><textarea id="hoContent" rows="4" class="w-full border rounded-lg p-2 font-mono" placeholder="S: Situation&#10;B: Background&#10;A: Assessment&#10;R: Recommendation"></textarea></div>
            <div class="flex justify-end gap-2 pt-2 border-t">
                <!-- L8 FIX: Use closeModal() consistently -->
                <button onclick="window.app.closeModal('handoverModal')" class="px-3 py-1.5 border rounded-lg">Cancel</button>
                <button onclick="window.app.submitHandover()" class="px-3 py-1.5 bg-indigo-600 text-white rounded-lg font-bold">Post Handover</button>
            </div>
        </div>
    </div>

    <div id="ticketModal" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center hidden p-4">
        <div class="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl space-y-3 text-xs">
            <h3 class="font-bold text-sm">Submit Hypercare Issue</h3>
            <div>
                <label class="font-bold block mb-1">Priority</label>
                <select id="tkPriority" class="w-full border rounded-lg p-2 bg-white">
                    <option value="P1_CRITICAL">P1 - Critical (Patient Care Blocker)</option>
                    <option value="P2_HIGH" selected>P2 - High (Roster Shortage)</option>
                    <option value="P3_MEDIUM">P3 - Medium (UI/Sync)</option>
                </select>
            </div>
            <div><label class="font-bold block mb-1">Title</label><input type="text" id="tkTitle" placeholder="e.g. Coverage deficit on Friday Night" class="w-full border rounded-lg p-2"></div>
            <div><label class="font-bold block mb-1">Description</label><textarea id="tkDesc" rows="3" class="w-full border rounded-lg p-2"></textarea></div>
            <div class="flex justify-end gap-2 pt-2 border-t">
                <!-- L8 FIX: Use closeModal() consistently -->
                <button onclick="window.app.closeModal('ticketModal')" class="px-3 py-1.5 border rounded-lg">Cancel</button>
                <button onclick="window.app.submitTicket()" class="px-3 py-1.5 bg-indigo-600 text-white rounded-lg font-bold">Log Ticket</button>
            </div>
        </div>
    </div>

    <!-- Client-Side Controller Bundle -->
    <script src="public/js/app.js"></script>
</body>
</html>
