// public/js/app.js - Hardened Error-Resistant Controller
class App {
    constructor() {
        this.currentLang = 'en';
        this.currentRole = 'HEAD_NURSE';
        this.matrixDates = [];
        this.deptsCache = [];
        this.subUnitsCache = [];
    }

    // C1 FIX: XSS sanitizer — escape all dynamic content before innerHTML insertion
    esc(str) {
        if (str === null || str === undefined) return '';
        const div = document.createElement('div');
        div.appendChild(document.createTextNode(String(str)));
        return div.innerHTML;
    }

    init() {
        try {
            // M6 FIX: Sync role from server-embedded data attribute
            const roleAttr = document.body.dataset.currentRole;
            if (roleAttr) {
                this.currentRole = roleAttr;
                const roleSelect = document.getElementById('appRoleSelect');
                if (roleSelect) roleSelect.value = roleAttr;
            }

            // C3 FIX: Read CSRF token from meta tag
            const csrfMeta = document.querySelector('meta[name="csrf-token"]');
            this.csrfToken = csrfMeta ? csrfMeta.content : '';

            this.initDates();
            this.ensureModalsHidden();
            this.refreshAll();
        } catch (err) {
            console.error("Critical initialization failure caught:", err);
        }
    }

    ensureModalsHidden() {
        // Guarantee all backdrop overlays are physically inert on load
        ['nurseModal', 'leaveModal', 'handoverModal', 'ticketModal', 'deptModal', 'subUnitModal'].forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                el.classList.add('hidden');
                el.style.display = 'none';
            }
        });
    }

    initDates() {
        this.matrixDates = [];
        const today = new Date();
        for (let i = -1; i <= 5; i++) {
            const d = new Date(today);
            d.setDate(today.getDate() + i);
            this.matrixDates.push(d.toISOString().split('T')[0]);
        }
        const lrStart = document.getElementById('lrStart');
        const lrEnd = document.getElementById('lrEnd');
        if (lrStart && this.matrixDates[1]) lrStart.value = this.matrixDates[1];
        if (lrEnd && this.matrixDates[4]) lrEnd.value = this.matrixDates[4];
    }

    async safeFetch(url, options = {}) {
        try {
            // C3 FIX: Attach CSRF token to all POST requests
            if (options.method && options.method.toUpperCase() === 'POST' && this.csrfToken) {
                if (!options.headers) options.headers = {};
                options.headers['X-CSRF-Token'] = this.csrfToken;
            }
            const res = await fetch(url, options);
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                console.error("Server non-JSON response:", text);
                return { ok: false, error: "Server returned a non-JSON payload." };
            }
            return { ok: res.ok, status: res.status, data: data };
        } catch (err) {
            console.error("Network communication failure:", err);
            return { ok: false, error: "Network connection error." };
        }
    }

    toggleLang() {
        this.currentLang = this.currentLang === 'en' ? 'ar' : 'en';
        document.documentElement.setAttribute('dir', this.currentLang === 'ar' ? 'rtl' : 'ltr');
        document.documentElement.setAttribute('lang', this.currentLang);
        const langBtn = document.getElementById('langBtn');
        if (langBtn) langBtn.innerText = this.currentLang === 'ar' ? 'English' : 'العربية';
        this.refreshAll();
    }

    switchTab(tabId) {
        const tabs = ['shifts', 'departments', 'directory', 'leaves', 'handovers', 'rollout', 'analytics'];
        tabs.forEach(t => {
            const view = document.getElementById(`view-${t}`);
            if (view) view.classList.toggle('hidden', t !== tabId);

            const btn = document.getElementById(`tab-${t}`);
            if (btn) {
                if (t === tabId) {
                    btn.className = "px-3.5 py-2 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200 flex items-center gap-1.5 whitespace-nowrap font-bold shadow-sm";
                } else {
                    btn.className = "px-3.5 py-2 rounded-lg hover:bg-slate-100 text-slate-600 flex items-center gap-1.5 whitespace-nowrap";
                }
            }
        });

        if (tabId === 'shifts') this.loadShifts();
        if (tabId === 'departments') this.loadDepartmentsConsole();
        if (tabId === 'directory') this.loadDirectory();
        if (tabId === 'leaves') this.loadLeaves();
        if (tabId === 'handovers') this.loadHandovers();
        if (tabId === 'rollout') this.loadRollout();
        if (tabId === 'analytics') this.loadAnalytics();
    }

    async switchRole(role) {
        this.currentRole = role;
        await this.safeFetch('index.php?action=switch_user', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ role })
        });
        this.showToast(role === 'HEAD_NURSE' ? 'Active Role: Head Nurse (Management Mode)' : 'Active Role: Staff Nurse (Self-Service Mode)', 'info');
        this.refreshAll();
    }

    refreshAll() {
        this.loadShifts();
        this.loadDepartmentsConsole();
        this.loadDirectory();
        this.loadLeaves();
        this.loadHandovers();
        this.loadRollout();
        this.loadAnalytics();
    }

    // Modal Display Helpers (Removes invisible blocking layer)
    openModal(id) {
        const el = document.getElementById(id);
        if (el) {
            el.classList.remove('hidden');
            el.style.display = 'flex';
        }
    }

    closeModal(id) {
        const el = document.getElementById(id);
        if (el) {
            el.classList.add('hidden');
            el.style.display = 'none';
        }
    }

    // --- 1. SHIFTS MATRIX ---
    async loadShifts() {
        const unitEl = document.getElementById('hubUnitSelect');
        if (!unitEl) return;
        const unit = unitEl.value;

        const res = await this.safeFetch(`index.php?action=get_shifts_matrix&unit_id=${unit}&start_date=${this.matrixDates[0]}&end_date=${this.matrixDates[this.matrixDates.length-1]}`);
        if (!res.ok) return;
        const data = res.data;

        const thead = document.getElementById('shiftsThead');
        if (thead) {
            let th = `<tr><th class="p-2.5 text-left rtl:text-right w-40">Nurse</th>`;
            this.matrixDates.forEach(d => {
                const day = new Date(d).toLocaleDateString('en-US', { weekday: 'short' });
                th += `<th class="p-2 border-l">${day}<br><span class="text-[9px] text-slate-400 font-mono">${d.slice(5)}</span></th>`;
            });
            thead.innerHTML = th + `</tr>`;
        }

        const tbody = document.getElementById('shiftsTbody');
        if (tbody) {
            tbody.innerHTML = '';
            (data.nurses || []).forEach(n => {
                let tr = `<tr><td class="p-2.5 text-left rtl:text-right font-bold bg-slate-50">${this.esc(n.first_name_en)} ${this.esc(n.last_name_en)} <div class="text-[9px] text-slate-400 font-mono">${this.esc(n.employee_number)}</div></td>`;
                this.matrixDates.forEach(d => {
                    const shift = (data.shifts || []).find(s => s.nurse_id === n.nurse_id && s.shift_date === d);
                    const code = shift ? shift.duty_code : '-';
                    const isPub = shift ? (shift.is_published == 1) : false; // M5 FIX: strict comparison
                    let color = "bg-slate-100 text-slate-400";
                    if (code === 'D') color = "bg-sky-100 text-sky-800 font-bold border border-sky-300";
                    if (code === 'E') color = "bg-amber-100 text-amber-800 font-bold border border-amber-300";
                    if (code === 'N') color = "bg-indigo-100 text-indigo-800 font-bold border border-indigo-300";
                    if (code === 'AL') color = "bg-emerald-100 text-emerald-800 font-bold";
                    tr += `<td class="p-1 border-l relative cursor-pointer hover:bg-slate-100" onclick="window.app.assignShiftPrompt('${this.esc(n.nurse_id)}', '${this.esc(d)}')">
                        <span class="inline-flex items-center justify-center w-7 h-7 rounded-lg text-xs ${color}">${this.esc(code)}</span>
                        ${isPub ? `<span class="absolute top-0.5 right-0.5 text-[8px] text-emerald-600 font-bold">✓</span>` : ''}
                    </td>`;
                });
                tbody.innerHTML += tr + `</tr>`;
            });
        }

        const openDiv = document.getElementById('openShiftsList');
        if (openDiv) {
            openDiv.innerHTML = '';
            const openShifts = data.open_shifts || [];
            if (openShifts.length === 0) {
                openDiv.innerHTML = '<div class="text-xs text-slate-400 col-span-3">No uncovered shifts broadcasted.</div>';
            } else {
                openShifts.forEach(os => {
                    openDiv.innerHTML += `
                        <div class="bg-white border border-amber-200 rounded-xl p-3 flex justify-between items-center text-xs">
                            <div><span class="font-bold text-amber-900">${this.esc(os.shift_date)}</span> • Duty ${this.esc(os.duty_code)}</div>
                            <button onclick="window.app.claimShift('${this.esc(os.assignment_id)}')" class="bg-emerald-600 text-white font-bold px-2.5 py-1 rounded shadow-sm hover:bg-emerald-700">Claim</button>
                        </div>
                    `;
                });
            }
        }
    }

    async assignShiftPrompt(nurseId, dateStr) {
        if (this.currentRole === 'STAFF_NURSE') {
            this.showToast('Staff nurses cannot edit schedules directly.', 'error');
            return;
        }
        const code = prompt("Enter Duty Code (D = Day, E = Evening, N = Night, AL = Annual Leave, X = Off):", "D");
        if (!code) return;

        const res = await this.safeFetch('index.php?action=save_shift_cell', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ 
                nurse_id: nurseId, 
                unit_id: document.getElementById('hubUnitSelect').value, 
                shift_date: dateStr, 
                duty_code: code 
            })
        });

        if (res.ok) {
            this.showToast('Shift assigned successfully.', 'success');
            this.loadShifts();
        } else {
            this.showToast((res.data && res.data.error) || res.error || 'Blocked by scheduling lock.', 'error');
        }
    }

    async claimShift(id) {
        const res = await this.safeFetch('index.php?action=claim_open_shift', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ assignment_id: id })
        });
        if (res.ok) {
            this.showToast('Open shift claimed.', 'success');
            this.loadShifts();
        } else {
            this.showToast((res.data && res.data.error) || 'Failed to claim shift.', 'error');
        }
    }

    async publishSchedule() {
        const res = await this.safeFetch('index.php?action=publish_unit_schedule', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ unit_id: document.getElementById('hubUnitSelect').value })
        });
        if (res.ok) {
            this.showToast(`Published ${res.data.count} shifts to Microsoft Teams Shifts!`, 'success');
            this.loadShifts();
        }
    }

    async runAutoSweep() {
        const res = await this.safeFetch('index.php?action=run_automated_sweep');
        if (res.ok) {
            this.showToast(`Swept 30-day alerts. ${res.data.dispatched} notifications created.`, 'success');
        }
    }

    // --- 2. DEPARTMENTS & SUB-UNITS ---
    async loadDepartmentsConsole() {
        const resDepts = await this.safeFetch('index.php?action=get_departments');
        if (!resDepts.ok) return;
        this.deptsCache = resDepts.data || [];

        let totalStaff = 0;
        this.deptsCache.forEach(d => { totalStaff += parseInt(d.nurse_count || 0); });
        
        const countDepts = document.getElementById('countTotalDepts');
        const countStaff = document.getElementById('countTotalStaff');
        if (countDepts) countDepts.innerText = this.deptsCache.length;
        if (countStaff) countStaff.innerText = totalStaff;

        const selDept = document.getElementById('selSelectedDept');
        const smParentDept = document.getElementById('smParentDept');
        if (selDept) {
            selDept.innerHTML = '<option value="ALL">All Departments</option>';
            if (smParentDept) smParentDept.innerHTML = '';

            this.deptsCache.forEach(d => {
                selDept.innerHTML += `<option value="${this.esc(d.department_id)}">${this.esc(d.code)} - ${this.esc(d.name_en)}</option>`;
                if (smParentDept) smParentDept.innerHTML += `<option value="${this.esc(d.department_id)}">${this.esc(d.code)} - ${this.esc(d.name_en)}</option>`;
            });
        }

        await this.renderDeptTable();
    }

    async renderDeptTable() {
        const selView = document.getElementById('selViewMode');
        const selDept = document.getElementById('selSelectedDept');
        const thead = document.getElementById('deptTableHead');
        const tbody = document.getElementById('deptTableBody');
        const caption = document.getElementById('tableHeaderCaption');
        if (!tbody || !thead || !selView || !selDept) return;

        const viewMode = selView.value;
        const selectedDeptId = selDept.value;
        tbody.innerHTML = '';

        if (viewMode === 'SUB_UNITS') {
            if (caption) caption.innerText = selectedDeptId === 'ALL' ? 'All Hospital Sub-Units' : 'Department Sub-Units';
            thead.innerHTML = `
                <tr>
                    <th class="p-3">Unit Code</th>
                    <th class="p-3">Sub-Unit Name</th>
                    <th class="p-3">Day Shift Quota</th>
                    <th class="p-3">Night Shift Quota</th>
                    <th class="p-3">Total Staff</th>
                    <th class="p-3">Status</th>
                    <th class="p-3 text-center">Actions</th>
                </tr>
            `;

            let url = 'index.php?action=get_sub_units';
            if (selectedDeptId !== 'ALL') {
                url += `&dept_id=${selectedDeptId}`;
            }

            const res = await this.safeFetch(url);
            if (!res.ok) return;
            const subUnits = res.data || [];

            if (subUnits.length === 0) {
                tbody.innerHTML = `<tr><td colspan="7" class="p-6 text-center text-slate-400">No sub-units found. Click "+ Add Sub-Unit" to create one.</td></tr>`;
                return;
            }

            subUnits.forEach(u => {
                const uJson = JSON.stringify(u).replace(/"/g, '&quot;');
                tbody.innerHTML += `
                    <tr class="hover:bg-slate-50 transition">
                        <td class="p-3 font-mono font-bold text-indigo-700">${this.esc(u.code)}</td>
                        <td class="p-3 font-semibold text-slate-800">${this.esc(u.name_en)}</td>
                        <td class="p-3 font-mono">${this.esc(u.min_staffing_day)} Day</td>
                        <td class="p-3 font-mono">${this.esc(u.min_staffing_night)} Night</td>
                        <td class="p-3"><span class="bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded font-mono font-bold">${this.esc(u.total_staff)} Staff</span></td>
                        <td class="p-3"><span class="px-2 py-0.5 rounded text-[10px] font-bold ${u.go_live_status === 'STABILIZED' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}">${this.esc(u.go_live_status)}</span></td>
                        <td class="p-3 text-center space-x-2 rtl:space-x-reverse">
                            <button onclick="window.app.editSubUnit(${uJson})" class="text-indigo-600 font-bold hover:underline">Edit</button>
                            <button onclick="window.app.deleteSubUnit('${this.esc(u.unit_id)}')" class="text-red-500 font-bold hover:underline">Delete</button>
                        </td>
                    </tr>
                `;
            });
        } else {
            if (caption) caption.innerText = 'Departments Overview';
            thead.innerHTML = `
                <tr>
                    <th class="p-3">Code</th>
                    <th class="p-3">Department Name (English)</th>
                    <th class="p-3">اسم القسم (العربية)</th>
                    <th class="p-3">Sub-Units</th>
                    <th class="p-3">Total Staff</th>
                    <th class="p-3 text-center">Actions</th>
                </tr>
            `;

            this.deptsCache.forEach(d => {
                const dJson = JSON.stringify(d).replace(/"/g, '&quot;');
                tbody.innerHTML += `
                    <tr class="hover:bg-slate-50 transition">
                        <td class="p-3 font-mono font-bold text-indigo-700">${this.esc(d.code)}</td>
                        <td class="p-3 font-bold text-slate-800">${this.esc(d.name_en)}</td>
                        <td class="p-3 text-slate-600">${this.esc(d.name_ar)}</td>
                        <td class="p-3 font-mono font-bold text-indigo-600">${this.esc(d.unit_count)} Units</td>
                        <td class="p-3 font-mono font-bold text-slate-800">${this.esc(d.nurse_count)} Nurses</td>
                        <td class="p-3 text-center space-x-2 rtl:space-x-reverse">
                            <button onclick='window.app.drillDownDept("${this.esc(d.department_id)}")' class="text-emerald-600 font-bold hover:underline">View Units</button>
                            <button onclick="window.app.editDept(${dJson})" class="text-indigo-600 font-bold hover:underline">Edit</button>
                            <button onclick="window.app.deleteDept('${this.esc(d.department_id)}')" class="text-red-500 font-bold hover:underline">Delete</button>
                        </td>
                    </tr>
                `;
            });
        }
    }

    onDeptViewModeChange() {
        this.renderDeptTable();
    }

    onSelectedDeptDropdownChange() {
        document.getElementById('selViewMode').value = 'SUB_UNITS';
        this.renderDeptTable();
    }

    drillDownDept(deptId) {
        document.getElementById('selSelectedDept').value = deptId;
        document.getElementById('selViewMode').value = 'SUB_UNITS';
        this.renderDeptTable();
    }

    openDeptModal() {
        document.getElementById('deptModalTitle').innerText = 'Add Department';
        document.getElementById('dmDeptId').value = '';
        document.getElementById('dmCode').value = '';
        document.getElementById('dmNameEn').value = '';
        document.getElementById('dmNameAr').value = '';
        this.openModal('deptModal');
    }

    editDept(d) {
        document.getElementById('deptModalTitle').innerText = 'Edit Department';
        document.getElementById('dmDeptId').value = d.department_id;
        document.getElementById('dmCode').value = d.code;
        document.getElementById('dmNameEn').value = d.name_en;
        document.getElementById('dmNameAr').value = d.name_ar;
        this.openModal('deptModal');
    }

    async submitDept() {
        const payload = {
            department_id: document.getElementById('dmDeptId').value,
            code: document.getElementById('dmCode').value,
            name_en: document.getElementById('dmNameEn').value,
            name_ar: document.getElementById('dmNameAr').value
        };

        const res = await this.safeFetch('index.php?action=save_department', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            this.closeModal('deptModal');
            this.showToast('Department saved successfully.', 'success');
            this.loadDepartmentsConsole();
        } else {
            this.showToast((res.data && res.data.error) || 'Failed to save department', 'error');
        }
    }

    async deleteDept(deptId) {
        if (!confirm('Are you sure you want to delete this department?')) return;
        const res = await this.safeFetch('index.php?action=delete_department', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ department_id: deptId })
        });
        if (res.ok) {
            this.showToast('Department deleted.', 'success');
            this.loadDepartmentsConsole();
        } else {
            this.showToast((res.data && res.data.error) || 'Delete blocked by safety constraint.', 'error');
        }
    }

    openSubUnitModal() {
        const currentSelectedDept = document.getElementById('selSelectedDept').value;
        if (currentSelectedDept !== 'ALL') {
            document.getElementById('smParentDept').value = currentSelectedDept;
        }
        document.getElementById('subUnitModalTitle').innerText = 'Add Sub-Unit';
        document.getElementById('smUnitId').value = '';
        document.getElementById('smCode').value = '';
        document.getElementById('smNameEn').value = '';
        document.getElementById('smDayQuota').value = 2;
        document.getElementById('smNightQuota').value = 2;
        this.openModal('subUnitModal');
    }

    editSubUnit(u) {
        document.getElementById('subUnitModalTitle').innerText = 'Edit Sub-Unit';
        document.getElementById('smUnitId').value = u.unit_id;
        document.getElementById('smParentDept').value = u.department_id;
        document.getElementById('smCode').value = u.code;
        document.getElementById('smNameEn').value = u.name_en;
        document.getElementById('smDayQuota').value = u.min_staffing_day;
        document.getElementById('smNightQuota').value = u.min_staffing_night;
        document.getElementById('smWave').value = u.rollout_wave || 'PILOT';
        document.getElementById('smStatus').value = u.go_live_status || 'PLANNED';
        this.openModal('subUnitModal');
    }

    async submitSubUnit() {
        const payload = {
            unit_id: document.getElementById('smUnitId').value,
            department_id: document.getElementById('smParentDept').value,
            code: document.getElementById('smCode').value,
            name_en: document.getElementById('smNameEn').value,
            min_staffing_day: document.getElementById('smDayQuota').value,
            min_staffing_night: document.getElementById('smNightQuota').value,
            rollout_wave: document.getElementById('smWave').value,
            go_live_status: document.getElementById('smStatus').value
        };

        const res = await this.safeFetch('index.php?action=save_sub_unit', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            this.closeModal('subUnitModal');
            this.showToast('Sub-Unit saved successfully.', 'success');
            this.loadDepartmentsConsole();
        } else {
            this.showToast((res.data && res.data.error) || 'Failed to save sub-unit', 'error');
        }
    }

    async deleteSubUnit(unitId) {
        if (!confirm('Are you sure you want to delete this sub-unit?')) return;
        const res = await this.safeFetch('index.php?action=delete_sub_unit', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ unit_id: unitId })
        });
        if (res.ok) {
            this.showToast('Sub-unit deleted.', 'success');
            this.renderDeptTable();
        } else {
            this.showToast((res.data && res.data.error) || 'Delete blocked by safety constraint.', 'error');
        }
    }

    filterDeptTable() {
        const query = document.getElementById('deptSearchInput').value.toLowerCase();
        const rows = document.querySelectorAll('#deptTableBody tr');
        rows.forEach(r => {
            const text = r.innerText.toLowerCase();
            r.style.display = text.includes(query) ? '' : 'none';
        });
    }

    // --- 3. NURSE DIRECTORY ---
    async loadDirectory() {
        const res = await this.safeFetch('index.php?action=get_nurses');
        if (!res.ok) return;
        const nurses = res.data || [];
        const tbody = document.getElementById('directoryTbody');
        if (!tbody) return;
        tbody.innerHTML = '';
        nurses.forEach(n => {
            let badge = '<span class="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-bold">Valid</span>';
            if (n.days_to_expiry < 0) badge = '<span class="bg-red-100 text-red-800 px-2 py-0.5 rounded font-bold">Expired</span>';
            else if (n.days_to_expiry <= 30) badge = `<span class="bg-amber-100 text-amber-800 px-2 py-0.5 rounded font-bold">${n.days_to_expiry}d left</span>`;
            tbody.innerHTML += `
                <tr>
                    <td class="p-3 font-bold">${this.esc(n.first_name_en)} ${this.esc(n.last_name_en)} <div class="text-[10px] text-slate-400 font-mono">${this.esc(n.employee_number)}</div></td>
                    <td class="p-3 font-mono">${this.esc(n.identification_type)}: ${this.esc(n.identification_number)}</td>
                    <td class="p-3">${this.esc(n.unit_name_en || '-')}</td>
                    <td class="p-3 font-mono">${this.esc(n.credential_number || 'N/A')}</td>
                    <td class="p-3">${badge}</td>
                </tr>
            `;
        });
    }

    async submitNurse() {
        const payload = {
            employee_number: document.getElementById('nmEmp').value,
            first_name_en: document.getElementById('nmFn').value,
            last_name_en: document.getElementById('nmLn').value,
            identification_type: document.getElementById('nmIdType').value,
            identification_number: document.getElementById('nmIdNo').value,
            phone_number: document.getElementById('nmPhone').value,
            primary_unit_id: document.getElementById('hubUnitSelect').value
        };
        const res = await this.safeFetch('index.php?action=save_nurse', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });
        if (res.ok) {
            this.closeModal('nurseModal');
            this.showToast('Nurse profile saved successfully.', 'success');
            this.loadDirectory();
        } else {
            this.showToast((res.data && res.data.error) || res.error || 'Failed to save nurse', 'error');
        }
    }

    // --- 4. LEAVES ---
    async loadLeaves() {
        const res = await this.safeFetch('index.php?action=get_leaves');
        if (!res.ok) return;
        const leaves = res.data || [];
        const tbody = document.getElementById('leavesTbody');
        if (!tbody) return;
        tbody.innerHTML = '';
        leaves.forEach(l => {
            tbody.innerHTML += `
                <tr>
                    <td class="p-3 font-bold">${this.esc(l.first_name_en)} ${this.esc(l.last_name_en)}</td>
                    <td class="p-3">${this.esc(l.leave_type)}</td>
                    <td class="p-3 font-mono">${this.esc(l.start_date)} → ${this.esc(l.end_date)}</td>
                    <td class="p-3 font-bold ${l.status === 'APPROVED' ? 'text-emerald-600' : 'text-amber-600'}">${this.esc(l.status)}</td>
                    <td class="p-3 text-center">
                        ${l.status === 'PENDING' && this.currentRole === 'HEAD_NURSE' ? `
                            <button onclick="window.app.decideLeave('${this.esc(l.leave_id)}', 'APPROVED')" class="bg-emerald-600 text-white font-bold px-2 py-1 rounded shadow-sm hover:bg-emerald-700">Approve</button>
                        ` : '-'}
                    </td>
                </tr>
            `;
        });
    }

    async submitLeave() {
        const res = await this.safeFetch('index.php?action=submit_leave', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                leave_type: document.getElementById('lrType').value,
                start_date: document.getElementById('lrStart').value,
                end_date: document.getElementById('lrEnd').value,
                reason: 'Statutory leave'
            })
        });
        if (res.ok) {
            this.closeModal('leaveModal');
            this.showToast('Leave submitted.', 'success');
            this.loadLeaves();
        } else {
            this.showToast((res.data && res.data.error) || 'Failed to submit leave', 'error');
        }
    }

    async decideLeave(id, dec) {
        const res = await this.safeFetch('index.php?action=decide_leave', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ leave_id: id, decision: dec })
        });
        if (res.ok) {
            this.showToast(`Leave ${dec.toLowerCase()}. Shifts locked.`, 'success');
            this.loadLeaves();
        }
    }

    // --- 5. SBAR HANDOVERS ---
    async loadHandovers() {
        const unit = document.getElementById('hubUnitSelect').value;
        const res = await this.safeFetch(`index.php?action=get_channel_messages&unit_id=${unit}`);
        if (!res.ok) return;
        const posts = res.data || [];
        const list = document.getElementById('handoverList');
        if (!list) return;
        list.innerHTML = '';
        posts.forEach(p => {
            list.innerHTML += `
                <div class="border rounded-xl p-4 bg-white shadow-sm space-y-1">
                    <div class="flex justify-between font-bold">
                        <span>${this.esc(p.sender_name)} (${this.esc(p.sender_role)})</span>
                        <span class="text-indigo-600">Census: ${this.esc(p.patient_count)} Patients</span>
                    </div>
                    <div class="font-bold text-slate-900">${this.esc(p.title)}</div>
                    <pre class="font-sans text-slate-600 whitespace-pre-line leading-relaxed">${this.esc(p.content)}</pre>
                </div>
            `;
        });
    }

    async submitHandover() {
        const res = await this.safeFetch('index.php?action=post_channel_message', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                unit_id: document.getElementById('hubUnitSelect').value,
                title: document.getElementById('hoTitle').value,
                patient_count: document.getElementById('hoCensus').value,
                content: document.getElementById('hoContent').value
            })
        });
        if (res.ok) {
            this.closeModal('handoverModal');
            this.showToast('Handover posted.', 'success');
            this.loadHandovers();
        }
    }

    // --- 6. ROLLOUT & HYPERCARE ---
    async loadRollout() {
        const res = await this.safeFetch('index.php?action=get_rollout_data');
        if (!res.ok) return;
        const data = res.data;

        const wList = document.getElementById('wavesList');
        if (wList) {
            wList.innerHTML = '';
            (data.units || []).forEach(u => {
                wList.innerHTML += `
                    <div class="flex justify-between items-center p-2 bg-white rounded border">
                        <span class="font-bold">${this.esc(u.name_en)} (${this.esc(u.rollout_wave)})</span>
                        <span class="px-2 py-0.5 rounded text-[10px] font-bold ${u.go_live_status === 'STABILIZED' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}">${this.esc(u.go_live_status)}</span>
                    </div>
                `;
            });
        }

        const tList = document.getElementById('ticketsList');
        if (tList) {
            tList.innerHTML = '';
            (data.tickets || []).forEach(t => {
                tList.innerHTML += `
                    <div class="p-2 border rounded flex justify-between items-center">
                        <div><span class="font-bold font-mono text-indigo-700">${this.esc(t.ticket_number)}</span>: ${this.esc(t.title)}</div>
                        ${t.status === 'OPEN' || t.status === 'IN_PROGRESS' ? `
                            <button onclick="window.app.resolveTicket('${this.esc(t.ticket_id)}')" class="bg-emerald-600 text-white px-2 py-0.5 rounded text-[10px]">Resolve</button>
                        ` : '<span class="text-emerald-600 font-bold text-[10px]">RESOLVED</span>'}
                    </div>
                `;
            });
        }
    }

    async submitTicket() {
        const res = await this.safeFetch('index.php?action=create_hypercare_ticket', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                unit_id: document.getElementById('hubUnitSelect').value,
                priority: document.getElementById('tkPriority').value,
                category: 'ROSTER_CONFLICT',
                title: document.getElementById('tkTitle').value,
                description: document.getElementById('tkDesc').value
            })
        });
        if (res.ok) {
            this.closeModal('ticketModal');
            this.showToast('Hypercare ticket logged.', 'success');
            this.loadRollout();
        }
    }

    async resolveTicket(id) {
        const res = await this.safeFetch('index.php?action=resolve_hypercare_ticket', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ ticket_id: id, resolution_notes: 'Resolved in clinical huddle.' })
        });
        if (res.ok) {
            this.showToast('Ticket marked resolved.', 'success');
            this.loadRollout();
        }
    }

    // --- 7. ANALYTICS ---
    async loadAnalytics() {
        const res = await this.safeFetch('index.php?action=get_stage7_analytics');
        if (!res.ok) return;
        const d = res.data;

        const compEl = document.getElementById('kpi-compliance');
        const csatEl = document.getElementById('kpi-csat');
        if (compEl) compEl.innerText = `${d.compliance_rate}%`;
        if (csatEl) csatEl.innerText = `${d.csat_avg} ★`;

        const otTbody = document.getElementById('overtimeTbody');
        if (otTbody) {
            otTbody.innerHTML = '';
            (d.overtime || []).forEach(o => {
                const over = o.scheduled_hours > o.weekly_hours_limit;
                otTbody.innerHTML += `
                    <tr>
                        <td class="p-2.5 font-bold">${this.esc(o.first_name_en)} ${this.esc(o.last_name_en)}</td>
                        <td class="p-2.5">${this.esc(o.unit_name || 'Floater')}</td>
                        <td class="p-2.5 font-bold ${over ? 'text-red-600' : 'text-slate-800'}">${this.esc(o.scheduled_hours)} hrs/wk</td>
                        <td class="p-2.5">${this.esc(o.weekly_hours_limit)} hrs</td>
                        <td class="p-2.5 font-bold text-[10px] ${over ? 'text-red-600' : 'text-emerald-600'}">${over ? 'OVERTIME ALERT' : 'OPTIMAL'}</td>
                    </tr>
                `;
            });
        }
    }

    async runAuditScanner() {
        const res = await this.safeFetch('index.php?action=run_data_drift_scan');
        if (!res.ok) return;
        const d = res.data;
        const kpiEl = document.getElementById('kpi-anomalies');
        if (kpiEl) kpiEl.innerText = (d.anomalies || []).length;

        if (!d.anomalies || d.anomalies.length === 0) {
            this.showToast('Drift Scan: 0 anomalies detected. System fully compliant.', 'success');
        } else {
            this.showToast(`Drift Scan: ${d.anomalies[0]}`, 'error');
        }
    }

    showToast(msg, type) {
        const box = document.getElementById('toastBox');
        if (!box) return;
        box.classList.remove('hidden');
        document.getElementById('toastMsg').innerText = msg;
        box.className = (type === 'error') 
            ? "p-3 rounded-xl border border-red-200 bg-red-50 text-red-900 text-xs font-semibold flex items-center justify-between shadow-sm"
            : "p-3 rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-900 text-xs font-semibold flex items-center justify-between shadow-sm";
        setTimeout(() => { box.classList.add('hidden'); }, 5000);
    }
}

// Global Single Instance Binding with Immediate Execution Guard
window.app = new App();

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => window.app.init());
} else {
    window.app.init();
}